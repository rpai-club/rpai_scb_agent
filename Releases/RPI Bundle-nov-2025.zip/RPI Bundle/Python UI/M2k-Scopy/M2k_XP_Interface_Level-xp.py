#
# Hardware specific interface functions
# For ADALM2000 aka M2k and Red M2k XPoint breadboards (8-11-2025)
# Written using Python version 3.10, Windows OS 
#
CPRevDate = "(10-26-2025)"
#
try:
    import serial
    import serial.tools.list_ports
except:
    root.update()
    showwarning("WARNING","Serial Library not installed?!")
    root.destroy()
    exit()
try:
    import libm2k
    libm2k_found = True
except:
    root.update()
    showwarning("WARNING","libm2k not installed?!")
    root.destroy()
    exit()
#
from tkinter import scrolledtext
#
ConfigFileName = "alice-last-config.cfg"
Tdiv.set(10)
ZeroGrid.set(0)
TimeDiv = 0.002

#
# adjust for your specific hardware by changing these values
DevID = "M2k"
TimeSpan = 0.001
CHANNELS = 2 # Number of supported Analog input channels
AWGChannels = 2 # Number of supported Analog output channels
PWMChannels = 0 # Number of supported PWM output channels
DigChannels = 0 # Number of supported Dig channels
LogicChannels = 0 # Number of supported Logic Analyzer channels
EnablePGAGain = 0 # 1
EnableOhmMeter = 0
EnableDmmMeter = 0
EnableDigIO = 0
UseSoftwareTrigger = 1 # use software triggering for now
AllowFlashFirmware = 0
SaveDig = 0
InterpRate = 1
MaxSamples = 8192
SMPfft = MaxSamples # Set FFT size based on fixed acquisition record length
MatrixStatus = IntVar()
MatrixStatus.set(0)
AWGBuffLen = 1024
AWGPeakToPeak = 10.0 # Iternal reference voltage for MCP4822
AWGRes = 4095 # For 8 bits, 4095 for 12 bits, 1023 for 10 bits
ATmin = 8 # set minimum DAC update rate to 8 uSec
MaxAWGSampleRate = 750000 # set to 1 / 8 uSec
AWGSampleRate = MaxAWGSampleRate
TriggerChannel = "CH1"
TriggerEdge = "RISE"
Wait = 0.001
PlusUSEnab = IntVar()
PlusUSEnab.set(1)
NegUSEnab = IntVar()
NegUSEnab.set(1)
## Time list in s/div
TMpdiv = ("0.1us","0.2us","0.5us","1us","2us","5us", "10us", "20us", "50us", "100us", "200us", "500us", "1.0ms", "2.0ms", "5.0ms",
          "10ms", "20ms", "50ms", "100ms", "200ms", "500ms", "1.0s", "2.0s", "5.0s")
#
OldCH1pdvRange = CH1pdvRange = 1.0
OldCH2pdvRange = CH2pdvRange = 1.0
#
AWGAwaveform = numpy.ones(1024)
AWGBwaveform = numpy.ones(1024)

#### Int variables to check if we want to connect/disconnect to a jumper in the different regions(Top Left, Bottom Left, Top Right, Bottom Right)
OnOff_RC = IntVar()
OnOff_TL = IntVar()
OnOff_BL = IntVar()
OnOff_TR = IntVar()
OnOff_BR = IntVar()

#### The original Matrix Screen with Cross Point Interface
MatrixStatus = IntVar()
MatrixStatus.set(0)
BOMStatus = IntVar()
BOMStatus.set(0)
#### The new Breadboard simulator Screen with Breadboard canvas and Cross Point Interface
BreadboardStatus = IntVar()
BreadboardStatus.set(0)
# initial X Y size of BB graphic, 11 pixels per grid point?
BBwidth = 520
BBheight = 440
BBGridSize = 46
BBFont = 6
CANVASwidthBB = BBwidth     # BB canvas width
CANVASheightBB = BBheight # BB canvas height
# set Jumper colors
#JPcolors = ["Red", "Orange", "Yellow", "Green", "Blue", "Purple", "Maroon", "Pink", "Red", "Orange", "Yellow", "Green", "Blue", "Purple", "Maroon", "Pink"]
JPcolors = [ "#ff0000", "#00ff00", "#0000ff", "#ff8000", "#00ffff", "#ff00ff", "#8080ff", "#ffff00",
             "#800000", "#008000", "#000080", "#905000", "#00b0b0", "#800080", "#4040a0", "#b0b000" ]
#### The variable tells what Jumpers 1-16 are connected to
Jumper_Connections = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]

#### The variable contains the circle IDs, each of which represent the jumper connections
Jumper_Connections_circles = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]

#### The variable keeps track of what component of the breadboards are occupied.
Breadboard_Store = [
                    ### TL Region
                    [[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]], 
                    ### BL Region
                    [[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]],
                    ### TR Region
                    [[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]],
                    ### BR Region
                    [[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]],]

### The variable contains the graphical represention of the jumper connections through an adjacency list
circle_adjacency_list = {}
ComponentList = []
########
# BB pin graphical location variables
TL1XY = [0,0]
BL1XY = [0,0]
TR1XY = [0,0]
BR1XY = [0,0]
JP1XY = [0,0]
JP9XY = [0,0]
AINHXY = [0,0]
# Possible power nodes
VPower = []
UnRouted = []
VPower_id = []
VPowerConnections = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]
PWConnString = ""
# Component lists
R_List = []
C_List = []
L_List = []
D_List = []
M_List = []
Q_List = []
U_List = []
#
# Breadboard pin maping for M2k Red layout
#
TL1 = "CA0"; TL2 = "CA1"; TL3 = "CA2"; TL4 = "CA3"; TL5 = "CA4"; TL6 = "CA5"; TL7 = "CA12"; TL8 = "CA13"
BL1 = "CA14"; BL2 = "CA15"; BL3 = "CA6"; BL4 = "CA7"; BL5 = "CA8"; BL6 = "CA9"; BL7 = "CA10"; BL8 = "CA11"
TL9 = "CB0"; TL10 = "CB1"; TL11 = "CB2"; TL12 = "CB3"; TL13 = "CB4"; TL14 = "CB5"; TL15 = "CB12"; TL16 = "CB13"
BL9 = "CB14"; BL10 = "CB15"; BL11 = "CB6"; BL12 = "CB7"; BL13 = "CB8"; BL14 = "CB9"; BL15 = "CB10"; BL16 = "CB11"
BL17 = "CE2"; TL17 = "CE0"; TR1 = "CE1"

TR2 = "CC0"; TR3 = "CC1"; TR4 = "CC2"; TR5 = "CC3"; TR6 = "CC4"; TR7 = "CC5"; TR8 = "CC12"; TR9 = "CC13"
BR1 = "CC14"; BR2 = "CC15"; BR3 = "CC6"; BR4 = "CC7"; BR5 = "CC8"; BR6 = "CC9"; BR7 = "CC10"; BR8 = "CC11"
TR10 = "CD0"; TR11 = "CD1"; TR12 = "CD2"; TR13 = "CD3"; TR14 = "CD4"; TR15 = "CD5"; TR16 = "CD12"; TR17 = "CD13"
BR9 = "CD14"; BR10 = "CD15"; BR11 = "CD6"; BR12 = "CD7"; BR13 = "CD8"; BR14 = "CD9"; BR15 = "CD10"; BR16 = "CD11"

AINH = "CE6"; BINH = "CE7"; CINH = "CE8"
AWG1 = "CE14"; AWG2 = "CE15"
JP5 = "CE3"; JP6 = "CE9"; JP7 = "CE10"; JP8 = "CE11"
JP9 = "CE4"; JP10 = "CE5"; JP11 = "CE12"; JP12 = "CE13"
# Change these serial pins to match board layout
CSA = 7; CSB = 6; CSE = 5; CSC = 4; CSD = 3; RST = 2; DATA = 1; CLK = 0
### CompSpinBoxList are now separated into their respective regions
JumperSpinBoxList = ("JP1", "JP2", "JP3", "JP4", "JP5", "JP6", "JP7", "JP8",
                     "JP9", "JP10", "JP11", "JP12", "JP13", "JP14", "JP15", "JP16")
CompSpinBoxList_RC = ("AWG1", "AWG2", "AINH", "BINH", "CINH", "TL17", "BL17", "TR1", "JP5", "JP6", "JP7", "JP8","JP9", "JP10", "JP11", "JP12")
CompSpinBoxList_TL = ("TL1", "TL2", "TL3", "TL4", "TL5", "TL6", "TL7", "TL8", "TL9", "TL10", "TL11", "TL12", "TL13", "TL14", "TL15", "TL16")
CompSpinBoxList_BL = ("BL1", "BL2", "BL3", "BL4", "BL5", "BL6", "BL7", "BL8", "BL9", "BL10", "BL11", "BL12", "BL13", "BL14", "BL15", "BL16")
CompSpinBoxList_TR = ("TR2", "TR3", "TR4", "TR5", "TR6", "TR7", "TR8", "TR9", "TR10", "TR11", "TR12", "TR13", "TR14", "TR15", "TR16", "TR17")
CompSpinBoxList_BR = ("BR1", "BR2", "BR3", "BR4", "BR5", "BR6", "BR7", "BR8", "BR9", "BR10", "BR11", "BR12", "BR13", "BR14", "BR15", "BR16")

##
NotesString = "Nodes JP1-8 can connect directly to BB pins TL1-16, BL1-16 (left hand BB)\nNodes JP9-16 can connect directly to BB pins TR2-17, BR1-16 (right hand BB)\nBB pins TL17, BL17 and TR1 can connect to any of JP1-4 and JP13-16\nNodes JP1-4 can connect directly to any of JP9-12 (and JP5-8*)\nNodes JP13-16 can connect directly to any of JP5-8 (and JP9-12*)\nAINH, BINH, CINH, AWG1, AWG2 can connect directly to any of JP1-4 and JP13-16"
##
## Navigate to Help web pages
def HelpLTspice(): # Change this as file location changes

    webbrowser.open("https://mercerxlab.notion.site/LTSpice-SCB-Guides-with-Example-Implementation-24c0f9dca44b80c48206db052092e88d",new=2)
#
def HelpSelfTest(): # Change this as file location changes

    webbrowser.open("https://mercerxlab.notion.site/SCB-Self-Testing-Protocol-24c0f9dca44b80aa860cdfb9986f3886",new=2)
#
def HelpDigital(): # Change this as file location changes

    webbrowser.open("https://mercerxlab.notion.site/SCB-Digital-Capabilities-24c0f9dca44b80fb8f59db6e9003f568",new=2)
#
def HelpFiles(): # How to open local help files
    #global

    file_path = os.path.abspath("Calibration%20Procedure.pdf")
    file_name = "file:///" + file_path
    # print(file_name)
    webbrowser.open(file_name,new=2)
#
### With the given jumper, Component location(ex. "TL7"), and on or off(represented by 1 or 0)
### set the corresponding JumperString, CompString and On/Off switch based on the information 
def set_connection(jumper, comp, onoff):
    global JumperString, CompString, OnOff

    if comp[0:2] == "TL" and comp != "TL17":
        JumperString[1].set(jumper)
        CompString[1].set(comp)
        OnOff[1].set(onoff)
        ManualCheck_TL()
        ManualMatrix_TL()

    elif comp[0:2] == "BL" and comp != "BL17":
        JumperString[2].set(jumper)
        CompString[2].set(comp)
        OnOff[2].set(onoff)
        ManualCheck_BL()
        ManualMatrix_BL()

    elif comp[0:2] == "TR" and comp != "TR1":
        JumperString[3].set(jumper)
        CompString[3].set(comp)
        OnOff[3].set(onoff)
        ManualCheck_TR()
        ManualMatrix_TR()

    elif comp[0:2] == "BR":
        JumperString[4].set(jumper)
        CompString[4].set(comp)
        OnOff[4].set(onoff)
        ManualCheck_BR()
        ManualMatrix_BR()

    else:
        JumperString[0].set(jumper)
        CompString[0].set(comp)
        OnOff[0].set(onoff)
        ManualCheck_RC()
        ManualMatrix_RC()
#
def BB_test():
    """
    Tests all pins in each region of a breadboard by connecting AWG1 and AINH
    through jumpers and measuring the resulting voltage.
    Logs pass/fail based on expected voltage threshold (3.9V - 4.1V).
    """
    global ser, CompString, JumperString, OnOffString, NumConn
    global AWGAShape, AWGAAmplEntry, AWGAOffsetEntry, root
    global AwgAOnOffBt, FailedPins, ShowC1_V, ShowC2_V, ShowC3_V

    Failed = 0
    FailedPins.config(text = "")
    PassString = "All BB Pins Passed"
    #reset matrix switches to all open
    ResetMatrix()
    # Configure AWG channel A DC 4.0 V
    AwgAOnOffBt.config(text='ON', style="Run.TButton")
    SetAwgA_Ampl(255)
    AWGAShape.set(0)
    AWGAAmplEntry.delete(0,"end")
    AWGAAmplEntry.insert(0, 0.0)
    AWGAOffsetEntry.delete(0,"end")
    AWGAOffsetEntry.insert(0,4.0)
    ## Send waveform
    MakeAWGwaves()
    # Select just Scope Channel A
    ShowC1_V.set(1)
    ShowC2_V.set(0)
    ShowC3_V.set(0)
    SelectChannels()
    TRACESread = 1
    #
    VOLTAGE_MIN = 3.9
    VOLTAGE_MAX = 4.1

    regions = ["TL", "BL", "TR", "BR"]

    for region in regions:
        upper_range = 17 if region[0] == "T" else 16

        if region[1] == "L":
            adc_jumper = "JP2"
            dac_jumper = "JP1"
            set_connection(dac_jumper, "TL9", 1)
            set_connection(dac_jumper, "BL9", 1)
        else:
            adc_jumper = "JP15"
            dac_jumper = "JP16"
            set_connection(dac_jumper, "TR9", 1)
            set_connection(dac_jumper, "BR9", 1)

        # Set up DAC
        set_connection(dac_jumper, "AWG1", 1)

        # Set up ADC
        set_connection(adc_jumper, "AINH", 1)
        
        for i in range(1, upper_range + 1):
            pin = region + str(i)

            # Connect test BB pin to ADC
            set_connection(adc_jumper, pin, 1)

            # get data
            Get_Data()
            VDC = numpy.mean(VBuffA)

            if VOLTAGE_MIN < VDC < VOLTAGE_MAX:
                print("{:.2f} V - Pin {} Passed!".format(VDC, pin))
            else:
                Failed = Failed + 1
                ErrorString = "{:.2f} V - Pin {} Failed!".format(VDC, pin)
                print(ErrorString)
                FailedPins.config(font="Arial 10 bold", foreground="red", text = ErrorString)
            # Disconnect test pin
            set_connection(adc_jumper, pin, 0)
            #
            root.update()
    if Failed == 0:
        FailedPins.config(font="Arial 14 bold", foreground="green", text = PassString)
        root.update()

    ####   
    ResetMatrix()
    #### 
##
# Cross point matrix functions
#
def ReadNetlist(nfp):
    global VPower, R_List, C_List, L_List, D_List, M_List, Q_List, U_List
    global ComponentList
    #
    
    try: # First check if net list is UTF-16-LE
        NetList = open(nfp, 'r', encoding='utf-16-le')     
        Rawlines = NetList.readlines()
        if len(Rawlines) == 1: # Actually miss read as utf-16 so try utf-8
            NetList.close()
            NetList = open(nfp, 'r', encoding='utf-8')
            Rawlines = NetList.readlines()
            print("Found file as UTF-8")
        #
        else:
            print("Found file as UTF-16-LE")
    except: # If fails then must be UTF-8
        NetList.close()
        NetList = open(nfp, 'r', encoding='utf-8')
        Rawlines = NetList.readlines()
        print("Found file as UTF-8")
    NetList.close()
    return(Rawlines)
    # print(Rawlines)``

def ParseNetlist(lines):
    global VPower, R_List, C_List, L_List, D_List, M_List, Q_List, U_List
    global ComponentList
    #
    VPower = []
    UnRouted = []
    R_List = []
    C_List = []
    L_List = []
    D_List = []
    M_List = []
    Q_List = []
    U_List = [] 
    # create a list of strings for all cross_point instance lines in netlist
    # ignore the rest
    ComponentList = []
    for line in lines:
        # Select only the lines that contain "cross_point"
        if ".subckt" in line:
            break
        if "cross_point" in line:
            ComponentList.append(line.split())
        SplitLine = []
        SplitLine = line.split()
        # if a source has V in name
        # and one or the other terminal nodes names have a V
        if len(SplitLine) > 0:
            FirstPart = SplitLine[0]
            if "V" == FirstPart[0]:
                if "V" in SplitLine[1]:
                    if SplitLine[1] in VPower:
                        donothing()
                    else:
                        VPower.append(SplitLine[1])
                if "V" in SplitLine[2]:
                    if SplitLine[2] in VPower:
                        donothing()
                    else:
                        VPower.append(SplitLine[2])
                if "COM" in SplitLine[1]:
                    if SplitLine[1] in VPower:
                        donothing()
                    else:
                        VPower.append(SplitLine[1])
                if "COM" in SplitLine[2]:
                    if SplitLine[2] in VPower:
                        donothing()
                    else:
                        VPower.append(SplitLine[2])
                if "0" == SplitLine[1]:
                    if SplitLine[1] in VPower:
                        donothing()
                    else:
                        VPower.append(SplitLine[1])
                if "0" == SplitLine[2]:
                    if SplitLine[2] in VPower:
                        donothing()
                    else:
                        VPower.append(SplitLine[2])
            if "R" == FirstPart[0]:
                R_List.append(SplitLine)
            if "C" == FirstPart[0]:
                C_List.append(SplitLine)
            if "L" == FirstPart[0]:
                L_List.append(SplitLine)
            if "D" == FirstPart[0]:
                D_List.append(SplitLine)
            if "M" == FirstPart[0]:
                M_List.append(SplitLine)
            if "Q" == FirstPart[0]:
                Q_List.append(SplitLine)
            if "U" in FirstPart:
                U_List.append(SplitLine)

    # print("Found these possible Power nodes: ", VPower)
#
def WhichChip(CompPin): # determine which cross point chip is used A-E

    ChipNum = 0
    # print("Which Chip ", CompPin)
    if isinstance(CompPin, int):
        return 0
    else:
        if "CA" in CompPin:
            ChipNum = 1
        if "CB" in CompPin:
            ChipNum = 2
        if "CC" in CompPin:
            ChipNum = 3
        if "CD" in CompPin:
            ChipNum = 4
        if "CE" in CompPin:
            ChipNum = 5
        return ChipNum
##
##
def ConfigCrossPointFile():
    global FileString

    netlist = FileString.get()
    ResetMatrix()
    ParseNetlist(ReadNetlist(netlist)) # list of all subcircuit instances found
    ConfigCrossPoint()
##
def ConfigCrossPointEditor():
    global BOMtext

    lines = BOMtext.get(1.0, END)
    lines = lines.splitlines()
    ResetMatrix()
    ParseNetlist(lines) # list of all subcircuit instances found
    ConfigCrossPoint()
##
def ConfigCrossPoint():
    global FileString, NumConn, ErrConn, BBblack
    global VPower, VPowerConnections, PWConnString, VPower_id
    global ComponentList, TL1XY, BL1XY, TR1XY, BR1XY
    global BBwidth, BBheight, BBGridSize, breadboard_canvas

    CompNum = len(ComponentList) # number of subcircuits
    index = 0
    connects = 0
    Errors = 0
    ErrorString = ""
    time.sleep(0.01)
    while index < CompNum:
        CompPins = ComponentList[index]
        # check if this cross point is connected to one of the possible Power rails
        for PWR in range ( 0, len(VPower), 1):
            if VPower[PWR] in CompPins:
                Vpin = CompPins[0]
                Vpin = Vpin.replace("X","")
                Vpin = Vpin.replace(chr(167),"")# remove §
                VPowerConnections[PWR].append(Vpin)
                # print( "Found ", VPower[PWR], " connected to ", Vpin)
        index = index + 1
        if "JP" in CompPins[1]:
            Jumper = CompPins[1] # First net is Jumper bus
            JmpNum = int(Jumper.replace("JP","")) - 1 # extract number 0-15
            try:
                XPin = eval(CompPins[2]) # is Second net a component BB pin
                xpin = CompPins[2]
                xpin = xpin.replace("X","")
                xpin = xpin.replace(chr(167),"")# remove §
            except:
                # for case where synbol instance name is the BB pin 
                xpin = CompPins[0]
                xpin = xpin.replace("X","")
                xpin = xpin.replace(chr(167),"")# remove §
                XPin = eval(xpin)
            #
            if XPin == 0: # cross point connected to node 0?
                xpin = CompPins[0]
                xpin = xpin.replace("X","")
                xpin = xpin.replace(chr(167),"")# remove §
                XPin = eval(xpin)
                # print(XPin,xpin)
            ##########
            updateBreadboardConnection(JmpNum, xpin, 1)
            ##########
            if "L" in xpin:
                if xpin != "TL17":
                    if JmpNum > 7:
                        ErrorString = "Jumper out of range in " + str(CompPins)
                        print(ErrorString)
                        Errors = Errors + 1
                        continue
                else: # BB pin TL17 can connect to any of JP1-4 and JP13-16
                    if JmpNum > 3 and JmpNum < 12:
                        ErrorString = "Jumper out of range in " + str(CompPins)
                        print(ErrorString)
                        Errors = Errors + 1
                        continue
                    if JmpNum > 7:
                        JmpNum = JmpNum - 8
                    # print(xpin, XPin, JmpNum)
            elif "R" in xpin:
                if xpin != "TR1":
                    if JmpNum < 7 or JmpNum > 15:
                        ErrorString = "Jumper out of range in " + str(CompPins)
                        print(ErrorString)
                        Errors = Errors + 1
                        continue
                    JmpNum = JmpNum - 8
                else: # BB pin TR1 can connect to any of JP1-4 and JP13-16
                    if JmpNum > 3 and JmpNum < 12:
                        ErrorString = "Jumper out of range in " + str(CompPins)
                        print(ErrorString)
                        Errors = Errors + 1
                        continue
                    if JmpNum > 7:
                        JmpNum = JmpNum - 8
            #
            ChipNum = WhichChip(XPin) # Find which switch chip 1-5
            if ChipNum == 5 and JmpNum > 7:
                JmpNum = JmpNum - 8
            if ChipNum > 0:
                CmpNum = int(only_numerics(XPin)) # extract number 0-15
                SendToMatrix(JmpNum, CmpNum, ChipNum, 1)
                connects = connects + 1
            else:
                ErrorString = "Error Unknown switch chip number for? " + str(xpin)
                print(ErrorString)
                # print(CompPins)
                # print(XPin,xpin)
                Errors = Errors + 1
    NumConn.config(text = "Number of connections = " + str(connects) + " Errors = " + str(Errors))
    ErrConn.config(text = ErrorString )
    #
    # Show Power / GND wires if any
    DrawPowerWires()
##
#
def ResetMatrix():
    global CSA, CSB, CSC, CSD, CSE, CLK, RST, DATA
    global FileString, NumConn, ErrConn, BOMStatus, BOMtext
    global JumperString, CompString
    global J_Connections_Labels
    global Jumper_Connections, Jumper_Connections_circles
    global breadboard_canvas, Breadboard_Store, circle_adjacency_list
    global VPower, VPowerConnections, PWConnString
    global BBwidth, BBheight, BBGridSize, VPower_id
    global OnOff_RC, OnOff_TL, OnOff_BL, OnOff_TR, OnOff_BR

    if BOMStatus.get() > 0:
        BOMtext.delete("1.0", END) # Clear all text
        DrawBreadBoardGraphic() # Clear and redraw BB graphic
    
    try:
        # Clear power nodes
        VPower = []
        UnRouted = []
        VPowerConnections = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]
        PWConnString = ""
        for PWR in range(0, len(VPower_id), 1):
            breadboard_canvas.delete(VPower_id[PWR])
        ### All of the labels and strings are reset to their first/original input
        JumperString[0].set("JP1")
        CompString[0].set("AWG1")

        JumperString[1].set("JP1")
        CompString[1].set("TL1")

        JumperString[2].set("JP1")
        CompString[2].set("BL1")

        JumperString[3].set("JP9")
        CompString[3].set("TR2")

        JumperString[4].set("JP9")
        CompString[4].set("BR1")

        # FileString.delete(0,"end")
        # FileString.insert(0,"")

        NumConn.config(text = "Number of Connections ")
        ErrConn.config(text = "Number of Errors ")
        ####

        ### All of the regions are disconnected/set to 0
        OnOff_RC.set(0)
        #ManualCheck_RC()
        OnOff_TL.set(0)
        #ManualCheck_TL()
        OnOff_BL.set(0)
        #ManualCheck_BL()
        OnOff_TR.set(0)
        #ManualCheck_TR()
        OnOff_BR.set(0)
        #ManualCheck_BR()
        ### 

        ### Empty all of the jumper connections
        Jumper_Connections = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]
        ###
        
        for i in range(0, 16, 1):
            ### Loop through all 16 jumpers and ensure that the corresponding text says "No connections"
            J_Connections_Labels[i].config(text = "No connections")
            ### For each jumper, remove the circle that represents a jumper connection
            for (_, breadboard_info, center, circle) in Jumper_Connections_circles[i]:
                breadboard_canvas.delete(circle)
                ### For the remaining connections to the same jumper, ensure that the current connection is remove by deleting the line associated
                if breadboard_info[0] != -1:
                    for (line_id, circle_id) in circle_adjacency_list[circle]:
                        breadboard_canvas.delete(line_id)
                        circle_adjacency_list[circle_id].remove((line_id, circle))

        Breadboard_Store = [
                    ### TL Region
                    [[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]], 
                    
                    ### BL Region
                    [[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]],
                    
                    ### TR Region
                    [[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]],
                    
                    ### BR Region
                    [[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
                    [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]],]
            
        Jumper_Connections_circles = [[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]]
        try:
            # Reset all cross point switches to off
            dig.setValueRaw(RST, 1) # Toggel Reset pin High
            # Wait
            dig.setValueRaw(RST, 0) # Toggel Reset pin Low
            time.sleep(0.001) # Reset all cross point switches to open
        except:
            pass
    except:
        try:
            dig.setValueRaw(RST, 1) # Toggel Reset pin High
            # Wait
            dig.setValueRaw(RST, 0) # Toggel Reset pin Low
            time.sleep(0.001) # Reset all cross point switches to ope
        except:
            pass
#
##
def BrowsNetFile():
    global FileString, NetList
    
    NetList = askopenfilename(defaultextension = ".cir", filetypes=[("Net List files", ".cir .net")])
    FileString.delete(0,"end")
    FileString.insert(0,NetList)
##
##
def DumpNetList():
    global Jumper_Connections

    filename = asksaveasfilename(defaultextension = ".cir", filetypes=[("Net Lists", "*.cir")])
    DataFile = open(filename, 'w')
    Xi = 1
    for i in range(0, 16, 1):
        for j in range(0, len(Jumper_Connections[i]), 1):
            CompPin = Jumper_Connections[i][j]
            if ("TL" in CompPin ) or ("BL" in CompPin) or ("TR" in CompPin) or ("BR" in CompPin):
                DataFile.write("X" + CompPin + " JP" + str(i+1) + " " + CompPin + " cross_point\n" )
            else:
                DataFile.write("X" + str(Xi) + " JP" + str(i+1) + " " + CompPin + " cross_point\n" )
                Xi = Xi + 1
    DataFile.close()
#
def MergNetList():
    global Jumper_Connections, BOMtext, VPowerConnections, VPower

    Xi = 1
    NC = 1
    # List all jumper connections
    for i in range(0, 16, 1):
        for j in range(0, len(Jumper_Connections[i]), 1):
            CompPin = Jumper_Connections[i][j]
            if ("TL" in CompPin ) or ("BL" in CompPin) or ("TR" in CompPin) or ("BR" in CompPin):
                IsConn = 0
                for PWR in range ( 0, len(VPower), 1):
                    if len(VPowerConnections[PWR]) > 0:
                        for Pins in range ( 0, len(VPowerConnections[PWR]), 1):
                            if CompPin in VPowerConnections[PWR][Pins]:
                                PwPin = VPower[PWR]
                                IsConn = 1
                                TxtLine = "X" + CompPin + " JP" + str(i+1) + " " + PwPin + " cross_point\n"
                if IsConn == 0:             
                    TxtLine = "X" + str(Xi) + " JP" + str(i+1) + " " + CompPin + " cross_point\n"
                    Xi = Xi + 1
            else:
                TxtLine ="X" + str(Xi) + " JP" + str(i+1) + " " + CompPin + " cross_point\n"
                if CompPin == "AWG1":
                    BOMtext.insert(END, "VAWG1 AWG1 0 0\n")
                if CompPin == "AWG2":
                    BOMtext.insert(END, "VAWG2 AWG2 0 0\n")
                Xi = Xi + 1
            BOMtext.insert(END, TxtLine)
    # Add dummy supplies for power and gnd and AWG
    BOMtext.insert(END, "VDD VDD 0 +5\n")
    BOMtext.insert(END, "VEE VEE 0 -5\n")
#            
def updateBreadboardConnection(JmpNum, CompPin, OnOff):
    global Jumper_Connections
    global J_Connections_Labels

    ### Grab the existing connections to the specified jumper
    ### along with the corresponding jumper label to the breadboard screen
    ### also determine if the Component is already connected to the Jumper
    Jmp_arr = Jumper_Connections[JmpNum]
    Jmp_label = J_Connections_Labels[JmpNum]
    connected = CompPin in Jmp_arr

    ### If we want to disconnect AND the connection exists,
    ### then we remove the component pin from the specified jumper.
    if OnOff == 0:
        if connected:
            Jmp_arr.remove(CompPin)

            ###
            modifyBreadboardCanvas(JmpNum, CompPin, OnOff)
            ###

            ### If there are no connections to the jumper
            if len(Jmp_arr) == 0:
                Jmp_label.config(text="No connections")
            ### otherwise
            else:
                Jmp_label.config(text=", ".join(Jmp_arr))

    ### If we want to connect AND the connection does not exist,
    ### then we add the component pin to the specificed jumper.
    else:
        if not connected:
            Jmp_arr.append(CompPin)
            Jmp_label.config(text=", ".join(Jmp_arr))

            ###
            modifyBreadboardCanvas(JmpNum, CompPin, OnOff)
            ###
##
def modifyBreadboardCanvas(JmpNum, CompPin, OnOff):
    global JPcolors, breadboard_canvas, Jumper_Connections_circles, circle_adjacency_list
    global BBwidth, BBheight, BBGridSize
    global TL1XY, BL1XY, TR1XY, BR1XY, JP1XY, JP9XY, AINHXY

    #### The initial (x,y) mouse click location
    # Calculate Xstep and YStep size for 50 X 40 0.1" grid,
    ## ~11 pixels per grid point?
    XStep = YStep = BBwidth/BBGridSize
    HStep = int(0.4 * XStep)
    ColumHight = (4 * XStep) + HStep # Default to 5 pin high
    start_point = (0, 0)

    ### How much we want to vary the x and y direction of
    ### the mouse click location
    x_offset = 0
    y_offset = 0

    ### Width of the Jumper circle
    width = 3

    ### Region index -> -1: Reading Channels/Voltage,
    ### 0: TL, 1: BL, 2: TR, 3: BR
    index = -1

    ### Depending on the region we are connecting to,
    ### we will have a starting pixel location
    if "JP" in CompPin:
        # print("Found a JP in CompPins", CompPin)
        JPnum = int(CompPin.replace("JP","")) # extract number 1-6
        if JPnum < 9:
            YLoc = 6 + JPnum
            start_point = (2*XStep, (YLoc*XStep))
            width = 5
            ColumHight = HStep
        else:
            YLoc = 6 + JPnum - 8
            start_point = (44*XStep, (YLoc*XStep))
            width = 5
            ColumHight = HStep
    ### AWG1 
    if "AWG1" in CompPin:
        start_point = (19*XStep, (22*XStep)+ HStep)
        width = 5
        ColumHight = XStep + HStep

    ### AWG2 
    elif "AWG2" in CompPin:
        start_point = (20*XStep, (22*XStep)+ HStep)
        width = 5
        ColumHight = XStep + HStep

    ### AINH 
    elif "AINH" in CompPin:
        start_point = (13*XStep, (22*XStep)+ HStep)
        width = 5
        ColumHight = XStep + HStep

    ### BINH 
    elif "BINH" in CompPin:
        start_point = (15*XStep, (22*XStep)+ HStep)
        width = 5
        ColumHight = XStep + HStep

    ### CINH 
    elif "CINH" in CompPin:
        start_point = (17*XStep, (22*XStep)+ HStep)
        width = 5
        ColumHight = XStep + HStep

    ### TL1 starts 
    elif "TL" in CompPin:
        start_point = (TL1XY[0]*XStep, TL1XY[1]*XStep)
        x_offset = int(CompPin[2:])-1
        index = 0

    ### BL1 starts 
    elif "BL" in CompPin:
        start_point = (BL1XY[0]*XStep, BL1XY[1]*XStep)
        x_offset = int(CompPin[2:])-1
        index = 1
    
    ### TR1 starts 
    elif "TR" in CompPin:
        start_point = (TR1XY[0]*XStep, TR1XY[1]*XStep)
        x_offset = int(CompPin[2:])-1
        index = 2

    ### BR1 starts 
    elif "BR" in CompPin:
        start_point = (BR1XY[0]*XStep, BR1XY[1]*XStep)
        x_offset = int(CompPin[2:])-1
        index = 3

    #### If we are connecting
    if OnOff:
        #### If we are at region TL, BL, TR, or BR
        if index != -1:
            #### At each region, there are 5 different locations to place our components. Find the closest open spot, if one exists
##            while y_offset < 5 and Breadboard_Store[index][y_offset][x_offset]:
##                y_offset+=1
##            
##            ### No more space on the column comp pin
##            if y_offset == 5:
##                return

            #### Otherwise, we will now occupy the location
            Breadboard_Store[index][y_offset][x_offset] = 1
            
            ### Each region (ex. TL1 <-> TL2) are separated by XStep pixels
            ### At each region, the 5 different location are separated by roughly 21 pixels
            x = start_point[0]+XStep*x_offset
            y = start_point[1]+XStep*y_offset
            
            start_point = (x, y)
    
        ### At the starting point, we will add a jumper connection through a circle
        
        # 
        if JmpNum > 8 :
            circle_id = breadboard_canvas.create_rectangle(start_point[0]-HStep, start_point[1]-HStep, start_point[0]+HStep, start_point[1]+ColumHight, outline=JPcolors[JmpNum], fill=JPcolors[JmpNum], stipple="gray50")
        else:
            circle_id = breadboard_canvas.create_rectangle(start_point[0]-HStep, start_point[1]-HStep, start_point[0]+HStep, start_point[1]+ColumHight, outline=JPcolors[JmpNum], fill=JPcolors[JmpNum], stipple="gray75")
        Jumper_Connections_circles[JmpNum].append((CompPin, (index, y_offset, x_offset), (start_point[0], start_point[1]), circle_id))

        #### If we are at region TL, BL, TR, or BR
        if index != -1:

            ### If the circle is not already existed, add it to the adjacency list
            if circle_id not in circle_adjacency_list:
                circle_adjacency_list[circle_id] = []
            
            ### For other components connected to the same jumper, we will now connect to our current component through a line
##            for (_, Breadboard_info, Center, Circle) in Jumper_Connections_circles[JmpNum]:
##                if Breadboard_info[0] != -1 and circle_id != Circle:
##                    #### The circles(jumper connections) are nodes and lines(comp location connections) are edges
##                    line_id = breadboard_canvas.create_line(x,y, Center[0], Center[1], fill=JPcolors[JmpNum], width=4)
##                    circle_adjacency_list[circle_id].append((line_id, Circle))
##                    circle_adjacency_list[Circle].append((line_id, circle_id))
    
    ### If we are disconnecting
    else:
        for (Connection, Breadboard_info, Center, Circle) in Jumper_Connections_circles[JmpNum]:
            ### We will remove the jumper connection/node
            if CompPin == Connection:
                breadboard_canvas.delete(Circle)
                Jumper_Connections_circles[JmpNum].remove((Connection, Breadboard_info, Center, Circle))

                #### If we are at region TL, BL, TR, or BR
                if Breadboard_info[0] != -1:

                    #### The location on the breadboard is now free
                    Breadboard_Store[Breadboard_info[0]][Breadboard_info[1]][Breadboard_info[2]] = 0

                    #### We will remove any existing edges from the adjacency list
                    for (line_id, circle_id) in circle_adjacency_list[Circle]:
                        breadboard_canvas.delete(line_id)
                        circle_adjacency_list[circle_id].remove((line_id, Circle))
                    circle_adjacency_list[Circle] = []
                break
##
def ManualReturn(event):

    ManualMartix()
##
def ManualMatrix(JumperString, CompString, OnOff):
    global ser, NumConn #OnOffString, NumConn

    Errors = 0
    Jumper = JumperString.get()
    JmpNum = int(Jumper.replace("JP","")) - 1 # extract number 0-15
    CompPin = CompString.get()
    if "JP" in Jumper:
        ##########
        updateBreadboardConnection(JmpNum, CompPin, OnOff)
        ##########
        if "L" in CompPin:
            if CompPin != "TL17":
                if JmpNum > 7:
                    print("Jumper out of range in " , CompPin)
                    Errors = Errors + 1
            else: # BB pin TL17 can connect to any of JP1-4 and JP13-16
                if JmpNum > 3 and JmpNum < 12:
                    print("Jumper out of range in " , CompPin)
                    Errors = Errors + 1
                if JmpNum > 7:
                    JmpNum = JmpNum - 8
                # print(xpin, XPin, JmpNum)
        elif "R" in CompPin:
            if CompPin != "TR1":
                if JmpNum < 7 or JmpNum > 15:
                    print("Jumper out of range in " , CompPins)
                    Errors = Errors + 1
                JmpNum = JmpNum - 8
            else: # BB pin TR1 can connect to any of JP1-4 and JP13-16
                if JmpNum > 3 and JmpNum < 12:
                    print("Jumper out of range in " , CompPins)
                    Errors = Errors + 1
                if JmpNum > 7:
                    JmpNum = JmpNum - 8
        #
    #print(Jumper, CompPin)
    if Errors > 0:
        NumConn.config(text = "Error: Jumper out of range! " + str(CompPin) + " " + str(Jumper))
        return
    Xpin = eval(CompPin)
    # print(Xpin, CompPin)
    # OnOff = int(OnOffString.get())
    ChipNum = WhichChip(Xpin) # Second net is Component pin
    if ChipNum == 5 and JmpNum > 7:
        JmpNum = JmpNum - 8
    if ChipNum > 0:
        CmpNum = int(only_numerics(Xpin)) # extract number 0-7
        SendToMatrix(JmpNum, CmpNum, ChipNum, OnOff)
##
def DigIOSetUp():
    global CSA, CSB, CSC, CSD, CSE, CLK, RST, DATA
    # Configure Digital pins 0-7 as Outputs
    
    dig.setDirection(CSA, libm2k.DIO_OUTPUT)
    dig.enableChannel(CSA, True)
    dig.setValueRaw(CSA, 0) # CSA input idles Low
    dig.setDirection(CSB, libm2k.DIO_OUTPUT)
    dig.enableChannel(CSB, True)
    dig.setValueRaw(CSB, 0) # CSB input idles Low
    dig.setDirection(CSC, libm2k.DIO_OUTPUT)
    dig.enableChannel(CSC, True)
    dig.setValueRaw(CSC, 0) # CSC input idles Low
    dig.setDirection(CSD, libm2k.DIO_OUTPUT)
    dig.enableChannel(CSD, True)
    dig.setValueRaw(CSD, 0) # CSD input idles Low
    dig.setDirection(CSE, libm2k.DIO_OUTPUT)
    dig.enableChannel(CSE, True)
    dig.setValueRaw(CSE, 0) # CSE input idles Low
    dig.setDirection(CLK, libm2k.DIO_OUTPUT)
    dig.enableChannel(CLK, True)
    dig.setValueRaw(CLK, 1) # CLK input idles High
    dig.setDirection(RST, libm2k.DIO_OUTPUT)
    dig.enableChannel(RST, True)
    dig.setValueRaw(RST, 0) # RST input idles Low
    dig.setDirection(DATA, libm2k.DIO_OUTPUT)
    dig.enableChannel(DATA, True)
    dig.setValueRaw(DATA, 0) # DATA input idles Low
#
def SendToMatrix(xadr, yadr, cadr, swon):
    global CSA, CSB, CSC, CSD, CSE, CLK, RST, DATA
    # set cross point switch at address x , y, on chip () to on / off
    if(xadr>7):
        xadr=7
    if(yadr>15):
        yadr=15
    if(cadr>5):
        cadr=5
    if(cadr==1):
        dadr=CSA
    if(cadr==2):
        dadr=CSB
    if(cadr==3):
        dadr=CSC
    if(cadr==4):
        dadr=CSD
    if(cadr==5):
        dadr=CSE
    # Send x y address to chip(s)
    dig.setValueRaw(CLK, 1) # CLK input idles High
    # Send first data bit
    if(xadr & 0b100):
        dig.setValueRaw(DATA, 1) # adr is High
    else:
        dig.setValueRaw(DATA, 0) # adr is Low
    dig.setValueRaw(CLK, 0) # CLK Low
    dig.setValueRaw(CLK, 1) # CLK High
    # Send Second data bit
    if(xadr & 0b010):
        dig.setValueRaw(DATA, 1) # adr is High
    else:
        dig.setValueRaw(DATA, 0) # adr is Low
    dig.setValueRaw(CLK, 0) # CLK Low
    dig.setValueRaw(CLK, 1) # CLK High
    # Send third data bit
    if(xadr & 0b001):
        dig.setValueRaw(DATA, 1) # adr is High
    else:
        dig.setValueRaw(DATA, 0) # adr is Low
    dig.setValueRaw(CLK, 0) # CLK Low
    dig.setValueRaw(CLK, 1) # CLK High
    # Now Yaddr
    # Send first data bit
    if(yadr & 0b1000):
        dig.setValueRaw(DATA, 1) # adr is High
    else:
        dig.setValueRaw(DATA, 0) # adr is Low
    dig.setValueRaw(CLK, 0) # CLK Low
    dig.setValueRaw(CLK, 1) # CLK High
    # Send Second data bit
    if(yadr & 0b0100):
        dig.setValueRaw(DATA, 1) # adr is High
    else:
        dig.setValueRaw(DATA, 0) # adr is Low
    dig.setValueRaw(CLK, 0) # CLK Low
    dig.setValueRaw(CLK, 1) # CLK High
    # Send Third data bit
    if(yadr & 0b0010):
        dig.setValueRaw(DATA, 1) # adr is High
    else:
        dig.setValueRaw(DATA, 0) # adr is Low
    dig.setValueRaw(CLK, 0) # CLK Low
    dig.setValueRaw(CLK, 1) # CLK High
    # Send fourth data bit
    if(yadr & 0b0001):
        dig.setValueRaw(DATA, 1) # adr is High
    else:
        dig.setValueRaw(DATA, 0) # adr is Low
    dig.setValueRaw(CLK, 0) # CLK Low
    dig.setValueRaw(CLK, 1) # CLK High
    # Set switch at address on or off
    if(swon == 1):
        dig.setValueRaw(DATA, 1) # Data is High switch on
    else:
        dig.setValueRaw(DATA, 0) # Data is Low switch off
    # Now Strobe which chip
    dig.setValueRaw(dadr, 1) # STB High
    dig.setValueRaw(dadr, 0) # STB Low
    dig.setValueRaw(DATA, 0) # Data idles Low
#
#### The following ManualMatrix functions are created for the divided regions in the breadboard screen
##
def ManualSet_RC():
    global CompString, JumperString
    ManualMatrix(JumperString[0], CompString[0], 1)
##
def ManualSet_TL():
    global CompString, JumperString
    ManualMatrix(JumperString[1], CompString[1], 1)
##
def ManualSet_BL():
    global CompString, JumperString
    ManualMatrix(JumperString[2], CompString[2], 1)
##
def ManualSet_TR():
    global CompString, JumperString
    ManualMatrix(JumperString[3], CompString[3], 1)
##
def ManualSet_BR():
    global CompString, JumperString
    ManualMatrix(JumperString[4], CompString[4], 1)
##
def ManualReSet_RC():
    global CompString, JumperString
    ManualMatrix(JumperString[0], CompString[0], 0)
##
def ManualReSet_TL():
    global CompString, JumperString
    ManualMatrix(JumperString[1], CompString[1], 0)
##
def ManualReSet_BL():
    global CompString, JumperString
    ManualMatrix(JumperString[2], CompString[2], 0)
##
def ManualReSet_TR():
    global CompString, JumperString
    ManualMatrix(JumperString[3], CompString[3], 0)
##
def ManualReSet_BR():
    global CompString, JumperString
    ManualMatrix(JumperString[4], CompString[4], 0)
##
def ManualMatrix_RC():
    global CompString, JumperString
    ManualMatrix(JumperString[0], CompString[0], OnOff_RC.get())
##
def ManualMatrix_RC():
    global CompString, JumperString
    ManualMatrix(JumperString[0], CompString[0], OnOff_RC.get())
##
def ManualMatrix_TL():
    global CompString, JumperString
    ManualMatrix(JumperString[1], CompString[1], OnOff_TL.get())
##
def ManualMatrix_BL():
    global CompString, JumperString
    ManualMatrix(JumperString[2], CompString[2], OnOff_BL.get())
##
def ManualMatrix_TR():
    global CompString, JumperString
    ManualMatrix(JumperString[3], CompString[3], OnOff_TR.get())
##
def ManualMatrix_BR():
    global CompString, JumperString
    ManualMatrix(JumperString[4], CompString[4], OnOff_BR.get())
## Check Boxes
def ManualCheck_RC():
    global OnOffString, OnOff
    if OnOff[0].get() == 0:
        OnOffString[0].config(style="Disab.TCheckbutton")
    else:
        OnOffString[0].config(style="Enab.TCheckbutton")
##
def ManualCheck_TL():
    global OnOffString, OnOff
    if OnOff[1].get() == 0:
        OnOffString[1].config(style="Disab.TCheckbutton")
    else:
        OnOffString[1].config(style="Enab.TCheckbutton")
##
def ManualCheck_BL():
    global OnOffString, OnOff
    if OnOff[2].get() == 0:
        OnOffString[2].config(style="Disab.TCheckbutton")
    else:
        OnOffString[2].config(style="Enab.TCheckbutton")
##
def ManualCheck_TR():
    global OnOffString, OnOff
    if OnOff[3].get() == 0:
        OnOffString[3].config(style="Disab.TCheckbutton")
    else:
        OnOffString[3].config(style="Enab.TCheckbutton")
##
def ManualCheck_BR():
    global OnOffString, OnOff
    if OnOff[4].get() == 0:
        OnOffString[4].config(style="Disab.TCheckbutton")
    else:
        OnOffString[4].config(style="Enab.TCheckbutton")
##
def DrawBBHoles(Xd, Yd, Yorg, XStep, PinW, Top):
    global breadboard_canvas, BBFont
    for Xi in range(0,17,1):
        ColNum = str(Xi+1)
        if Top == 1:
            breadboard_canvas.create_text(Xd, Yd-PinW, text = ColNum, fill="black", anchor='s', font=("arial", BBFont, "bold"))
        for Yi in range(0,5,1):
            breadboard_canvas.create_rectangle(Xd-PinW, Yd+PinW, Xd+PinW, Yd-PinW, fill="black", outline="gray", width=1)
            Yd = Yd + XStep
        if Top == 0:
            Yd = Yd - XStep
            breadboard_canvas.create_text(Xd, Yd+PinW, text = ColNum, fill="black", anchor='n', font=("arial", BBFont, "bold"))
        Yd = Yorg
        Xd = Xd + XStep
##
def DrawBreadBoardGraphic():
    global BBwidth, BBheight, BBGridSize, breadboard_canvas, FontSize
    global TL1XY, BL1XY, TR1XY, BR1XY, JP1XY, JP9XY, AINHXY, PWConnString
    global VPowerConnections, VPower, PWConnString, VPower_id, BBblack
    global COLORwhite, COLORblack, GUITheme, Jumper_Connections
    global XlabLogo_image, NotesString

    if "Sun Valley Dark" in GUITheme:
        BBblack = "#ffffff" # 100% white
    else:
        BBblack = "#000000" # 100% black
    
    breadboard_canvas.delete(ALL) # remove all items
    # print("Just Cleared BB Canvas")
    # Calculate Xstep and YStep size for 50 X 40 0.1" square grid,
    # ~11 pixels per grid point?
    XStep = YStep = BBwidth/BBGridSize
    HStep = int(XStep/2)
    PinW = int(0.3 * XStep)
    # Draw BB outlines
    Xorg = Yorg = 4 * XStep
    Xd = 22 * XStep
    Yd = 17 * XStep
    MidY = (BL1XY[1] - 1) * XStep
    breadboard_canvas.create_rectangle(Xorg, Yorg, Xd, Yd, fill="white", outline="black", width=2)
    Xorg = 24 * XStep
    Xd = 42 * XStep
    breadboard_canvas.create_rectangle(Xorg, Yorg, Xd, Yd, fill="white", outline="black", width=2)
    # Left mounting holes
    Xorg = int(6 * XStep)
    Yorg = int(10.5 * XStep)
    Dia = int(XStep * 0.75)
    breadboard_canvas.create_oval(Xorg-Dia, Yorg-Dia, Xorg+Dia, Yorg+Dia, outline="black", fill="white", width=2)
    Xorg = int(20 * XStep)
    breadboard_canvas.create_oval(Xorg-Dia, Yorg-Dia, Xorg+Dia, Yorg+Dia, outline="black", fill="white", width=2)
    # Right mounting holes
    Xorg = int(26 * XStep)
    breadboard_canvas.create_oval(Xorg-Dia, Yorg-Dia, Xorg+Dia, Yorg+Dia, outline="black", fill="white", width=2)
    Xorg = int(40 * XStep)
    breadboard_canvas.create_oval(Xorg-Dia, Yorg-Dia, Xorg+Dia, Yorg+Dia, outline="black", fill="white", width=2)
    # Left slot
    Xorg = int(7 * XStep)
    Xd = int(19 * XStep)
    breadboard_canvas.create_rectangle(Xorg, Yorg-Dia, Xd, Yorg+Dia, fill="white", outline="black", width=2)
    # Rigth Slot
    Xorg = int(27 * XStep)
    Xd = int(39 * XStep)
    breadboard_canvas.create_rectangle(Xorg, Yorg-Dia, Xd, Yorg+Dia, fill="white", outline="black", width=2)
    # Start with TL1 at Grid X = 5 and Y = 5
    TL1XY = [5,5]
    #
    Xorg = Xd = Yorg = Yd = 5 * XStep
    DrawBBHoles(Xd, Yd, Yorg, XStep, PinW, 1)
    # Next BL1 at Grid X = 5 and Y = 12
    BL1XY = [5,12]
    #
    Xorg = Xd = 5 * XStep
    Yorg = Yd = 12 * XStep
    DrawBBHoles(Xd, Yd, Yorg, XStep, PinW, 0)
    # Next TR1 at Grid X = 27 and Y = 5
    TR1XY = [25,5]
    #
    Xorg = Xd = 25 * XStep
    Yorg = Yd = 5 * XStep
    DrawBBHoles(Xd, Yd, Yorg, XStep, PinW, 1)
    # Next BR1 at Grid X = 27 and Y = 12
    BR1XY = [25,12]
    #
    Xorg = Xd = 25 * XStep
    Yorg = Yd = 12 * XStep
    DrawBBHoles(Xd, Yd, Yorg, XStep, PinW, 0)
    # Top Power Rail
    Xorg = 8 * XStep
    Yorg = int(0.5 * XStep)
    Xd = 38 * XStep
    Yd = int(3.5 * XStep)
    breadboard_canvas.create_rectangle(Xorg, Yorg, Xd, Yd, fill="white", outline="black", width=2)
    breadboard_canvas.create_line(Xorg+HStep, Yorg+HStep, Xd-HStep, Yorg+HStep, fill="red", width=2)
    breadboard_canvas.create_text(Xd+XStep+HStep, Yorg+HStep, text = "+5V", fill="red", font=("arial", FontSize, "bold"))
    breadboard_canvas.create_line(Xorg+HStep, Yd-HStep, Xd-HStep, Yd-HStep, fill="blue", width=2)
    breadboard_canvas.create_text(Xd+XStep+HStep, Yd-HStep, text = "GND", fill=BBblack, font=("arial", FontSize, "bold"))
    #
    Xorg = Xd = 9 * XStep
    Yorg = Yd = int(1.5 * XStep)
    for Xi in range(0,5,1):
        for Yi in range(0,5,1):
            breadboard_canvas.create_rectangle(Xd-PinW, Yd+PinW, Xd+PinW, Yd-PinW, fill="black", outline="gray", width=1)
            Xd = Xd + XStep
        Xd = Xd + XStep
    Xorg = Xd = 9 * XStep
    Yorg = Yd = int(2.5 * XStep)
    for Xi in range(0,5,1):
        for Yi in range(0,5,1):
            breadboard_canvas.create_rectangle(Xd-PinW, Yd+PinW, Xd+PinW, Yd-PinW, fill="black", outline="gray", width=1)
            Xd = Xd + XStep
        Xd = Xd + XStep
    # Bottom Power Rail
    Xorg = 8 * XStep
    Yorg = 18 * XStep
    Xd = 38 * XStep
    Yd = 21 * XStep
    breadboard_canvas.create_rectangle(Xorg, Yorg, Xd, Yd, fill="white", outline="black", width=2)
    breadboard_canvas.create_line(Xorg+HStep, Yorg+HStep, Xd-HStep, Yorg+HStep, fill="red", width=2)
    breadboard_canvas.create_text(Xd+XStep+HStep, Yorg+HStep, text = "GND", fill=BBblack, font=("arial", FontSize, "bold"))
    breadboard_canvas.create_line(Xorg+HStep, Yd-HStep, Xd-HStep, Yd-HStep, fill="blue", width=2)
    breadboard_canvas.create_text(Xd+XStep+HStep, Yd-HStep, text = "-5V", fill="blue", font=("arial", FontSize, "bold"))
    Xorg = Xd = 9 * XStep
    Yorg = Yd = 19 * XStep
    for Xi in range(0,5,1):
        for Yi in range(0,5,1):
            breadboard_canvas.create_rectangle(Xd-PinW, Yd+PinW, Xd+PinW, Yd-PinW, fill="black", outline="gray", width=1)
            Xd = Xd + XStep
        Xd = Xd + XStep
    Xorg = Xd = 9 * XStep
    Yorg = Yd = 20 * XStep
    for Xi in range(0,5,1):
        for Yi in range(0,5,1):
            breadboard_canvas.create_rectangle(Xd-PinW, Yd+PinW, Xd+PinW, Yd-PinW, fill="black", outline="gray", width=1)
            Xd = Xd + XStep
        Xd = Xd + XStep
    # AWG / Scope points
    AINHXY = [12,22]
    #
    Xorg = 12 * XStep
    Xd = 21 * XStep 
    Yorg = 22 * XStep
    Yd = 24 * XStep
    breadboard_canvas.create_rectangle(Xorg, Yorg, Xd, Yd, fill="white", outline="black", width=2)
    Xorg = 20 * XStep
    Yorg = 23 * XStep
    Xd = 22 * XStep
    Xt = 24 * XStep
    Yd = 27 * XStep
    breadboard_canvas.create_rectangle(Xorg-PinW, Yorg+PinW, Xorg+PinW, Yorg-PinW, fill="black", outline="gray", width=1)
    breadboard_canvas.create_line(Xorg, Yorg, Xorg, Yd, fill=BBblack, width=3)
    breadboard_canvas.create_line(Xorg, Yd, Xd, Yd, fill=BBblack, width=3, arrow="last")
    breadboard_canvas.create_text(Xt, Yd, text = "AWG2", fill=BBblack, font=("arial", FontSize, "bold"))
    Xorg = 19 * XStep
    Yd = 28 * XStep
    breadboard_canvas.create_rectangle(Xorg-PinW, Yorg+PinW, Xorg+PinW, Yorg-PinW, fill="black", outline="gray", width=1)
    breadboard_canvas.create_line(Xorg, Yorg, Xorg, Yd, fill=BBblack, width=3)
    breadboard_canvas.create_line(Xorg, Yd, Xd, Yd, fill=BBblack, width=3, arrow="last")
    breadboard_canvas.create_text(Xt, Yd, text = "AWG1", fill=BBblack, font=("arial", FontSize, "bold"))
    Xorg = 17 * XStep
    Yd = 29 * XStep
    breadboard_canvas.create_rectangle(Xorg-PinW, Yorg+PinW, Xorg+PinW, Yorg-PinW, fill="black", outline="gray", width=1)
    breadboard_canvas.create_line(Xorg, Yorg, Xorg, Yd, fill=BBblack, width=3)
    breadboard_canvas.create_line(Xorg, Yd, Xd, Yd, fill=BBblack, width=3, arrow="last")
    breadboard_canvas.create_text(Xt, Yd, text = "CINH", fill=BBblack, font=("arial", FontSize, "bold"))
    Xorg = 15 * XStep
    Yd = 30 * XStep
    breadboard_canvas.create_rectangle(Xorg-PinW, Yorg+PinW, Xorg+PinW, Yorg-PinW, fill="black", outline="gray", width=1)
    breadboard_canvas.create_line(Xorg, Yorg, Xorg, Yd, fill=BBblack, width=3)
    breadboard_canvas.create_line(Xorg, Yd, Xd, Yd, fill=BBblack, width=3, arrow="last")
    breadboard_canvas.create_text(Xt, Yd, text = "BINH", fill=BBblack, font=("arial", FontSize, "bold"))
    Xorg = 13 * XStep
    Yd = 31 * XStep
    breadboard_canvas.create_rectangle(Xorg-PinW, Yorg+PinW, Xorg+PinW, Yorg-PinW, fill="black", outline="gray", width=1)
    breadboard_canvas.create_line(Xorg, Yorg, Xorg, Yd, fill=BBblack, width=3)
    breadboard_canvas.create_line(Xorg, Yd, Xd, Yd, fill=BBblack, width=3, arrow="last")
    breadboard_canvas.create_text(Xt, Yd, text = "AINH", fill=BBblack, font=("arial", FontSize, "bold"))
    # Left and Right Jumper Headers
    JP1XY = [2,7]
    JP9XY = [44,7]
    #
    Xorg = 2 * XStep
    Yorg = Yd = 7 * XStep
    Yb = 15 * XStep
    breadboard_canvas.create_rectangle(Xorg-XStep, Yorg-YStep, Xorg+XStep, Yb, fill="white", outline="black", width=2)
    for Yi in range(0,8,1):
        breadboard_canvas.create_rectangle(Xorg-PinW, Yd+PinW, Xorg+PinW, Yd-PinW, fill="black", outline="gray", width=1)
        Yd = Yd + XStep
    #
    Xorg = 44 * XStep
    Yd = 7 * XStep
    breadboard_canvas.create_rectangle(Xorg-XStep, Yorg-YStep, Xorg+XStep, Yb, fill="white", outline="black", width=2)
    for Yi in range(0,8,1):
        breadboard_canvas.create_rectangle(Xorg-PinW, Yd+PinW, Xorg+PinW, Yd-PinW, fill="black", outline="gray", width=1)
        Yd = Yd + XStep
    ### Now redraw matrix connections
    for i in range(0, 16, 1):
        for j in range(0, len(Jumper_Connections[i]), 1):
            # print(Jumper_Connections[i])
            CompPin = Jumper_Connections[i][j]
            modifyBreadboardCanvas(i, CompPin, 1)
    # Show Power / GND wires if any
    DrawPowerWires()
    # Place XLab logo
    try:
        Xd = 3 * XStep
        Yd = 32 * XStep
        breadboard_canvas.create_image((Xd, Yd), image=XlabLogo_image) # 500 , 375 
        # breadboard_canvas.image = breadboard_image
    except:
        pass
    # Place connection notes
    Xd = 3 * XStep
    Yd = 37 * XStep
    breadboard_canvas.create_text(Xd, Yd, text=NotesString, anchor='nw', fill=BBblack, font=("arial", FontSize, "bold"))
##
def DrawPowerWires():
    global BBblack, VPower, VPowerConnections, breadboard_canvas
    global TL1XY, BL1XY, TR1XY, BR1XY, VPower_id
    global BBwidth, BBGridSize

    # Show Power / GND wires if any
    XStep = YStep = BBwidth/BBGridSize
    HStep = int(XStep/2)
    PinW = int(0.3 * XStep)
    Xd = 6 * XStep
    Yd = 33 * XStep
    VPower_id = []
    WireColor = BBblack
    MidY = (BL1XY[1] - 1) * XStep
    for PWR in range ( 0, len(VPower), 1):
        if len(VPowerConnections[PWR]) > 0:
            PWConnString = "Found "
            for Pins in range ( 0, len(VPowerConnections[PWR]), 1):
                PWConnString = PWConnString + VPowerConnections[PWR][Pins] + " "
                #
                Xh1 = Yh1 = Xh2 = Yh2 = 0
                PinStr = VPowerConnections[PWR][Pins]
                # print(PinStr)
                Xh1, Yh1, GrNum = FindBBPin(PinStr, XStep)
                #
                if "V" in VPower[PWR]:
                    Xh1, Xh2, Yh1, Yh2 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 0)
                    if Yh1 < MidY:
                        WireColor = "red"
                    else:
                        WireColor = "blue"
                if "GND" == VPower[PWR] or "COM" == VPower[PWR] or "0" == VPower[PWR]:
                    Xh1, Xh2, Yh1, Yh2 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 1)
                    WireColor = BBblack
                MidLineX = abs(Xh1 + Xh2)/2
                MidLineY = abs(Yh1 + Yh2)/2
                PWRLine = [Xh1, Yh1, MidLineX+XStep, MidLineY, Xh2, Yh2]
                Power_id = breadboard_canvas.create_line(PWRLine, smooth=TRUE, fill=WireColor, width=4)
                VPower_id.append(Power_id)
                Power_id = breadboard_canvas.create_oval(Xh1-2, Yh1-2, Xh1+2, Yh1+2, outline="#a0a0a0", fill="#a0a0a0", width=1)
                VPower_id.append(Power_id)
                Power_id = breadboard_canvas.create_oval(Xh2-2, Yh2-2, Xh2+2, Yh2+2, outline="#a0a0a0", fill="#a0a0a0", width=1)
                VPower_id.append(Power_id)
                #
            if VPower[PWR] == "0":
                PwrNode = "GND"
            else:
                PwrNode = VPower[PWR]
            PWConnString = PWConnString + "connected to " + PwrNode
            Power_id = breadboard_canvas.create_text(Xd, Yd, text = PWConnString, anchor='w', fill=BBblack, font=("arial", FontSize, "bold"))
            VPower_id.append(Power_id)
            Yd = Yd + XStep
##
def MakeBreadboardScreen():
    global breadboardwindow, BreadboardStatus
    global BBwidth, BBheight, BBGridSize, CANVASwidthBB, CANVASheightBB
    global J_Connections_Labels, PassFailSelfCal
    global FileString, NumConn, CPRevDate, SWRev
    global CompString, JumperString, OnOff, OnOffString, FailedPins
    global FrameBG, BorderSize, ErrConn, ShowBallonHelp
    global JumperSpinBoxList, XlabLogo_image
    global CompSpinBoxList_RC, CompSpinBoxList_TL, CompSpinBoxList_BL, CompSpinBoxList_TR, CompSpinBoxList_BR
    global click_loc, breadboard_image, JPcolors, breadboard_canvas

    if BreadboardStatus.get() == 0:
        try:
            XlabLogo_image = PhotoImage(file='./XLab-logo.png') #
            # image size in pixels is 50 X 50
            # XlabLogo_image =  XlabLogo_image.zoom(2, 2)
            # XlabLogo_image = XlabLogo_image.subsample(3,3)
        except:
            pass
        BreadboardStatus.set(1)
        CANVASwidthBB = BBwidth     # BB canvas width
        CANVASheightBB = BBheight # BB canvas height
        ### Set the size and shape of the Breadboard window 
        breadboardwindow = Toplevel()
        breadboardwindow.title("Software Breadboard Connections " + CPRevDate)
        breadboardwindow.protocol("WM_DELETE_WINDOW", DestroyBreadboardScreen)
        breadboardwindow.resizable(TRUE,TRUE)
        # breadboardwindow.geometry('+300+300')
        breadboardwindow.configure(background=FrameBG, borderwidth=BorderSize)
        
        ### The labels that tells the connections for each jumper
        J_Connections_Labels = []

        ### The Component string tells us what to connect to the jumper
        CompString = []
        OnOffString = []
        ### The Jumper string tells us what jumper we are dealing with
        JumperString = []

        ManualMatrix_funcs = [ManualMatrix_RC, ManualMatrix_TL, ManualMatrix_BL, ManualMatrix_TR, ManualMatrix_BR]
        ManualCheck_funcs = [ManualCheck_RC, ManualCheck_TL, ManualCheck_BL, ManualCheck_TR, ManualCheck_BR]
        ManualSet_funcs = [ManualSet_RC, ManualSet_TL, ManualSet_BL, ManualSet_TR, ManualSet_BR]
        ManualReSet_funcs = [ManualReSet_RC, ManualReSet_TL, ManualReSet_BL, ManualReSet_TR, ManualReSet_BR]
        regions = ["XC", "TL", "BL", "TR", "BR"]

        CompSpinBoxList_arr = [CompSpinBoxList_RC, CompSpinBoxList_TL, CompSpinBoxList_BL, CompSpinBoxList_TR, CompSpinBoxList_BR]
        JumperSpinBoxList_arr = [JumperSpinBoxList[0:4]+JumperSpinBoxList[12:17], JumperSpinBoxList[0:8], JumperSpinBoxList[0:8], JumperSpinBoxList[8:16], JumperSpinBoxList[8:16]]
        
        OnOff = [OnOff_RC, OnOff_TL, OnOff_BL, OnOff_TR, OnOff_BR]
        
        #### LEFT SIDE OF SCREEN ####

        ### The following is the original Matrix window of the Cross Point Interface

        matrixwindow = Frame(breadboardwindow, borderwidth=BorderSize, relief=FrameRelief)
        matrixwindow.pack(side=LEFT, fill=BOTH, expand=NO)

        toplab = Label(matrixwindow,text="Cross Point Interface ", style="A12B.TLabel")
        toplab.grid(row=0, column=0, columnspan=4, sticky=W)
        mcl1 = Label(matrixwindow,text="LTspice Netlist File")
        mcl1.grid(row=1, column=0, columnspan=2, sticky=W)
        FileString = Entry(matrixwindow, width=50)
        FileString.bind("<Return>", ConfigCrossPointFile)
        FileString.grid(row=2, column=0, columnspan=4, sticky=W)
        FileString.delete(0,"end")
        FileString.insert(0,"")
        NumConn = Label(matrixwindow,text="Number of Connections ")
        NumConn.grid(row=3, column=0, columnspan=4, sticky=W)
        ErrConn = Label(matrixwindow,text="Number of Errors ")
        ErrConn.grid(row=4, column=0, columnspan=4, sticky=W)
        Browsebutton = Button(matrixwindow, text="Browse", style="W8.TButton", command=BrowsNetFile)
        Browsebutton.grid(row=5, column=0, columnspan=1, sticky=W, pady=4)
        #
        Sendbutton = Button(matrixwindow, text="Send", style="W6.TButton", command=ConfigCrossPointFile)
        Sendbutton.grid(row=5, column=1, columnspan=1, sticky=W, pady=4)
        # 
        resetmxbutton = Button(matrixwindow, text="Reset", style="W6.TButton", command=ResetMatrix)
        resetmxbutton.grid(row=5, column=2, columnspan=1, sticky=W, pady=4)
        #
        dumpnetsbutton = Button(matrixwindow, text="Save Nets", style="W10.TButton", command=DumpNetList)
        dumpnetsbutton.grid(row=6, column=0, columnspan=1, sticky=W, pady=4)
        #
        Helpmenu = Menubutton(matrixwindow, text="Help", style="W6.TButton")
        Helpmenu.menu = Menu(Helpmenu, tearoff = 0 )
        Helpmenu["menu"]  = Helpmenu.menu
        Helpmenu.menu.add_command(label="LTspice Guide", foreground="blue", command=HelpLTspice)
        Helpmenu.menu.add_command(label="Self Test Guide", foreground="blue", command=HelpSelfTest)
        Helpmenu.menu.add_command(label="Digital Guide", foreground="blue", command=HelpDigital)
        Helpmenu.grid(row=6, column=2, columnspan=1, sticky=W, pady=6)
        #
        if ShowBallonHelp > 0:
            try:
                Browsebutton_tip = CreateToolTip(Browsebutton, 'Select LTspice net list file')
            except:
                donothing()
            try:
                Sendbutton_tip = CreateToolTip(Sendbutton, 'Send net list connections to BB')
            except:
                donothing()
            try:
                resetmxbutton_tip = CreateToolTip(resetmxbutton, 'Reset all BB connections to open')
            except:
                donothing()
            try:
                dumpnetsbutton_tip = CreateToolTip(dumpnetsbutton, 'Save all BB connections to a file')
            except:
                donothing()
            try:
                Helpmenu_tip = CreateToolTip(Helpmenu, 'Access Help pages')
            except:
                donothing()
        ### The loop simply divides the Component String, Jumper String, and On/Off switch into different regions
        for region in range(0, 5, 1):
            cpcl1 = Label(matrixwindow,text=f"{regions[region]} Comp Pin")
            cpcl1.grid(row=2*region + 7, column=0, columnspan=1, sticky=W)

            jpcl1 = Label(matrixwindow,text="Jumper")
            jpcl1.grid(row=2*region + 7, column=1, columnspan=1, sticky=W)
       
            oncl1 = Label(matrixwindow,text="Off")
            oncl1.grid(row=2*region + 7, column=2, columnspan=1, sticky=W)
            oncl2 = Label(matrixwindow,text="On")
            oncl2.grid(row=2*region + 7, column=3, columnspan=1, sticky=W)
        
            #### The component label is added in the specified region
            CompString.append(Combobox(matrixwindow, state="readonly", width=6, values=CompSpinBoxList_arr[region]))
            CompString[region].grid(row=2*region + 8, column=0, columnspan=1, sticky=W)
            ####

            if region == 0:
                CompString[region].set("AWG1")
            else:
                if regions[region] != "TR":
                    CompString[region].set(f"{regions[region]}1")
                else:
                    CompString[region].set(f"{regions[region]}2")

            #### The jumper label is added in the specified region
            JumperString.append(Combobox(matrixwindow, state="readonly", width=6, values=JumperSpinBoxList_arr[region]))
            JumperString[region].grid(row=2*region + 8, column=1, columnspan=1, sticky=W)
            ####

            if regions[region] != "TR" and regions[region] != "BR":
                JumperString[region].set("JP1")
            else:
                JumperString[region].set("JP9")

            #### The On/Off check box is added in the specified region
            ## OnOffString.append(Checkbutton(matrixwindow, variable = OnOff[region], onvalue = 1, offvalue = 0, width=2, command=ManualCheck_funcs[region]))
            ## OnOffString[region].grid(row=2*region + 8, column=2, columnspan=1, sticky=W)
            ## ManualCheck_funcs[region]()
            ####
            Resetbutton = Button(matrixwindow, image=RoundRedBtn, command=ManualReSet_funcs[region])
            Resetbutton.grid(row=2*region + 8, column=2, sticky=W)
            Setbutton = Button(matrixwindow, image = RoundGrnBtn, command=ManualSet_funcs[region])
            Setbutton.grid(row=2*region + 8, column=3, sticky=W)
            ## Setbutton = Button(matrixwindow, text="Set", style="W6.TButton", command=ManualMatrix_funcs[region])
            ## Setbutton.grid(row=2*region + 8, column=3, sticky=W, pady=4)
        #### Self Test Button Section
        #
        SelfTestbutton = Button(matrixwindow, text="Self Test", style="W10.TButton", command=BB_test)
        SelfTestbutton.grid(row=17, column=0, columnspan=1, sticky=W, pady=4)
        FailedPins = Label(matrixwindow,text="")
        FailedPins.grid(row=18, column=1, columnspan=4, sticky=W)
        #####
        if ShowBallonHelp > 0:
            try:
                SelfCalibrateButton_tip = CreateToolTip(SelfCalibrateButton, 'Calibrate Scope input resistor dividers')
            except:
                donothing()
            try:
                SelfTestbutton_tip = CreateToolTip(SelfTestbutton, 'Run Continuity Self Test.')
            except:
                donothing()
        BOMButton = Button(matrixwindow, text="Placement", style="W10.TButton", command=MakeBOMScreen)
        BOMButton.grid(row=18, column=0, columnspan=1, sticky=W)
##        UpdateBOMButton = Button(matrixwindow, text="Update", style="W10.TButton", command=UpDateBOMScreen)
##        UpdateBOMButton.grid(row=19, column=1, columnspan=1, sticky=W)
##        MergBOMButton = Button(matrixwindow, text="Merg Nets", style="W10.TButton", command=MergNetList)
##        MergBOMButton.grid(row=19, column=2, columnspan=1, sticky=W)
        ############################## 

        ### MIDDLE SIDE OF SCREEN ####
        
        #### The top part of the middle section is the simulated image of the breadboard
        breadboard_connections = Frame(breadboardwindow, borderwidth=BorderSize, relief=FrameRelief)
        breadboard_connections.pack(side=LEFT, fill=BOTH, expand=YES)

        image_section = Frame(breadboard_connections, borderwidth=BorderSize, relief=FrameRelief)
        image_section.pack(side=TOP, fill=BOTH, expand=YES)
        
        #
        breadboard_canvas = Canvas(image_section, width=CANVASwidthBB, height=CANVASheightBB, cursor='cross')
        breadboard_canvas.pack(side=TOP, fill=BOTH, expand=YES)
        #
        breadboard_canvas.bind('<Configure>', BBCAresize)
        breadboard_canvas.bind('<1>', onBBClick)
        breadboard_canvas.bind('<3>', onBBClick)
        DrawBreadBoardGraphic()
        ####

        #### Bottom of the middle Section currently tells the pixel location of our mouse click
        buttons_section = Frame(breadboard_connections, borderwidth=BorderSize, relief=FrameRelief)
        buttons_section.pack(side=TOP, fill=BOTH, expand=NO)

        test22 = Label(buttons_section,text="Interactive Mouse")
        test22.grid(row=0, column=0, columnspan=4, sticky=W)

        click_loc = Label(buttons_section,text="Click Location")
        click_loc.grid(row=1, column=1, columnspan=4, sticky=W)

        #####

        ##############################

        #### RIGHT SIDE OF SCREEN ####

        ### The right side of the screen goes through all 16 Jumpers and sets up the initial connections through text labels
        J_all_connections = Frame(breadboardwindow, borderwidth=BorderSize, relief=FrameRelief)
        J_all_connections.pack(side=RIGHT, fill=BOTH, expand=NO)

        J_all_topLabel = Label(J_all_connections,text="Jumper 1-16 Connections ", style="A12B.TLabel")
        J_all_topLabel.grid(row=0, column=0, columnspan=4, sticky=W)

        for i in range(0, 16, 1):
            J = Label(J_all_connections,font="Arial 10 bold",text=f"Jumper {i+1}: ", foreground = JPcolors[i])
            J.grid(row=2*(i)+1, column=0, columnspan=4, sticky=W)

            J_connections = Label(J_all_connections,font="Arial 8 bold", borderwidth=2, text="No connections")
            J_connections.grid(row=2*(i+1), column=0, columnspan=4, sticky=W)

            J_Connections_Labels.append(J_connections)

        ##############################
#
def BBCAresize(event):
    global breadboard_canvas, BBwidth, BBheight, CANVASwidthBB, CANVASheightBB
    global BBFont, FontSize, BBGridSize
    
    CANVASwidthBB = event.width - 4
    CANVASheightBB = event.height - 4
    BBwidth = CANVASwidthBB # new grid width
    BBheight = CANVASheightBB # new grid height
    BBFont = int(0.6 * BBwidth/BBGridSize)
    DrawBreadBoardGraphic()
    UpDateBOMScreen()
#
## Display the location on the BB of the mouse click.
def onBBClick(event):
    global BBwidth, BBheight, BBGridSize, breadboard_canvas, FontSize
    global TL1XY, BL1XY, TR1XY, BR1XY, JP1XY, JP9XY, AINHXY
    global JumperString, CompString, OnOff
    global click_loc, BOMStatus, BOMtext

    # Calculate Xstep and YStep size for 50 X 40 0.1" grid, 11 pixels per grid point?
    XStep = YStep = BBwidth/BBGridSize
    HStep = int(XStep/2)
    # Find extent of four BB regions
    TLwidth = 18 * XStep
    TLheight = 6 * XStep
    TLMinX = (TL1XY[0] * XStep) - HStep
    TLMaxX = TLMinX + TLwidth
    TLMinY = (TL1XY[1] * XStep) - HStep
    TLMaxY = TLMinY + TLheight
    #
    BLMinX = (BL1XY[0] * XStep) - HStep
    BLMaxX = BLMinX + TLwidth
    BLMinY = (BL1XY[1] * XStep) - HStep
    BLMaxY = BLMinY + TLheight
    #
    TRMinX = (TR1XY[0] * XStep) - HStep
    TRMaxX = TRMinX + TLwidth
    TRMinY = (TR1XY[1] * XStep) - HStep
    TRMaxY = TRMinY + TLheight
    #
    BRMinX = (BR1XY[0] * XStep) - HStep
    BRMaxX = BRMinX + TLwidth
    BRMinY = (BR1XY[1] * XStep) - HStep
    BRMaxY = BRMinY + TLheight
    # Find extent of left and right jumper regions
    JLwidth = 2* XStep
    JLheight = 9 * XStep
    JLMinX = (JP1XY[0] * XStep) - HStep
    JLMaxX = JLMinX + JLwidth
    JLMinY = (JP1XY[1] * XStep) - HStep
    JLMaxY = JLMinY + JLheight
    #
    JRMinX = (JP9XY[0] * XStep) - HStep
    JRMaxX = JRMinX + JLwidth
    JRMinY = (JP9XY[1] * XStep) - HStep
    JRMaxY = JRMinY + JLheight
    # Find extent of Scope AWG pin regions
    INwidth = 9 * XStep
    INheight = 2 * XStep
    INMinX = (AINHXY[0] * XStep) - HStep
    INMaxX = INMinX + INwidth
    INMinY = (AINHXY[1] * XStep) - HStep
    INMaxY = INMinY + INheight
    #
    CursorX = event.x
    CursorY = event.y
    # Find which BB pin was clicked on
    if CursorX > TLMinX and CursorX < TLMaxX and CursorY > TLMinY and CursorY < TLMaxY:
        GridX = 1 + int((CursorX - TLMinX) / XStep)
        PinClicked = "TL" + str(GridX)
        CompString[1].set(PinClicked)
        PinBB = "Clicked on " + PinClicked
    elif CursorX > BLMinX and CursorX < BLMaxX and CursorY > BLMinY and CursorY < BLMaxY:
        GridX = 1 + int((CursorX - TLMinX) / XStep)
        PinClicked = "BL" + str(GridX)
        CompString[2].set(PinClicked)
        PinBB = "Clicked on " + PinClicked
    elif CursorX > TRMinX and CursorX < TRMaxX and CursorY > TRMinY and CursorY < TRMaxY:
        GridX = 1 + int((CursorX -TRMinX) / XStep)
        PinClicked = "TR" + str(GridX)
        CompString[3].set(PinClicked)
        PinBB = "Clicked on " + PinClicked
    elif CursorX > BRMinX and CursorX < BRMaxX and CursorY > BRMinY and CursorY < BRMaxY:
        GridX = 1 + int((CursorX -TRMinX) / XStep)
        PinClicked = "BR" + str(GridX)
        CompString[4].set(PinClicked)
        PinBB = "Clicked on " + PinClicked
    elif CursorX > JLMinX and CursorX < JLMaxX and CursorY > JLMinY and CursorY < JLMaxY:
        GridY = 1 + int((CursorY - JLMinY) / XStep)
        PinClicked = "JP" + str(GridY)
        if GridY < 5:
            JumperString[0].set(PinClicked)
        JumperString[1].set(PinClicked)
        JumperString[2].set(PinClicked)
        PinBB = "Clicked on " + PinClicked
    elif CursorX > JRMinX and CursorX < JRMaxX and CursorY > JRMinY and CursorY < JRMaxY:
        GridY = 9 + int((CursorY - JLMinY) / XStep)
        PinClicked = "JP" + str(GridY)
        if GridY > 12:
            JumperString[0].set(PinClicked)
        JumperString[3].set(PinClicked)
        JumperString[4].set(PinClicked)
        PinBB = "Clicked on " + PinClicked
    elif CursorX > INMinX and CursorX < INMaxX and CursorY > INMinY and CursorY < INMaxY:
        GridX = 1 + int((CursorX - INMinX) / XStep)
        PinClicked = "AINH" # default to
        if GridX == 1:
            PinClicked = "AINH"
        elif GridX == 4:
            PinClicked = "BINH"
        elif GridX == 6:
            PinClicked = "CINH"
        elif GridX == 8:
            PinClicked = "AWG1"
        elif GridX == 9:
            PinClicked = "AWG2"
        #
        CompString[0].set(PinClicked)
        PinBB = "Clicked on " + PinClicked
    else:
        PinBB = ""
    #
    if event.num == 1:
        click_loc.config(text = PinBB, font=("arial", FontSize, "bold"))
    elif event.num == 3:
        if BOMStatus.get() > 0:
            PinClicked = PinClicked + " "
            BOMtext.insert(INSERT, PinClicked)
##
def DestroyBreadboardScreen():
    global breadboardwindow, BreadboardStatus

    BreadboardStatus.set(0)
    breadboardwindow.destroy()
#
def MakeBOMScreen():
    global BOMwindow, BOMStatus, BOMtext, CPRevDate

    if BOMStatus.get() == 0:
        BOMStatus.set(1)
        ### Set the size and shape of the Placement window 
        BOMwindow = Toplevel()
        BOMwindow.title("Comp Placement " + CPRevDate)
        BOMwindow.protocol("WM_DELETE_WINDOW", DestroyBOMScreen)
        BOMwindow.resizable(TRUE,TRUE)
        #
        BOMwindow.configure(background=FrameBG, borderwidth=BorderSize)
        #
        BOMtext = scrolledtext.ScrolledText(BOMwindow, wrap=WORD, undo=True, maxundo=-1, font="arial")
        BOMtext.pack(expand=True, fill='both')
        #
        menubar = Menu(BOMwindow)
        BOMwindow.config(menu=menubar)

        file_menu = Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="New", command=TextNew_file)
        file_menu.add_command(label="Open", command=TextOpen_file)
        file_menu.add_command(label="Save", command=TextSave_file)
        file_menu.add_command(label="Save As...", command=TextSave_file_as)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=DestroyBOMScreen)
        
        command_menu = Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Commands", menu=command_menu)
        command_menu.add_command(label="Update Components", command=UpDateBOMScreen)
        command_menu.add_command(label="Merg Jumper Nets", command=MergNetList)
        command_menu.add_command(label="Send From Editor", command=ConfigCrossPointEditor)
        command_menu.add_command(label="Auto Placer", command=AutoPlacer)
#AutoPlacer()
def DestroyBOMScreen():
    global BOMwindow, BOMStatus

    BOMStatus.set(0)
    BOMwindow.destroy()
#
def DrawCompOval(Step, Xh1, Yh1, Xh2, Yh2, CmpName):
    global breadboard_canvas, BBFont, BBblack
    global TL1XY, BL1XY, TR1XY, BR1XY, JP1XY, JP9XY, AINHXY

    # draw oval around two pins?
    HStep = Step/2
    Deg = 270
    Xwidth = Step
    Ywidth = Step
    if Xh1 > 0 and Yh1 > 0 and Xh2 > 0 and Yh2 > 0:
        Xp1 = Xh1; Xp2 = Xh2
        Xcen = (Xh1 + Xh2)/2
        Ycen = (Yh1 + Yh2)/2
        if Yh1 == Yh2: # Hor comp?
            Xwidth = 0
            Ywidth = Step
            Deg = 0
            if Ycen < (BR1XY[1] * Step):
                if "Q" in CmpName or "M" in CmpName:
                    Yh1 = Yh2 = Ycen = (TL1XY[1] + 2) * Step # Center hole
                    breadboard_canvas.create_oval(Xcen-2, Yh1-2, Xcen+2, Yh1+2, outline="#a0a0a0", fill="#a0a0a0", width=1)
                else:
                    Yh1 = (TL1XY[1] + 2) * Step # 1, 3 One grid below top
                    Yh2 = (TL1XY[1] + 2) * Step #
                    Ycen = (Yh1 + Yh2)/2
            else:
                if "Q" in CmpName or "M" in CmpName:
                    Yh1 = Yh2 = Ycen = (BL1XY[1] + 2) * Step # Center hole
                    breadboard_canvas.create_oval(Xcen-2, Yh1-2, Xcen+2, Yh1+2, outline="#a0a0a0", fill="#a0a0a0", width=1)
                else:
                    Yh1 = (BR1XY[1] + 2) * Step # 3, 1 One grid above bottom
                    Yh2 = (BR1XY[1] + 2) * Step
                    Ycen = (Yh1 + Yh2)/2
            #
            if abs(Xh1 - Xh2) < (Step+HStep): # in adjacent col?
                if "C" in CmpName:
                    Xwidth = Step * 1.1
                else:
                    Xwidth = Step * 0.8
        elif Xh1 == Xh2: # Vert comp?:
            Xwidth = Step
            Ywidth = 0
        #
        SpLine = True
        if (Xh1 - Xh2) < 0 and (Yh1 - Yh2) < 0: # UL to LR
            Line1 = [Xh1, Yh1, Xcen+Xwidth, Ycen-Ywidth, Xh2, Yh2]
            Line2 = [Xh1, Yh1, Xcen-Xwidth, Ycen+Ywidth, Xh2, Yh2]
        elif (Xh1 - Xh2) > 0 and (Yh1 - Yh2) > 0: # LR to UL
            Line1 = [Xh1, Yh1, Xcen+Xwidth, Ycen-Ywidth, Xh2, Yh2]
            Line2 = [Xh1, Yh1, Xcen-Xwidth, Ycen+Ywidth, Xh2, Yh2]
        elif (Xh1 - Xh2) < 0 and (Yh1 - Yh2) > 0: # LL to UR
            Line1 = [Xh1, Yh1, Xcen+Xwidth, Ycen+Ywidth, Xh2, Yh2]
            Line2 = [Xh1, Yh1, Xcen-Xwidth, Ycen-Ywidth, Xh2, Yh2]
        elif (Xh1 - Xh2) > 0 and (Yh1 - Yh2) < 0: # UR to LL
            Line1 = [Xh1, Yh1, Xcen+Xwidth, Ycen+Ywidth, Xh2, Yh2]
            Line2 = [Xh1, Yh1, Xcen-Xwidth, Ycen-Ywidth, Xh2, Yh2]
        else:
            Line1 = [Xh1, Yh1, Xcen+Xwidth, Ycen+Ywidth, Xh2, Yh2]
            Line2 = [Xh1, Yh1, Xcen-Xwidth, Ycen-Ywidth, Xh2, Yh2]
        #
        if "R" in CmpName: # and Xh1 == Xh2:
            Ytop = min(Yh1, Yh2)
            Ybot = max(Yh1, Yh2)
            if (Xh1 - Xh2) < 0 and (Yh1 - Yh2) < 0: # UL to LR
                Xtop = min(Xh1, Xh2)
                Xbot = max(Xh1, Xh2)
            elif (Xh1 - Xh2) > 0 and (Yh1 - Yh2) > 0: # LR to UL
                Xtop = min(Xh1, Xh2)
                Xbot = max(Xh1, Xh2)
            elif (Xh1 - Xh2) < 0 and (Yh1 - Yh2) > 0: # LL to UR
                Xtop = max(Xh1, Xh2)
                Xbot = min(Xh1, Xh2)
            elif (Xh1 - Xh2) > 0 and (Yh1 - Yh2) < 0: # UR to LL
                Xtop = max(Xh1, Xh2)
                Xbot = min(Xh1, Xh2)
            else:
                Xtop = min(Xh1, Xh2)
                Xbot = max(Xh1, Xh2)
            Dx = abs(Xtop - Xbot)
            Dy = abs(Ytop - Ybot)
            Line1 = [Xtop,Ytop]
            if Dy > Dx: # More vert
                Line1.append(Xcen)
                Line1.append(Ytop)
                Line = [0,0.7, 0.4,0.9, -0.4,1.3, 0.4,1.7, -0.4,2.1, 0,2.3]
                for point in range ( 0, len(Line), 2):
                    Line1.append((Line[point] * Step) + Xcen)
                    Line1.append((Line[point+1] * Step) + Ytop)
                Line1.append(Xcen)
                Line1.append(Ybot)
                Line1.append(Xbot)
                Line1.append(Ybot)
            else: # More Horz
                Line = [0.7,0, 0.9,0.4, 1.3,-0.4, 1.7,0.4, 2.1,-0.4, 2.3,0]
                if Yh1 == Yh2:
                    Line1.append(Xtop)
                    Line1.append(Ytop-HStep)
                    for point in range ( 0, len(Line), 2):
                        Line1.append((Line[point] * Step) + Xtop)
                        Line1.append((Line[point+1] * Step) + Ycen - HStep)
                else:
                    Line1.append(Xtop)
                    Line1.append(Ycen)
                    for point in range ( 0, len(Line), 2):
                        Line1.append((Line[point] * Step) + Xtop)
                        Line1.append((Line[point+1] * Step) + Ycen)
                if Yh1 == Yh2:
                    Line1.append(Xbot)
                    Line1.append(Ybot-HStep)
                else:
                    Line1.append(Xbot)
                    Line1.append(Ycen)
                Line1.append(Xbot)
                Line1.append(Ybot)
            # print(Line1)
            Line2 = [Xh1, Yh1, Xh1, Yh1]
            SpLine = False
        elif "C" in CmpName: # and Xh1 == Xh2:
            Ytop = min(Yh1, Yh2)
            Ybot = max(Yh1, Yh2)
            if (Xh1 - Xh2) < 0 and (Yh1 - Yh2) < 0: # UL to LR
                Xtop = min(Xh1, Xh2)
                Xbot = max(Xh1, Xh2)
            elif (Xh1 - Xh2) > 0 and (Yh1 - Yh2) > 0: # LR to UL
                Xtop = min(Xh1, Xh2)
                Xbot = max(Xh1, Xh2)
            elif (Xh1 - Xh2) < 0 and (Yh1 - Yh2) > 0: # LL to UR
                Xtop = max(Xh1, Xh2)
                Xbot = min(Xh1, Xh2)
            elif (Xh1 - Xh2) > 0 and (Yh1 - Yh2) < 0: # UR to LL
                Xtop = max(Xh1, Xh2)
                Xbot = min(Xh1, Xh2)
            else:
                Xtop = min(Xh1, Xh2)
                Xbot = max(Xh1, Xh2)
            Dx = abs(Xtop - Xbot)
            Dy = abs(Ytop - Ybot)
            Line1 = [Xtop,Ytop]
            if Dy > Dx: # More vert
                Line1.append(Xcen)
                Line1.append(Ytop)
                Line = [0,1.3, 0.4,1.3, -0.4,1.3]
                for point in range ( 0, len(Line), 2):
                    Line1.append((Line[point] * Step) + Xcen)
                    Line1.append((Line[point+1] * Step) + Ytop)
                # print(Line1)
                Line2 = [Xbot, Ybot, Xcen, Ybot]
                Line = [0,1.7, 0.4,1.7, -0.4,1.7]
                for point in range ( 0, len(Line), 2):
                    Line2.append((Line[point] * Step) + Xcen)
                    Line2.append((Line[point+1] * Step) + Ytop)
            else: # More Horz
                Line = [1.3,0, 1.3,0.4, 1.3,-0.4]
                if Yh1 == Yh2:
                    Line1.append(Xtop)
                    Line1.append(Ytop-HStep)
                    for point in range ( 0, len(Line), 2):
                        Line1.append((Line[point] * Step) + Xtop)
                        Line1.append((Line[point+1] * Step) + Ycen - HStep)
                else:
                    Line1.append(Xtop)
                    Line1.append(Ycen)
                    for point in range ( 0, len(Line), 2):
                        Line1.append((Line[point] * Step) + Xtop)
                        Line1.append((Line[point+1] * Step) + Ycen)
                # print(Line1)
                Line2 = [Xbot, Ybot]
                Line = [1.7,0, 1.7,0.4, 1.7,-0.4]
                if Yh1 == Yh2:
                    Line2.append(Xbot)
                    Line2.append(Ybot-HStep)
                    for point in range ( 0, len(Line), 2):
                        Line2.append((Line[point] * Step) + Xtop)
                        Line2.append((Line[point+1] * Step) + Ycen - HStep)
                else:
                    Line2.append(Xbot)
                    Line2.append(Ycen)
                    for point in range ( 0, len(Line), 2):
                        Line2.append((Line[point] * Step) + Xtop)
                        Line2.append((Line[point+1] * Step) + Ycen)
            SpLine = False
        elif "D" in CmpName: # A end is Xh1, Yh1 
            Ytop = min(Yh1, Yh2)
            Ybot = max(Yh1, Yh2)
            if (Xh1 - Xh2) < 0 and (Yh1 - Yh2) < 0: # UL to LR
                Xtop = min(Xh1, Xh2)
                Xbot = max(Xh1, Xh2)
            elif (Xh1 - Xh2) > 0 and (Yh1 - Yh2) > 0: # LR to UL
                Xtop = min(Xh1, Xh2)
                Xbot = max(Xh1, Xh2)
            elif (Xh1 - Xh2) < 0 and (Yh1 - Yh2) > 0: # LL to UR
                Xtop = max(Xh1, Xh2)
                Xbot = min(Xh1, Xh2)
            elif (Xh1 - Xh2) > 0 and (Yh1 - Yh2) < 0: # UR to LL
                Xtop = max(Xh1, Xh2)
                Xbot = min(Xh1, Xh2)
            else:
                Xtop = min(Xh1, Xh2)
                Xbot = max(Xh1, Xh2)
            Dx = abs(Xtop - Xbot)
            Dy = abs(Ytop - Ybot)
            if Dy > Dx: # More vert
                if Yh1 < Yh2:
                    Line1 = [Xtop, Ytop, Xcen, Ytop]
                    Line2 = [Xbot, Ybot, Xcen, Ybot]
                    LineA = [0,1.0, 0.4,1.0, 0,1.8, -0.4,1.0, 0,1.0]
                    LineK = [0,1.8, 0.4,1.8, -0.4,1.8]
                else:
                    Line1 = [Xbot, Ybot, Xcen, Ybot]
                    Line2 = [Xtop, Ytop, Xcen, Ytop]
                    LineA = [0,1.8, 0.4,1.8, 0,1.0, -0.4,1.8, 0,1.8]
                    LineK = [0,1.0, 0.4,1.0, -0.4,1.0]
                for point in range ( 0, len(LineA), 2):
                    Line1.append((LineA[point] * Step) + Xcen)
                    Line1.append((LineA[point+1] * Step) + Ytop)
                for point in range ( 0, len(LineK), 2):
                    Line2.append((LineK[point] * Step) + Xcen)
                    Line2.append((LineK[point+1] * Step) + Ytop)
            else: # More Horz
                if Xh1 < Xh2:
                    Line1 = [Xtop, Ytop]
                    Line2 = [Xbot, Ybot]
                    LineA = [1.0,0, 1.0,0.4, 1.8,0, 1.0,-0.4, 1.0,0]
                    LineK = [1.8,0, 1.8,0.4, 1.8,-0.4]
                    if Yh1 == Yh2:
                        VertOff = HStep
                        Line1.append(Xtop)
                        Line1.append(Ytop-HStep)
                        Line2.append(Xbot)
                        Line2.append(Ybot-HStep)
                    else:
                        VertOff = 0
                        Line1.append(Xtop)
                        Line1.append(Ycen)
                        Line2.append(Xbot)
                        Line2.append(Ycen)
                else:
                    Line1 = [Xbot, Ybot]
                    Line2 = [Xtop, Ytop]
                    LineA = [1.8,0, 1.8,0.4, 1.0,0, 1.8,-0.4, 1.8,0]
                    LineK = [1.0,0, 1.0,0.4, 1.0,-0.4]
                    if Yh1 == Yh2:
                        VertOff = HStep
                        Line1.append(Xbot)
                        Line1.append(Ybot-HStep)
                        Line2.append(Xtop)
                        Line2.append(Ytop-HStep)
                    else:
                        VertOff = 0
                        Line1.append(Xbot)
                        Line1.append(Ycen)
                        Line2.append(Xtop)
                        Line2.append(Ycen)
                for point in range ( 0, len(LineA), 2):
                    Line1.append((LineA[point] * Step) + Xtop)
                    Line1.append((LineA[point+1] * Step) + Ycen - VertOff)
                for point in range ( 0, len(LineK), 2):
                    Line2.append((LineK[point] * Step) + Xtop)
                    Line2.append((LineK[point+1] * Step) + Ycen - VertOff)
            SpLine = False
        breadboard_canvas.create_line(Line1, smooth=SpLine, fill=BBblack, width=2)
        breadboard_canvas.create_line(Line2, smooth=SpLine, fill=BBblack, width=2)
        breadboard_canvas.create_oval(Xp1-2, Yh1-2, Xp1+2, Yh1+2, outline="#a0a0a0", fill="#a0a0a0", width=1)
        breadboard_canvas.create_oval(Xp2-2, Yh2-2, Xp2+2, Yh2+2, outline="#a0a0a0", fill="#a0a0a0", width=1)
        breadboard_canvas.create_text(Xcen, Ycen, text = CmpName, angle=Deg, fill="red", font=("arial", BBFont, "bold"))
#
def FindPowerRail(X1, X2, Y1, Y2, MidY, GrNum, Step, G):
    global TL1XY, BL1XY, TR1XY

    HStep = Step/2
    XL = (TL1XY[0] + 4) * Step
    XR = (TR1XY[0] + 12) * Step
    MidX = (XR + XL) / 2
    NX1 = NX2 = X1
    # Swap X1, X2 if X1 == 0
    if X1 == 0 and Y1 == 0:
        X1 = X2
        Y1 = Y2
        X2 = 0
        Y2 = 0
    # Set Y values
    if Y2 < MidY and Y2 > 0: # In Top resion
        NY2 = ((TL1XY[1] - 4 + G) * Step) + HStep
        NY1 = (TL1XY[1] * Step) # - HStep
    else:
        NY1 = ((BL1XY[1] + 4) * Step)
        NY2 = ((BL1XY[1] + 8 - G) * Step) # + HStep

    if Y1 < MidY and Y1 > 0: # In Bottom region
        NY2 = ((TL1XY[1] - 4 + G) * Step) + HStep
        NY1 = (TL1XY[1] * Step) # - HStep
    else:
        NY1 = ((BL1XY[1] + 4) * Step)
        NY2 = ((BL1XY[1] + 8 - G) * Step) # + HStep
    # determine X values
    if X1 > 0 and Y1 > 0: # Power wire BB holes always sent as X1, Y1
        NX1 = NX2 = X1
    # Check if Left of left edge or Right of right edge
        if GrNum == 16: # Check if falls on empty spot
            NX2 = NX2 + Step
        elif GrNum == 10 and NX2 < MidX:
            NX2 = NX2 + Step
        elif GrNum == 2:
            NX2 = NX2 - Step
        elif GrNum == 8 and NX2 > MidX:
            NX2 = NX2 - Step
        if NX2 < XL:
            NX2 = XL
        elif NX2 > XR:
            NX2 = XR
    #
    return(NX1, NX2, NY1, NY2)
#
def FindBBPin(xpin, Step): # Finds X Y of BB hole in pixels
    global TL1XY, BL1XY, TR1XY, BR1XY

    X1 = Y1 = GrNum = 0 # return 0 if we don't find a matching hole
    if "TL" in xpin:
        GrNum = eval(xpin.replace("TL",""))
        X1 = (TL1XY[0] + GrNum - 1) * Step
        Y1 = ((TL1XY[1] + 4 ) * Step) # + HStep
    if "BL" in xpin:
        GrNum = eval(xpin.replace("BL",""))
        X1 = (BL1XY[0] + GrNum - 1) * Step
        Y1 = (BL1XY[1] * Step) # + HStep
    if "TR" in xpin:
        GrNum = eval(xpin.replace("TR",""))
        X1 = (TR1XY[0] + GrNum - 1) * Step
        Y1 = ((TR1XY[1] + 4 ) * Step) # + HStep
    if "BR" in xpin:
        GrNum = eval(xpin.replace("BR",""))
        X1 = (BR1XY[0] + GrNum - 1) * Step
        Y1 = (BR1XY[1] * Step) # + HStep
    return(X1, Y1, GrNum)
#
def UpDateBOMScreen():
    global VPower, R_List, C_List, L_List, D_List, M_List, Q_List, U_List
    global U_Connections, VPowerConnections, VPower, UnRouted
    global ComponentList, BOMtext, BOMStatus, BBblack
    global BBwidth, BBheight, BBGridSize, breadboard_canvas, FontSize, BBFont
    global TL1XY, BL1XY, TR1XY, BR1XY, JP1XY, JP9XY, AINHXY

    if BOMStatus.get() == 0:
        return
    # Calculate Xstep and YStep size for 50 X 40 0.1" grid, 11 pixels per grid point?
    XStep = YStep = BBwidth/BBGridSize
    HStep = XStep/2
    MidY = (BL1XY[1] - 1) * XStep
    # Clear all text
    BOMtext.delete("1.0", END)
    # List resistors
    for R in range ( 0, len(R_List), 1):
        Rterm = R_List[R]
        Rname = Rterm[0]
        Rterm1 = Rterm[1]
        Rterm2 = Rterm[2]
        RValue = Rterm[3]
        #
        R_Line = Rname + " "
        xpin1 = xpin2 = ""
        Xh1 = Yh1 = Xh2 = Yh2 = GrNum = 0
        if ("TL" in Rterm1 ) or ("BL" in Rterm1) or ("TR" in Rterm1) or ("BR" in Rterm1):
            R_Line = R_Line + Rterm1 + " "
            Xh1, Yh1, GrNum = FindBBPin(Rterm1, XStep)
        if ("TL" in Rterm2 ) or ("BL" in Rterm2) or ("TR" in Rterm2) or ("BR" in Rterm2):
            R_Line = R_Line + Rterm2 + " "
            Xh2, Yh2, GrNum = FindBBPin(Rterm2, XStep)
        # print(Rterm1, " ", Rterm2)
        if Xh1 == 0 and Yh1 == 0 and Xh2 == 0 and Yh2 == 0: 
            for xp in range (0, len(ComponentList), 1 ):
                if "V" in Rterm1 or "0" == Rterm1:
                    pass
                elif Rterm1 in ComponentList[xp]:
                    CompPins = ComponentList[xp]
                    xpin1 = CompPins[0]
                    xpin1 = xpin1.replace("X","")
                    xpin1 = xpin1.replace(chr(167),"")# remove §
                    R_Line = R_Line + xpin1 + " "
                    if Xh1 == 0 and Yh1 == 0:
                        Xh1, Yh1, GrNum = FindBBPin(xpin1, XStep)
                if "V" in Rterm2 or "0" == Rterm2:
                    pass
                elif Rterm2 in ComponentList[xp]:
                    CompPins = ComponentList[xp]
                    xpin2 = CompPins[0]
                    xpin2 = xpin2.replace("X","")
                    xpin2 = xpin2.replace(chr(167),"")# remove §
                    R_Line = R_Line + xpin2 + " "
                    if Xh2 == 0 and Yh2 == 0:
                        Xh2, Yh2, GrNum = FindBBPin(xpin2, XStep)
        #
        if "V" in Rterm1:
            R_Line = R_Line + Rterm1 + " "
            Xh1, Xh2, Yh1, Yh2 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 0)
        if "V" in Rterm2:
            R_Line = R_Line + Rterm2 + " "
            Xh1, Xh2, Yh1, Yh2 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 0)
        if "0" == Rterm1 or "COM" == Rterm1 or "GND" == Rterm1:
            R_Line = R_Line + "GND "
            Xh1, Xh2, Yh1, Yh2 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 1)
        if "0" == Rterm2 or "COM" == Rterm2 or "GND" == Rterm2:
            R_Line = R_Line + "GND "
            Xh1, Xh2, Yh1, Yh2 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 1)
        #
        R_Line = R_Line + RValue
        BOMtext.insert(END, R_Line + '\n')
        DrawCompOval(XStep, Xh1, Yh1, Xh2, Yh2, Rname)
    # List capacitors
    for C in range ( 0, len(C_List), 1):
        Cterm = C_List[C]
        Cname = Cterm[0]
        Cterm1 = Cterm[1]
        Cterm2 = Cterm[2]
        CValue = Cterm[3]
        C_Line = Cname + " "
        xpin1 = xpin2 = ""
        Xh1 = Yh1 = Xh2 = Yh2 = 0
        if ("TL" in Cterm1 ) or ("BL" in Cterm1) or ("TR" in Cterm1) or ("BR" in Cterm1):
            C_Line = C_Line + Cterm1 + " "
            Xh1, Yh1, GrNum = FindBBPin(Cterm1, XStep)
        if ("TL" in Cterm2 ) or ("BL" in Cterm2) or ("TR" in Cterm2) or ("BR" in Cterm2):
            C_Line = C_Line + Cterm2 + " "
            Xh2, Yh2, GrNum = FindBBPin(Cterm2, XStep)
        # print(Cterm1[0], " ", Cterm2[0])
        if Xh1 == 0 and Yh1 == 0 and Xh2 == 0 and Yh2 == 0:
            for xp in range (0, len(ComponentList), 1 ):
                if "V" in Cterm1 or "0" == Cterm1:
                    donothing()
                elif Cterm1 in ComponentList[xp]:
                    CompPins = ComponentList[xp]
                    xpin1 = CompPins[0]
                    xpin1 = xpin1.replace("X","")
                    xpin1 = xpin1.replace(chr(167),"")# remove §
                    C_Line = C_Line + xpin1 + " "
                    if Xh1 == 0 and Yh1 == 0:
                        Xh1, Yh1, GrNum = FindBBPin(xpin1, XStep)
                if "V" in Cterm2 or "0" == Cterm2:
                    donothing()
                elif Cterm2 in ComponentList[xp]:
                    CompPins = ComponentList[xp]
                    xpin2 = CompPins[0]
                    xpin2 = xpin2.replace("X","")
                    xpin2 = xpin2.replace(chr(167),"")# remove §
                    C_Line = C_Line + xpin2 + " "
                    if Xh2 == 0 and Yh2 == 0:
                        Xh2, Yh2, GrNum = FindBBPin(xpin2, XStep)
        if "V" in Cterm1:
            C_Line = C_Line + Cterm1 + " "
            Xh1, Xh2, Yh1, Yh2 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 0)
        if "V" in Cterm2:
            C_Line = C_Line + Cterm2 + " "
            Xh1, Xh2, Yh1, Yh2 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 0)
        if "0" == Cterm1 or "COM" == Cterm1 or "GND" == Cterm1:
            C_Line = C_Line + "GND "
            Xh1, Xh2, Yh1, Yh2 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 1)
        if "0" == Cterm2 or "COM" == Cterm2 or "GND" == Cterm2:
            C_Line = C_Line + "GND "
            Xh1, Xh2, Yh1, Yh2 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 1)
        C_Line = C_Line + CValue
        BOMtext.insert(END, C_Line + '\n')
        DrawCompOval(XStep, Xh1, Yh1, Xh2, Yh2, Cname)
    # List inductors
    for L in range ( 0, len(L_List), 1):
        Lterm = L_List[L]
        Lname = Lterm[0]
        Lterm1 = Lterm[1]
        Lterm2 = Lterm[2]
        LValue = Lterm[3]
        L_Line = Lname + " "
        xpin1 = xpin2 = ""
        Xh1 = Yh1 = Xh2 = Yh2 = 0
        if ("TL" in Lterm1 ) or ("BL" in Lterm1) or ("TR" in Lterm1) or ("BR" in Lterm1):
            L_Line = L_Line + Lterm1 + " "
            Xh1, Yh1, GrNum = FindBBPin(Lterm1, XStep)
        if ("TL" in Lterm2 ) or ("BL" in Lterm2) or ("TR" in Lterm2) or ("BR" in Lterm2):
            L_Line = L_Line + Lterm2[0] + " "
            Xh2, Yh2, GrNum = FindBBPin(Lterm2, XStep)
        # print(Rterm1[0], " ", Rterm2[0])
        if Xh1 == 0 and Yh1 == 0 and Xh2 == 0 and Yh2 == 0:
            for xp in range (0, len(ComponentList), 1 ):
                if "V" in Lterm1 or "0" == Lterm1:
                    pass
                elif Lterm1 in ComponentList[xp]:
                    CompPins = ComponentList[xp]
                    xpin1 = CompPins[0]
                    xpin1 = xpin1.replace("X","")
                    xpin1 = xpin1.replace(chr(167),"")# remove §
                    L_Line = L_Line + xpin1 + " "
                    if Xh1 == 0 and Yh1 == 0:
                        Xh1, Yh1, GrNum = FindBBPin(xpin1, XStep)
                if "V" in Lterm2 or "0" == Lterm2:
                    pass
                elif Lterm2 in ComponentList[xp]:
                    CompPins = ComponentList[xp]
                    xpin2 = CompPins[0]
                    xpin2 = xpin2.replace("X","")
                    xpin2 = xpin2.replace(chr(167),"")# remove §
                    L_Line = L_Line + xpin2 + " "
                    if Xh2 == 0 and Yh2 == 0:
                        Xh2, Yh2, GrNum = FindBBPin(xpin2, XStep)
        if "V" in Lterm1:
            L_Line = L_Line + Lterm1 + " "
            Xh1, Xh2, Yh1, Yh2 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 0)
        if "V" in Lterm2:
            L_Line = L_Line + Lterm2 + " "
            Xh1, Xh2, Yh1, Yh2 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 0)
        if "0" == Lterm1 or "COM" == Lterm1 or "GND" == Lterm1:
            L_Line = L_Line + "GND "
            Xh1, Xh2, Yh1, Yh2 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 1)
        if "0" == Rterm2 or "COM" == Lterm2 or "GND" == Lterm2:
            L_Line = L_Line + "GND "
            Xh1, Xh2, Yh1, Yh2 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 1)
        L_Line = L_Line + LValue
        BOMtext.insert(END, L_Line + '\n')
        DrawCompOval(XStep, Xh1, Yh1, Xh2, Yh2, Lname)
    # List Diodes
    for D in range ( 0, len(D_List), 1):
        Dterm = D_List[D]
        Dname = Dterm[0]
        Dterm1 = Dterm[1]
        Dterm2 = Dterm[2]
        DValue = Dterm[3]
        D_Line = Dname + " "
        Polarity = "* "
        xpin1 = xpin2 = ""
        Xh1 = Yh1 = Xh2 = Yh2 = 0
        # print(Dterm)
        if ("TL" in Dterm1 ) or ("BL" in Dterm1) or ("TR" in Dterm1) or ("BR" in Dterm1):
            D_Line = D_Line + Dterm1 + " "
            Polarity = Polarity + "A " + Dterm1 + " "
            Xh1, Yh1, GrNum = FindBBPin(Dterm1, XStep)
            if "V" in Dterm2:
                D_Line = D_Line + Dterm2 + " "
                Xh1, Xh2, Yh1, Yh2 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 0)
            elif "0" == Dterm2 or "COM" == Dterm2 or "GND" == Dterm2:
                D_Line = D_Line + "GND "
                Xh1, Xh2, Yh1, Yh2 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 1)
            else:
                Xh2, Yh2, GrNum = FindBBPin(Dterm2, XStep)
                D_Line = D_Line + Dterm2 + " "
        elif ("TL" in Dterm2 ) or ("BL" in Dterm2) or ("TR" in Dterm2) or ("BR" in Dterm2):
            Polarity = Polarity + "K " + Dterm2 + " "
            Xh2, Yh2, GrNum = FindBBPin(Dterm2, XStep)
            if "V" in Dterm1:
                D_Line = D_Line + Dterm1 + " "
                Xh2, Xh1, Yh2, Yh1 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 0)
            if "0" == Dterm1 or "COM" == Dterm1 or "GND" == Dterm1:
                D_Line = D_Line + "GND "
                Xh2, Xh1, Yh2, Yh1 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 1)
            else:
                Xh1, Yh1, GrNum = FindBBPin(Dterm1, XStep)
                D_Line = D_Line + Dterm1 + " "
            D_Line = D_Line + Dterm2 + " "
        # 
        if Xh1 == 0 and Yh1 == 0 and Xh2 == 0 and Yh2 == 0:
            for xp in range (0, len(ComponentList), 1 ):
                if "V" in Dterm1 or "0" == Dterm1[0] or "GND" == Dterm1[0]:
                    pass
                elif Dterm1 in ComponentList[xp]:
                    CompPins = ComponentList[xp]
                    xpin1 = CompPins[0]
                    xpin1 = xpin1.replace("X","")
                    xpin1 = xpin1.replace(chr(167),"")# remove §
                    Polarity = Polarity + "A " + xpin1 + " "
                    D_Line = D_Line + xpin1 + " "
                    if Xh1 == 0 and Yh1 == 0:
                        Xh1, Yh1, GrNum = FindBBPin(xpin1, XStep)
                    if "V" in Dterm2:
                        D_Line = D_Line + Dterm2 + " "
                        Xh1, Xh2, Yh1, Yh2 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 0)
                    if "0" == Dterm2 or "COM" == Dterm2 or "GND" == Dterm2:
                        D_Line = D_Line + "GND "
                        Xh1, Xh2, Yh1, Yh2 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 1)
                if "V" in Dterm2 or "0" == Dterm2 or "GND" == Dterm2:
                    pass
                elif Dterm2 in ComponentList[xp]:
                    CompPins = ComponentList[xp]
                    xpin2 = CompPins[0]
                    xpin2 = xpin2.replace("X","")
                    xpin2 = xpin2.replace(chr(167),"")# remove §
                    Polarity = Polarity + "K " + xpin2 + " "
                    if Xh2 == 0 and Yh2 == 0:
                        Xh2, Yh2, GrNum = FindBBPin(xpin2, XStep)
                    if "V" in Dterm1:
                        D_Line = D_Line + Dterm1 + " "
                        Xh2, Xh1, Yh2, Yh1 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 0)
                    if "0" == Dterm1 or "COM" == Dterm1 or "GND" == Dterm1:
                        D_Line = D_Line + "GND "
                        Xh2, Xh1, Yh2, Yh1 = FindPowerRail(Xh1, Xh2, Yh1, Yh2, MidY, GrNum, XStep, 1)
                    D_Line = D_Line + xpin2 + " "
        D_Line = D_Line + Polarity
        BOMtext.insert(END, D_Line + '\n')
        DrawCompOval(XStep, Xh1, Yh1, Xh2, Yh2, Dname)
    # List MOS Transistors
    for M in range ( 0, len(M_List), 1):
        Mterm = M_List[M]
        Mname = Mterm[0]
        Mterm1 = Mterm[1]
        Mterm2 = Mterm[2]
        Mterm3 = Mterm[3]
        M_Line = Mname + " "
        Polarity = "* "
        # print(Mterm, " ", M_Line)
        xpin1 = xpin2 = xpin3 = ""
        Xh1 = Yh1 = Xh2 = Yh2 = Xh3 = Yh3 = 0
        if ("TL" in Mterm1 ) or ("BL" in Mterm1) or ("TR" in Mterm1) or ("BR" in Mterm1):
            M_Line = M_Line + Mterm1 + " "
            Polarity = Polarity + "D " + Mterm1 + " "
            Xh1, Yh1, GrNum = FindBBPin(Mterm1, XStep)
        if ("TL" in Mterm2 ) or ("BL" in Mterm2) or ("TR" in Mterm2) or ("BR" in Mterm2):
            M_Line = M_Line + Mterm2 + " "
            Polarity = Polarity + "G " + Mterm2 + " "
            Xh2, Yh2, GrNum = FindBBPin(Mterm2, XStep)
        if ("TL" in Mterm3 ) or ("BL" in Mterm3) or ("TR" in Mterm3) or ("BR" in Mterm3):
            M_Line = M_Line + Mterm3 + " "
            Polarity = Polarity + "S " + Mterm3 + " "
            Xh3, Yh3, GrNum = FindBBPin(Mterm3, XStep)
        if Xh1 == 0 and Yh1 == 0 and Xh2 == 0 and Yh2 == 0 and Xh3 == 0 and Yh3 == 0:
            for xp in range (0, len(ComponentList), 1 ):
                if "V" in Mterm1 or "0" == Mterm1:
                    pass
                elif Mterm1 in ComponentList[xp]:
                    CompPins = ComponentList[xp]
                    xpin1 = CompPins[0]
                    xpin1 = xpin1.replace("X","")
                    xpin1 = xpin1.replace(chr(167),"")# remove §
                    Polarity = Polarity + "D " + xpin1 + " "
                    M_Line = M_Line + xpin1 + " "
                    if Xh1 == 0 and Yh1 == 0:
                        Xh1, Yh1, GrNum = FindBBPin(xpin1, XStep)
                if "V" in Mterm2 or "0" == Mterm2:
                    pass
                elif Mterm2 in ComponentList[xp]:
                    CompPins = ComponentList[xp]
                    xpin2 = CompPins[0]
                    xpin2 = xpin2.replace("X","")
                    xpin2 = xpin2.replace(chr(167),"")# remove §
                    Polarity = Polarity + "G " + xpin2 + " "
                    M_Line = M_Line + xpin2 + " "
                    if Xh2 == 0 and Yh2 == 0:
                        Xh2, Yh2, GrNum = FindBBPin(xpin2, XStep)
                if "V" in Mterm3 or "0" == Mterm3:
                    pass
                elif Mterm3 in ComponentList[xp]:
                    CompPins = ComponentList[xp]
                    xpin3 = CompPins[0]
                    xpin3 = xpin3.replace("X","")
                    xpin3 = xpin3.replace(chr(167),"")# remove §
                    Polarity = Polarity + "S " + xpin3 + " "
                    M_Line = M_Line + xpin3 + " "
                    if Xh3 == 0 and Yh3 == 0:
                        Xh3, Yh3, GrNum = FindBBPin(xpin3, XStep)
        if "V" in Mterm1:
            M_Line = M_Line + Mterm1 + " "
            Xh1 = Xh2 - XStep
            Yh1 = Yh2 # + XStep
        if "V" in Mterm2:
            M_Line = M_Line + Mterm2 + " "
        if "V" in Mterm3:
            M_Line = M_Line + Mterm3 + " "
            Xh3 = Xh2 + XStep
            Yh3 = Yh2 # + XStep
        if "0" == Mterm1 or "COM" == Mterm1 or "GND" == Mterm1:
            M_Line = M_Line + "GND "
            Xh1 = Xh2 - XStep
            Yh1 = Yh2 # + XStep
        if "0" == Mterm2 or "COM" == Mterm2 or "GND" == Mterm2:
            M_Line = M_Line + "GND "
        if "0" == Mterm3 or "COM" == Mterm3 or "GND" == Mterm3:
            M_Line = M_Line + "GND "
            Xh3 = Xh2 - XStep
            Yh3 = Yh2 # + XStep
        M_Line = M_Line + Polarity
        BOMtext.insert(END, M_Line + '\n')
        Xm = max([Xh1, Xh2, Xh3])
        Ym = max([Yh1, Yh2, Yh3])
        Xn = min([Xh1, Xh2, Xh3])
        Yn = min([Yh1, Yh2, Yh3])
        #
        DrawCompOval(XStep, Xm, Ym, Xn, Yn, Mname)
    # List Q BJTs
    for Q in range ( 0, len(Q_List), 1):
        Qterm = Q_List[Q]
        Qname = Qterm[0]
        Qterm1 = Qterm[1]
        Qterm2 = Qterm[2]
        Qterm3 = Qterm[3]
        Qterm4 = Qterm[4]
        Qvalue = Qterm[5]
        Q_Line = Qname + " "
        Polarity = "* "
        # print(Rterm1[0], " ", Rterm2[0])
        xpin1 = xpin2 = xpin3 = ""
        Xh1 = Yh1 = Xh2 = Yh2 = Xh3 = Yh3 = 0
        if ("TL" in Qterm1 ) or ("BL" in Qterm1) or ("TR" in Qterm1) or ("BR" in Qterm1):
            Q_Line = Q_Line + Qterm1 + " "
            Polarity = Polarity + "C " + Qterm1 + " "
            Xh1, Yh1, GrNum = FindBBPin(Qterm1, XStep)
        if ("TL" in Qterm2 ) or ("BL" in Qterm2) or ("TR" in Qterm2) or ("BR" in Qterm2):
            Q_Line = Q_Line + Qterm2 + " "
            Polarity = Polarity + "B " + Qterm2 + " "
            Xh2, Yh2, GrNum = FindBBPin(Qterm2, XStep)
        if ("TL" in Qterm3 ) or ("BL" in Qterm3) or ("TR" in Qterm3) or ("BR" in Qterm3):
            Q_Line = Q_Line + Qterm3 + " "
            Polarity = Polarity + "E " + Qterm3 + " "
            Xh3, Yh3, GrNum = FindBBPin(Qterm3, XStep)
        if Xh1 == 0 and Yh1 == 0 and Xh2 == 0 and Yh2 == 0 and Xh3 == 0 and Yh3 == 0:
            for xp in range (0, len(ComponentList), 1 ):
                if "V" in Qterm1 or "0" == Qterm1:
                    pass
                if Qterm1 in ComponentList[xp]:
                    CompPins = ComponentList[xp]
                    xpin1 = CompPins[0]
                    xpin1 = xpin1.replace("X","")
                    xpin1 = xpin1.replace(chr(167),"")# remove §
                    Polarity = Polarity + "C " + xpin1 + " "
                    Q_Line = Q_Line + xpin1 + " "
                    if Xh1 == 0 and Yh1 == 0:
                        Xh1, Yh1, GrNum = FindBBPin(xpin1, XStep)
                if "V" in Qterm2 or "0" == Qterm2:
                    pass
                elif Qterm2 in ComponentList[xp]:
                    CompPins = ComponentList[xp]
                    xpin2 = CompPins[0]
                    xpin2 = xpin2.replace("X","")
                    xpin2 = xpin2.replace(chr(167),"")# remove §
                    Polarity = Polarity + "B " + xpin2 + " "
                    Q_Line = Q_Line + xpin2 + " "
                    if Xh2 == 0 and Yh2 == 0:
                        Xh2, Yh2, GrNum = FindBBPin(xpin2, XStep)
                if "V" in Qterm3 or "0" == Qterm3:
                    pass
                elif Qterm3 in ComponentList[xp]:
                    CompPins = ComponentList[xp]
                    xpin3 = CompPins[0]
                    xpin3 = xpin3.replace("X","")
                    xpin3 = xpin3.replace(chr(167),"")# remove §
                    Polarity = Polarity + "E " + xpin3 + " "
                    Q_Line = Q_Line + xpin3 + " "
                    if Xh3 == 0 and Yh3 == 0:
                        Xh3, Yh3, GrNum = FindBBPin(xpin3, XStep)
        if "V" in Qterm1:
            Q_Line = Q_Line + Qterm1 + " "
            Xh1 = Xh2 - XStep
            Yh1 = Yh2 # + XStep
        if "V" in Qterm2:
            Q_Line = Q_Line + Qterm2 + " "
        if "V" in Qterm3:
            Xh3 = Xh2 + XStep
            Yh3 = Yh2 # + XStep
            Q_Line = Q_Line + Qterm3 + " "
        if "0" == Qterm1 or "COM" == Qterm1 or "GND" == Qterm1:
            Q_Line = Q_Line + "GND "
            Xh1 = Xh2 - XStep
            Yh1 = Yh2 # + XStep
        if "0" == Qterm2 or "COM" == Qterm2 or "GND" == Qterm2:
            Q_Line = Q_Line + "GND "
        if "0" == Qterm3 or "COM" == Qterm3 or "GND" == Qterm3:
            Q_Line = Q_Line + "GND "
            Xh3 = Xh2 + XStep
            Yh3 = Yh2 # + XStep
        Q_Line = Q_Line + Qvalue + " " + Polarity
        BOMtext.insert(END, Q_Line + '\n')
        # print(Xh1, Yh1, Xh2, Yh2, Xh3, Yh3, Q_List[Q])
        Xm = max([Xh1, Xh2, Xh3])
        Ym = max([Yh1, Yh2, Yh3])
        Xn = min([Xh1, Xh2, Xh3])
        Yn = min([Yh1, Yh2, Yh3])
        #
        DrawCompOval(XStep, Xm, Ym, Xn, Yn, Qname)
    # List U ICs
    for U in range ( 0, len(U_List), 1):
        Uterm = U_List[U]
        # U_Line = U_List[U]
        CmpName = U_List[U][0]
        CmpName = CmpName.replace("X","")
        CmpName = CmpName.replace(chr(167),"")# remove §
        U_Line = CmpName + " "
        #
        xpin = ""
        Xm = Ym = 0
        Xn = Yn = BBheight
        for trm in range(0, len(Uterm), 1):
            Uterm1 = Uterm[trm]
            if ("TL" in Uterm1 ) or ("BL" in Uterm1) or ("TR" in Uterm1) or ("BR" in Uterm1):
                U_Line = U_Line + Uterm1 + " "
                if "TL" in Uterm1:
                    GrNum = eval(Uterm1.replace("TL",""))
                    Xh1 = (TL1XY[0] + GrNum - 1) * XStep
                    Yh1 = ((TL1XY[1] + 4 ) * XStep) # + HStep
                    breadboard_canvas.create_oval(Xh1-2, Yh1-2, Xh1+2, Yh1+2, outline="#a0a0a0", fill="#a0a0a0", width=1)
                    Xm = int(max([Xh1, Xm]))
                    Ym = int(max([Yh1, Ym]))
                    Xn = int(min([Xh1, Xn]))
                    Yn = int(min([Yh1, Yn]))
                if "BL" in Uterm1:
                    GrNum = eval(Uterm1.replace("BL",""))
                    Xh1 = (BL1XY[0] + GrNum - 1) * XStep
                    Yh1 = (BL1XY[1] * XStep) + XStep
                    breadboard_canvas.create_oval(Xh1-2, Yh1-2, Xh1+2, Yh1+2, outline="#a0a0a0", fill="#a0a0a0", width=1)
                    Xm = int(max([Xh1, Xm]))
                    Ym = int(max([Yh1, Ym]))
                    Xn = int(min([Xh1, Xn]))
                    Yn = int(min([Yh1, Yn]))
                if "TR" in Uterm1:
                    GrNum = eval(Uterm1.replace("TR",""))
                    Xh1 = (TR1XY[0] + GrNum - 1) * XStep
                    Yh1 = ((TR1XY[1] + 4 ) * XStep) # + HStep
                    breadboard_canvas.create_oval(Xh1-2, Yh1-2, Xh1+2, Yh1+2, outline="#a0a0a0", fill="#a0a0a0", width=1)
                    Xm = int(max([Xh1, Xm]))
                    Ym = int(max([Yh1, Ym]))
                    Xn = int(min([Xh1, Xn]))
                    Yn = int(min([Yh1, Yn]))
                if "BR" in Uterm1:
                    GrNum = eval(Uterm1.replace("BR",""))
                    Xh1 = (BR1XY[0] + GrNum - 1) * XStep
                    Yh1 = (BR1XY[1] * XStep) + XStep
                    breadboard_canvas.create_oval(Xh1-2, Yh1-2, Xh1+2, Yh1+2, outline="#a0a0a0", fill="#a0a0a0", width=1)
                    Xm = int(max([Xh1, Xm]))
                    Ym = int(max([Yh1, Ym]))
                    Xn = int(min([Xh1, Xn]))
                    Yn = int(min([Yh1, Yn]))
            else:
                for xp in range (0, len(ComponentList), 1 ):
                    if Uterm1 in ComponentList[xp]:
                        CompPins = ComponentList[xp]
                        xpin1 = CompPins[0]
                        xpin1 = xpin1.replace("X","")
                        xpin1 = xpin1.replace(chr(167),"")# remove §
                        U_Line = U_Line + xpin1 + " "
                        Xh1, Yh1, GrNum = FindBBPin(xpin1, XStep)
                        Xm = int(max([Xh1, Xm]))
                        Ym = int(max([Yh1, Ym]))
                        Xn = int(min([Xh1, Xn]))
                        Yn = int(min([Yh1, Yn]))
        if Xm == 0 and Ym == 0 and Xn == BBheight and Yn == BBheight:   
            for xp in range (0, len(ComponentList), 1 ):
                for trm in range(0, len(Uterm), 1):
                    Uterm1 = Uterm[trm]
                    if Uterm1 in ComponentList[xp]:
                        CompPins = ComponentList[xp]
                        xpin = CompPins[0]
                        xpin = xpin.replace("X","")
                        xpin = xpin.replace(chr(167),"")# remove §
                        U_Line = U_Line + xpin + " "
                        if "TL" in xpin:
                            GrNum = eval(xpin.replace("TL",""))
                            Xh1 = (TL1XY[0] + GrNum - 1) * XStep
                            Yh1 = ((TL1XY[1] + 4 ) * XStep) # + HStep
                            breadboard_canvas.create_oval(Xh1-2, Yh1-2, Xh1+2, Yh1+2, outline="#a0a0a0", fill="#a0a0a0", width=1)
                            Xm = int(max([Xh1, Xm]))
                            Ym = int(max([Yh1, Ym]))
                            Xn = int(min([Xh1, Xn]))
                            Yn = int(min([Yh1, Yn]))
                        if "BL" in xpin:
                            GrNum = eval(xpin.replace("BL",""))
                            Xh1 = (BL1XY[0] + GrNum - 1) * XStep
                            Yh1 = (BL1XY[1] * XStep) # + XStep
                            breadboard_canvas.create_oval(Xh1-2, Yh1-2, Xh1+2, Yh1+2, outline="#a0a0a0", fill="#a0a0a0", width=1)
                            Xm = int(max([Xh1, Xm]))
                            Ym = int(max([Yh1, Ym]))
                            Xn = int(min([Xh1, Xn]))
                            Yn = int(min([Yh1, Yn]))
                        if "TR" in xpin:
                            GrNum = eval(xpin.replace("TR",""))
                            Xh1 = (TR1XY[0] + GrNum - 1) * XStep
                            Yh1 = ((TR1XY[1] + 4 ) * XStep) # + HStep
                            breadboard_canvas.create_oval(Xh1-2, Yh1-2, Xh1+2, Yh1+2, outline="#a0a0a0", fill="#a0a0a0", width=1)
                            Xm = int(max([Xh1, Xm]))
                            Ym = int(max([Yh1, Ym]))
                            Xn = int(min([Xh1, Xn]))
                            Yn = int(min([Yh1, Yn]))
                        if "BR" in xpin:
                            GrNum = eval(xpin.replace("BR",""))
                            Xh1 = (BR1XY[0] + GrNum - 1) * XStep
                            Yh1 = (BR1XY[1] * XStep) # + XStep
                            breadboard_canvas.create_oval(Xh1-2, Yh1-2, Xh1+2, Yh1+2, outline="#a0a0a0", fill="#a0a0a0", width=1)
                            Xm = int(max([Xh1, Xm]))
                            Ym = int(max([Yh1, Ym]))
                            Xn = int(min([Xh1, Xn]))
                            Yn = int(min([Yh1, Yn]))
#
        BOMtext.insert(END, U_Line + '\n')
        Xcen = int((Xm + Xn) / 2)
        Ycen = int((Ym + Yn) / 2)
        breadboard_canvas.create_rectangle(Xm+HStep, Ym+4, Xn-HStep, Yn-4, outline="black", width=2)
        breadboard_canvas.create_text(Xcen, Ycen, text = CmpName , fill=BBblack, font=("arial", BBFont, "bold"))
    # Place any UnRouted fly wires
    if len(UnRouted) > 0:
        # print(UnRouted)
        for fw in range ( 0, len(UnRouted), 1):
            UcNode = UnRouted[fw]
            matching_indices = [index for index, item in enumerate(UnRouted) if UcNode[0] in item]
            # print(matching_indices)
            Nd1 = matching_indices[0]
            Nd2 = matching_indices[1]
            xpin1 = UnRouted[Nd1][1]
            xpin2 = UnRouted[Nd2][1]
            Xh1, Yh1, GrNum = FindBBPin(xpin1, XStep)
            Xh2, Yh2, GrNum = FindBBPin(xpin2, XStep)
            # print(Xh1, Yh1, Xh2, Yh2)
            if Yh1 == Yh2: # Horizontal shift one hole up or down
                if Yh1 < MidY:
                    Yh1 = Yh1 - XStep
                    Yh2 = Yh2 - XStep
                else:
                    Yh1 = Yh1 + XStep
                    Yh2 = Yh2 + XStep
                Ycen = int((Yh1 + Yh2) / 2) - XStep
                Xcen = int((Xh1 + Xh2) / 2)
            elif Xh1 == Xh2: # Vert
                Ycen = int((Yh1 + Yh2) / 2)
                Xcen = int((Xh1 + Xh2) / 2) + XStep
            else:
                Ycen = int((Yh1 + Yh2) / 2) - XStep
                Xcen = int((Xh1 + Xh2) / 2) + XStep
            line = [Xh1, Yh1, Xcen, Ycen, Xh2, Yh2]
            breadboard_canvas.create_line(line, smooth=True, fill="green", width=4)
            breadboard_canvas.create_oval(Xh1-2, Yh1-2, Xh1+2, Yh1+2, outline="#a0a0a0", fill="#a0a0a0", width=1)
            breadboard_canvas.create_oval(Xh2-2, Yh2-2, Xh2+2, Yh2+2, outline="#a0a0a0", fill="#a0a0a0", width=1)
        #
#
def DestroyMatrixScreen():
    global matrixwindow, MatrixStatus
    
    MatrixStatus.set(0)
    matrixwindow.destroy()
#
# M2k Data capture Stuff
#
# Set Scope Sample Rate based on Horz Time Scale
#
def SetSampleRate():
    global TimeSpan, MaxSampleRate, SHOWsamples, InterpRate, Tdiv, GRW
    global TrigSource, TriggerEdge, TriggerInt, SAMPLErate, TimeDiv, ser

    OldShowSamples = SHOWsamples
    TimeDiv = UnitConvert(TMsb.get())
    # see if time base hase changed and adjust gain corrections
    TryRate = (GRW)/(10*TimeDiv)
    #print("TimeDiv = ", TimeDiv)
    #print("TryRate = ", TryRate)
    #print("SAMPLErate = ", SAMPLErate)
    if TryRate <= 1000:
        NewSAMPLErate = 1000
    elif TryRate > 1000 and TryRate <= 10000:
        NewSAMPLErate = 10000
    elif TryRate > 10000 and TryRate <= 100000:
        NewSAMPLErate = 100000
    elif TryRate > 100000 and TryRate <= 1000000:
        NewSAMPLErate = 1000000
    elif TryRate > 1000000 and TryRate <= 10000000:
        NewSAMPLErate = 10000000
    elif TryRate > 10000000:
        NewSAMPLErate = 100000000
    if NewSAMPLErate != SAMPLErate:
        SAMPLErate = NewSAMPLErate
        #print("Set SAMPLErate = ", SAMPLErate)
        ain.setSampleRate(SAMPLErate)
#
def Get_Data():
    global ain, aout, ctx, trig, Wait, TimeDiv, SHOWsamples
    global ShowC1_V, ShowC2_V, ShowC3_V, ShowC4_V
    global TgInput, VBuffA, VBuffB # , VBuffC, VBuffD, VBuffG
    global D0_is_on, D1_is_on, D2_is_on, D3_is_on
    global D4_is_on, D5_is_on, D6_is_on, D7_is_on, COLORtrace8
    global DBuff0, DBuff1, DBuff2, DBuff3, DBuff4, DBuff5, DBuff6, DBuff7
    global D0line, D1line, D2line, D3line, D4line, D5line, D6line, D7line
    global TRIGGERentry, TRIGGERsample, SaveDig, CHANNELS, TRACESread
    global OldCH1pdvRange, OldCH2pdvRange, CH1pdvRange, CH2pdvRange
    global CHAsb, CHBsb

    # Get data from M2k
##    if hldn+hozpos > MaxSamples-twoscreens:
##        hldn = MaxSamples-twoscreens-hozpos
##        HoldOffentry.delete(0,END)
##        HoldOffentry.insert(0, hldn*1000/SAMPLErate)
    #
    if SAMPLErate == 1000:
        SHOWsamples = 4096
    elif SAMPLErate == 10000:
        SHOWsamples = 8192
    else:
        SHOWsamples = 8192 # twoscreens + hldn + hozpos
    if SHOWsamples > MaxSamples: # or a Max of 16,384 samples
        SHOWsamples = MaxSamples
    if SHOWsamples < MinSamples: # or a Min of 1000 samples
        SHOWsamples = MinSamples
    #
    twoscreens = int(SAMPLErate * 20.0 * TimeDiv / 1000.0) # number of samples to acquire, 2 screen widths
    onescreen = int(twoscreens/2)
    #
    # get the vertical ranges
    try:
        CH1pdvRange = UnitConvert(CHAsb.get()) # float(eval(CHAsb.get()))
    except:
        CHAsb.delete(0,END)
        CHAsb.insert(0, CH1pdvRange)
    try:
        CH2pdvRange = UnitConvert(CHBsb.get()) # float(eval(CHBsb.get()))
    except:
        CHBsb.delete(0,END)
        CHBsb.insert(0, CH2pdvRange)
    if CH1pdvRange < 1.0:
        if OldCH1pdvRange != CH1pdvRange:
            ain.setRange(0,-2.5,2.5)
    else:
        if OldCH1pdvRange != CH1pdvRange:
            ain.setRange(0,-25,25)
    if CH2pdvRange < 1.0:
        if OldCH2pdvRange != CH2pdvRange:
            ain.setRange(1,-2.5,2.5)
    else:
        if OldCH2pdvRange != CH2pdvRange:
            ain.setRange(1,-25,25)
    OldCH1pdvRange = CH1pdvRange
    OldCH2pdvRange = CH2pdvRange
    #
    try:
        ADsignal1 = ain.getSamples(SHOWsamples) # read the buffer
        #
        VBuffA = ADsignal1[0] # make the V Buff array for trace A
        VBuffB = ADsignal1[1] # make the V Buff array for trace B
        SHOWsamples = len(VBuffA)
        VBuffA = numpy.array(VBuffA)
        VBuffB = numpy.array(VBuffB)
        VBuffA = (VBuffA - InOffA) * InGainA
        VBuffB = (VBuffB - InOffB) * InGainB
        TRACESread = 2
    except:
        ain.flushBuffer()
        Is_Triggered = 0
        ADsignal1 = []
    time.sleep(Wait)
# 
def Get_Buffer():
    global Wait, ser, MaxSampleRate, InterpRate, SAMPLErate
    global ABuff, iterCount, SampleTime, MinSamples, TRACESread
    
    time.sleep(Wait)
#
## Hardware specific Fucntion to close and exit ALICE
def Bcloseexit():
    global RUNstatus, Closed, core, ana_out, dev, ser, ConfigFileName
    
    RUNstatus.set(0)
    Closed = 1
    # 
    try:
        # try to write last config file, Don't crash if running in Write protected space
        BSaveConfig(ConfigFileName)
        # close context and exit
        try:
            aout.enableChannel(0, False)
            aout.enableChannel(1, False)
            libm2k.contextClose(ctx) # deviceClose(ctx)
        except:
            print("closing anyway")
            # exit
    except:
        donothing()

    root.destroy()
    exit()
#
#
def only_numerics(seq):
    seq_type= type(seq)
    return seq_type().join(filter(seq_type.isdigit, seq))
#
## try to connect to M2k
#
def ConnectDevice():
    global ctx, ain, aout, trig, DevID, bcon, FWRev, HWRev, UserPS, ProductName
    global ain, aout, trig, dig, AWGASampleRate, AWGBSampleRate
    global CH1Probe, CH2Probe, CH1VRange, CH2VRange, TimeDiv, TimeDivStr
    global CHAsb, CHBsb, TMsb, EnableInterpFilter, InterpRate
    global TgInput, TgEdge, TRIGGERlevel, TRIGGERentry, TriggerChannel, TriggerEdge

    if DevID == "No Device" or DevID == "M2k":
        #
        # Setup M2k instrument
        ctx=libm2k.m2kOpen('ip:m2k.local')
        # the uri can be something similar to: "ip:192.168.2.1" or "usb:1.6.5"
##        ProductName = ctx.getContextAttributeValue('usb,product')
##        # ProductName = ctx.getContextAttributeValue('product')
##        try:
##            ProductName = ctx.getContextAttributeValue('usb,product')
##        except:
##            print('No Device plugged IN!')
##            ProductName = "No Device"
##            bcon.configure(text="Recon", style="RConn.TButton")
##            return
##        if ProductName != 'M2k (ADALM-2000)':
##            print('M2K board not found!')
##            print(ProductName, " Found")
##            DevID = "No Device"
##            bcon.configure(text="Recon", style="RConn.TButton")
##            return
        bcon.configure(text="Conn",  style="GConn.TButton")
        DevID = ctx.getContextAttributeValue('hw_serial')
        print(DevID)
        HWRev = ctx.getContextAttributeValue('hw_model')
        if "M2k" in HWRev:
            DevID = "M2k"
        print(HWRev)
        FWRev = ctx.getContextAttributeValue('fw_version')
        print(FWRev)
    
    # define analog inputs and outputs
        ain=ctx.getAnalogIn()
        aout=ctx.getAnalogOut()
        trig=ain.getTrigger()
    #
        ain.reset()
        aout.reset()
    #
        ain.setKernelBuffersCount(1) # added line here
        ain.enableChannel(0,True)
        ain.enableChannel(1,True)
        ain.setSampleRate(100000)
        ain.setRange(0,-2,2)

    ##    trig.setAnalogSource(0) # Channel 0 as source
    ##    trig.setAnalogCondition(0,libm2k.RISING_EDGE_ANALOG) # RISING_EDGE)
    ##    trig.setAnalogLevel(0,0.5)  # Set trigger level at 0.5
    ##    trig.setAnalogDelay(0) # Trigger is centered
    ##    trig.setAnalogMode(1,libm2k.ANALOG)

        aout.setSampleRate(0, AWGSampleRate)
        aout.setSampleRate(1, AWGSampleRate)
        aout.enableChannel(0, True)
        aout.enableChannel(1, True)
    # User power supply
        UserPS = ctx.getPowerSupply()

    # Digital Input / OutPut channels
        dig=ctx.getDigital()

        dig.setSampleRateIn(10000)
        DigIOSetUp()

    # Digital patten generator output stuff
        dig.setSampleRateOut(10000)
        # make a temp digital pattern buffer
        # DigBuff0 = iio.Buffer(Dig_Out, 8192, True)
        #
        SAMPLErate = (2048 / TimeSpan)*2 # 2 screens of samples
        if TriggerChannel == "CH1":
            TgInput.set(1)
        else:
            TgInput.set(2)
        if TriggerEdge == "RISE":
            TgEdge.set(0)
        else:
            TgEdge.set(1)
        # print(dev)
        # bcon.configure(text="Conn", style="GConn.TButton")
        EnableInterpFilter.set(1)
        # make cross point control screen
        PlaceUSPower()
        time.sleep(0.01)
        BPlusOnOff() # Power up matrix chips
        BNegOnOff()
        time.sleep(0.01)
    # do a self calibration
        adc_calib=ctx.calibrateADC()
        dac_calib=ctx.calibrateDAC()
        # ResetMatrix() # Reset all cross point switches to open
        ######
        MakeBreadboardScreen()
        ######
        return(True) # return a logical true if sucessful!
    else:
        ######
        MakeBreadboardScreen()
        ######
        return(False)
#
# M2k AWG stuff
#
def SetAwgSampleRate():
    global AWGASampleRate, AWGBSampleRate, AWGSampleRate

    SetAwgASampleRate()
    SetAwgBSampleRate()
    AWGSampleRate = AWGASampleRate
    if AWGASampleRate >= AWGBSampleRate:
        AWGSampleRate = AWGASampleRate
    else:
        AWGSampleRate = AWGBSampleRate
#
def SetAwgASampleRate():
    global aout, AWGAFreqEntry, AWGAFreqvalue, AWGASampleRate

    try:
        AWGAFreqvalue = float(eval(AWGAFreqEntry.get()))
    except:
        AWGAFreqEntry.delete(0,"end")
        AWGAFreqEntry.insert(0, AWGAFreqvalue)

    if AWGAFreqvalue > 25000000: # max freq is 25 MHz
        AWGAFreqvalue = 25000000
        AWGAFreqEntry.delete(0,"end")
        AWGAFreqEntry.insert(0, AWGAFreqvalue)
    if AWGAFreqvalue <= 0: # Set negative frequency entry to 0
        AWGAFreqvalue = 1
        AWGAFreqEntry.delete(0,"end")
        AWGAFreqEntry.insert(0, AWGAFreqvalue)
    if AWGAFreqvalue <= 10000: # 10 times 7500
        AWGASampleRate = 7500000
##    elif AWGAFreqvalue > 7500 and AWGAFreqvalue < 75000: # 10 times 75000
##        AWGASampleRate = 7500000
    elif AWGAFreqvalue > 10000 and AWGAFreqvalue < 25000000: # 10 times 750000
        AWGASampleRate = 75000000
    aout.setSampleRate(0, AWGASampleRate) # m2k_dac_a.attrs["sampling_frequency"].value = str(AWGASampleRate)
#    print(aout.getSampleRate(0))
#    print(aout.getOversamplingRatio(0))

def SetAwgBSampleRate():
    global aout, AWGBFreqEntry, AWGBFreqvalue, AWGBSampleRate, m2k_dac_b

    try:
        AWGBFreqvalue = float(eval(AWGBFreqEntry.get()))
    except:
        AWGBFreqEntry.delete(0,"end")
        AWGBFreqEntry.insert(0, AWGBFreqvalue)

    if AWGBFreqvalue > 25000000: # max freq is 25 MHz
        AWGBFreqvalue = 25000000
        AWGBFreqEntry.delete(0,"end")
        AWGBFreqEntry.insert(0, AWGBFreqvalue)
    if AWGBFreqvalue <= 0: # Set negative frequency entry to 0
        AWGBFreqvalue = 1
        AWGBFreqEntry.delete(0,"end")
        AWGBFreqEntry.insert(0, AWGBFreqvalue)
    if AWGBFreqvalue <= 10000: # 10 times 7500
        AWGBSampleRate = 7500000
##    elif AWGBFreqvalue > 7500 and AWGBFreqvalue < 75000: # 10 times 75000
##        AWGBSampleRate = 7500000
    elif AWGBFreqvalue > 10000 and AWGBFreqvalue < 25000000: # 10 times 750000
        AWGBSampleRate = 75000000
    # aout.stop()
    aout.setSampleRate(1, AWGBSampleRate) # m2k_dac_b.attrs["sampling_frequency"].value = str(AWGBSampleRate)
#        
def AWGASendWave(AWG3):
    global AWGARecLength, AWGBuffLen, AWGAwaveform
    global AWGAAmplvalue, AWGAOffsetvalue, AWGPeakToPeak

    # Expect array values normalized from -1 to 1
    # scale values to minimum and max voltage
    AWG3 = numpy.array(AWG3) * 0.5 # scale by 1/2
    # Get Low and High voltage levels
    # Scale to high and low voltage values
    Gain = AWGAOffsetvalue - AWGAAmplvalue
    Offset = (AWGAOffsetvalue + AWGAAmplvalue)/2.0
    # print("Gain = ", Gain, "Offset = ", Offset)
    AWGAwaveform = numpy.array((AWG3 * Gain) + Offset)
#
##    
def AWGBSendWave(AWG3):
    global AWGBLastWave, AWGBRecLength, AWGBuffLen, AWGBwaveform
    global AWGBAmplvalue, AWGBOffsetvalue, AWGPeakToPeak
    # Expect array values normalized from -1 to 1
    # AWG3 = numpy.roll(AWG3, -68)
    AWGBLastWave = numpy.array(AWG3)
    AWG3 = numpy.array(AWG3) * 0.5 # scale by 1/2
    # Get Low and High voltage levels
    #
    Gain = AWGBOffsetvalue - AWGBAmplvalue
    Offset = (AWGBOffsetvalue + AWGBAmplvalue)/2.0
    AWGBwaveform = numpy.array((AWG3 * Gain) + Offset)
    
#
## Make the current selected AWG waveform
#
# Shape list SINE(1)|SQUare(2)|RAMP(3)|PULSe(4)|AmpALT(11)|AttALT(12)|StairDn(5)|StairUD(7) |
#  StairUp(6)|Besselj(8)|Bessely(9)|Sinc(10)
##AwgString1 = "Sine"
##AwgString2 = "Triangle"
##AwgString3 = "Ramp Up"
##AwgString4 = "Ramp Down"
##AwgString5 = "Stair Up"
##AwgString6 = "Stair Down"
##AwgString7 = "Stair Up-Down"
AwgString9 = "Cosine"
AwgString10 = "Full Wave Sine"
AwgString11 = "Half Wave Sine"
AwgString12 = "Fourier Series"
AwgString13 = "Schroeder Chirp"
AwgString14 = "Sine Power Pulse"
#
def MakeAWGwaves(): # make awg waveforms in case something changed
    global aout, AWGAAmplvalue, AWGAOffsetvalue
    global AWGAFreqvalue, AWGAPhasevalue, AWGAPhaseDelay
    global AWGADutyCyclevalue, AWGARepeatFlag
    global AWGAWave, AWGAMode, AWGAwaveform, AWGAIOMode
    global AWGSampleRate, AWG1Offset 
    global AWGAoffset, AWGBgain, AWGBoffset
    global AWGAModeLabel, DevID, HWRevOne
    global AWGAShape, AWGBwaveform
    global AWGBAmplvalue, AWGBOffsetvalue,  AWGAwaveform
    global AWGBFreqvalue, AWGBPhasevalue, AWGBPhaseDelay
    global AWGBDutyCyclevalue, FSweepMode, AWGBRepeatFlag, dac_b_pd
    global AWGSampleRate, AWG2Offset, AWGBWave, AWGBMode
    global ctx, m2k_AWG2pd, m2k_fabric, Buff0, Buff1, m2k_dac_a, m2k_dac_b
    global AWGBMode, AWGBIOMode, AWGBModeLabel
    global AWGBShape, AWGBbinform
    
    if AWGAFreqvalue > 0.0:
        AWGAperiodvalue = AWGSampleRate/AWGAFreqvalue
    else:
        AWGAperiodvalue = 0.0
    aout.setCyclic(True)
    # aout.stop()
#
    if AWGAShape.get()== 0:
        AWGAMakeDC()
        AWGAShapeLabel.config(text = "DC") # change displayed value
    elif AWGAShape.get()==1:
        AWGAMakeSine()
        AWGAShapeLabel.config(text = AwgString1) # change displayed value
    elif AWGAShape.get()==2:
        AWGAMakeSquare()
        AWGAShapeLabel.config(text = AwgString2) # change displayed value
    elif AWGAShape.get()==3:
        AWGAMakeTriangle()
        AWGAShapeLabel.config(text = AwgString3) # change displayed value
    elif AWGAShape.get()==4:
        AWGAMakePulse()
        AWGAShapeLabel.config(text = AwgString4) # change displayed value
    elif AWGAShape.get()==5:
        AWGAMakeRampDn()
        AWGAShapeLabel.config(text = AwgString5) # change displayed value
    elif AWGAShape.get()==6:
        AWGAMakeRampUp()
        AWGAShapeLabel.config(text = AwgString6) # change displayed value
    elif AWGAShape.get()==7:
        AWGAMakeStair()
        AWGAShapeLabel.config(text = AwgString7) # change displayed value
    elif AWGAShape.get()==8:
        AWGAMakeSinc()
        AWGAShapeLabel.config(text = AwgString8) # change displayed value
    elif AWGAShape.get()==9:
        AWGAMakeSine()
        AWGAShapeLabel.config(text = AwgString9) # change displayed value
    elif AWGAShape.get()==10:
        AWGAMakeFullWaveSine()
        AWGAShapeLabel.config(text = AwgString10) # change displayed value
    elif AWGAShape.get()==11:
        AWGAMakeHalfWaveSine()
        AWGAShapeLabel.config(text = AwgString11) # change displayed value
    elif AWGAShape.get()==12:
        AWGAMakeFourier()
        AWGAShapeLabel.config(text = AwgString12) # change displayed value
    elif AWGAShape.get()==13:
        SetAwgSampleRate()
        AWGAAmplvalue = float(eval(AWGAAmplEntry.get()))
        AWGAOffsetvalue = float(eval(AWGAOffsetEntry.get()))
        AWGAFreqvalue = UnitConvert(AWGAFreqEntry.get())
        NrTones = int(eval(AWGADutyCycleEntry.get()))
        ampl = 3.0/NrTones
        if ampl > 0.25:
            ampl = 0.25
        AWGASendWave(SchroederPhase(MaxSamples, NrTones, ampl))
        AWGAShapeLabel.config(text = AwgString13) # change displayed value
    elif AWGAShape.get()==14:
        SetAwgSampleRate()
        AWGAAmplvalue = float(eval(AWGAAmplEntry.get()))
        AWGAOffsetvalue = float(eval(AWGAOffsetEntry.get()))
        AWGAFreqvalue = UnitConvert(AWGAFreqEntry.get())
        Power = int(eval(AWGADutyCycleEntry.get()))
        Power = Power / 100.0
        ampl = 1
        AWGASendWave(SinePower(100, Power, 180, ampl))
        AWGAShapeLabel.config(text = AwgString14) # change displayed value
    else:
        AWGAShapeLabel.config(text = "Other Shape") # change displayed value
#
    AWGALength.config(text = "L = " + str(int(len(AWGAwaveform)))) # change displayed value
    if BisCompA.get() == 1:
        SetBCompA()
#
    if AWGBShape.get() == 0:
        AWGBMakeDC()
        AWGBShapeLabel.config(text = "DC") # change displayed value
    elif AWGBShape.get() == 1:
        AWGBMakeSine()
        AWGBShapeLabel.config(text = AwgString1) # change displayed value
    elif AWGBShape.get() == 2:
        AWGBMakeSquare()
        AWGBShapeLabel.config(text = AwgString2) # change displayed value
    elif AWGBShape.get() == 3:
        AWGBMakeTriangle()
        AWGBShapeLabel.config(text = AwgString3) # change displayed value
    elif AWGBShape.get() == 4:
        AWGBMakePulse()
        AWGBShapeLabel.config(text = AwgString4) # change displayed value
    elif AWGBShape.get()==5:
        AWGBMakeRampDn()
        AWGBShapeLabel.config(text = AwgString5) # change displayed value
    elif AWGBShape.get()==6:
        AWGBMakeRampUp()
        AWGBShapeLabel.config(text = AwgString6) # change displayed value
    elif AWGBShape.get()==7:
        AWGBMakeStair()
        AWGBShapeLabel.config(text = AwgString7) # change displayed value
    elif AWGBShape.get()==8:
        AWGBMakeSinc()
        AWGBShapeLabel.config(text = AwgString8) # change displayed value
    elif AWGBShape.get()==9:
        AWGBMakeSine()
        AWGBShapeLabel.config(text = AwgString9) # change displayed value
    elif AWGBShape.get()==10:
        AWGBMakeFullWaveSine()
        AWGBShapeLabel.config(text = AwgString10) # change displayed value
    elif AWGBShape.get()==11:
        AWGBMakeHalfWaveSine()
        AWGBShapeLabel.config(text = AwgString11) # change displayed value
    elif AWGBShape.get()==12:
        AWGBMakeFourier()
        AWGBShapeLabel.config(text = AwgString12) # change displayed value
    elif AWGBShape.get()==13:
        SetAwgSampleRate()
        AWGBAmplvalue = float(eval(AWGBAmplEntry.get()))
        AWGBOffsetvalue = float(eval(AWGBOffsetEntry.get()))
        AWGBFreqvalue = UnitConvert(AWGBFreqEntry.get())
        NrTones = int(eval(AWGBDutyCycleEntry.get()))
        ampl = 3.0/NrTones
        if ampl > 0.25:
            ampl = 0.25
        AWGBSendWave(SchroederPhase(MaxSamples, NrTones, ampl))
        AWGBShapeLabel.config(text = AwgString13) # change displayed value
    else:
        AWGBShapeLabel.config(text = "Other Shape") # change displayed value
#
    # aout.stop()
    # print(len(AWGAwaveform), len(AWGBwaveform))
    # buffer = [AWGAwaveform, AWGBwaveform]
    aout.setCyclic(True)
    aout.push([AWGAwaveform, AWGBwaveform])
    # 
    time.sleep(0.01)
    #aout.enableChannel(0, True)
    #aout.enableChannel(1, True)
    
def SetAwgA_Ampl(Ampl): # used to toggle on / off AWG output
    global aout, AwgBOnOffBt, AwgaOnOffLb, AwgbOnOffLb
    global AWGAwaveform, AWGBwaveform

    #AwgBOnOffBt.config(state=DISABLED)
    #AwgaOnOffLb.config(text="AWG Output ")
    #AwgbOnOffLb.config(text=" ")
    if Ampl == 0:
        #print("Power down AWG 1")
        aout.enableChannel(0, False)
    else:
        #print("power up AWG 1")
        aout.enableChannel(0, True)
    aout.push([AWGAwaveform, AWGBwaveform])
#
def SetAwgB_Ampl(Ampl): # used to toggle on / off AWG output
    global aout, AwgBOnOffBt, AwgAOnOffBt, AwgaOnOffLb, AwgbOnOffLb
    global AWGAwaveform, AWGBwaveform

    #AwgBOnOffBt.config(state=DISABLED)
    #AwgaOnOffLb.config(text="AWG Output ")
    #AwgbOnOffLb.config(text=" ")
    if Ampl == 0:
        #print("Power down AWG 2")
        aout.enableChannel(1, False)
    else:
        # AwgAOnOffBt.config(text='ON', style="Run.TButton")
        #print("power up AWG 2")
        aout.enableChannel(1, True)
    aout.push([AWGAwaveform, AWGBwaveform])
#
def HOffsetA():
    global CHAOffset, CHAVPosEntry

    try:
        CHAOffset = 0.0 - float(eval(CHAVPosEntry.get()))
        CHAOffset
        ain.setVerticalOffset(0,CHAOffset)
    except:
        CHAVPosEntry.delete(0,END)
        CHAVPosEntry.insert(0, CHAOffset)
#
def HOffsetB():
    global CHBOffset, CHBVPosEntry

    try:
        CHBOffset = 0.0 - float(eval(CHBVPosEntry.get()))
        ain.setVerticalOffset(1,CHBOffset)
    except:
        CHBVPosEntry.delete(0,END)
        CHBVPosEntry.insert(0, CHBOffset)
#
# Hardware Specific Trigger functions
#
def SendTriggerLevel():
    global TRIGGERlevel, ser, RUNstatus, AWGPeakToPeak
    # Min and Max trigger level specific to hardware
    if TRIGGERlevel > 4.0:
        TRIGGERlevel = 4.0
        TRIGGERentry.delete(0,"end")
        TRIGGERentry.insert(0, ' {0:.2f} '.format(4.0))
    if TRIGGERlevel < 0.0:
        TRIGGERlevel = 0.0
        TRIGGERentry.delete(0,"end")
        TRIGGERentry.insert(0, ' {0:.2f} '.format(0.0))
# Adjust trigger level.
# representa a 8-bit number (0-255) sent to DAC

# Set Horz possition from entry widget
def SetHorzPoss():
    global HozPossentry, ser

    HzSteps = int(float(HozPossentry.get()))
    Hz_Value = 511-HzSteps
    if Hz_Value > 256:
        T_High = 1
        T_Low = Hz_Value - 256
    else:
        T_High = 0
        T_Low = Hz_Value
#
# Set Internal / External triggering bits
def BTrigIntExt():
    global trig, TriggerMethod, Is_Triggered, hozpos, TRIGGERsample
    global TgInput, TgEdge, TRIGGERlevel

    if TriggerMethod.get() == 1: # Using Hardware triggering
        TRIGGERsample = 0 # reset pointer to zero when using HW trigger
        Is_Triggered = 1
        trig.setAnalogDelay(hozpos)
        if TgInput.get() == 0:
            trig.setAnalogMode(0,libm2k.ALWAYS)
            trig.setAnalogMode(1,libm2k.ALWAYS)
        elif TgInput.get() == 1:
            trig.setAnalogMode(0,libm2k.ANALOG)
            trig.setAnalogMode(1,libm2k.ALWAYS)
            trig.setAnalogLevel(0,TRIGGERlevel)
        elif TgInput.get() == 3:
            trig.setAnalogMode(0,libm2k.ALWAYS)
            trig.setAnalogMode(1,libm2k.ANALOG)
            trig.setAnalogLevel(1,TRIGGERlevel)
        if TgEdge.get() == 0:
            trig.setAnalogCondition(0,libm2k.RISING_EDGE_ANALOG)
            trig.setAnalogCondition(1,libm2k.RISING_EDGE_ANALOG)
        else:
            trig.setAnalogCondition(0,libm2k.FALLING_EDGE_ANALOG) # RISING_EDGE)
            trig.setAnalogCondition(1,libm2k.FALLING_EDGE_ANALOG) # RISING_EDGE)
    else:
        trig.setAnalogMode(0,libm2k.ALWAYS)
        trig.setAnalogMode(1,libm2k.ALWAYS)
#
# Set Triggering source bits
def BSetTriggerSource():
    global TgInput, TrigSource, TriggerInt

    if TgInput.get() == 1:
        TrigSource = 0x00 # bit 4 0x00 = Channel A
    if TgInput.get() == 2:
        TrigSource = 0x10 # bit 4 0x10 = Channel B
    if TgInput.get() == 0:
        TriggerInt = 0x40 # bit 6 0x40 No Triggers (free-run)?
# Set Trigger edge bits
def BSetTrigEdge():
    global TgEdge, TriggerEdge
    
    if TgEdge.get() == 0:
        trig.setAnalogCondition(0,libm2k.RISING_EDGE_ANALOG)
        trig.setAnalogCondition(1,libm2k.RISING_EDGE_ANALOG)
#
def PlaceUSPower():
    global frame2r, plusUSEntry, negUSEntry, plusUSrb, negUSrb, plusUSlab, negUSlab
    
    # User Power supply controls
    userlab = Label(frame2r, text="External Power Supplies")
    userlab.pack(side=TOP)
    PlusUS = Frame( frame2r )
    PlusUS.pack(side=TOP)
    plusUSrb = Label(PlusUS, text="5.00")
    plusUSrb.pack(side=RIGHT)
    plusUSEntry = Entry(PlusUS, width=5)
    plusUSEntry.bind("<Return>", BplusUS)
    plusUSEntry.bind('<MouseWheel>', scrollPlusUS)
    plusUSEntry.bind('<Key>', onTextKey)
    plusUSEntry.pack(side=RIGHT)
    plusUSEntry.delete(0,"end")
    plusUSEntry.insert(0,5.0)
    plusUSlab = Checkbutton(PlusUS, text="+V", style="Disab.TCheckbutton", variable=PlusUSEnab, command=BPlusOnOff)
    plusUSlab.pack(side=RIGHT)
    #
    NegUS = Frame( frame2r )
    NegUS.pack(side=TOP)
    negUSrb = Label(NegUS, text=" -5.00")
    negUSrb.pack(side=RIGHT)
    negUSEntry = Entry(NegUS, width=5)
    negUSEntry.bind("<Return>", BnegUS)
    negUSEntry.bind('<MouseWheel>', scrollNegUS)
    negUSEntry.bind('<Key>', onTextKey)
    negUSEntry.pack(side=RIGHT)
    negUSEntry.delete(0,"end")
    negUSEntry.insert(0,-5.0)
    negUSlab = Checkbutton(NegUS, text="-V", style="Disab.TCheckbutton", variable=NegUSEnab, command=BNegOnOff)
    negUSlab.pack(side=RIGHT)
#
#
def BnegUS(temp):
    global negUSEntry, NegUS, ctx, ad5627

    SetNegUS()
#
def BplusUS(temp):
    global plusUSEntry, PlusUS, ctx, ad5627

    SetPosUS()
#
def BPlusOnOff():
    global PlusUSEnab, UserPS, ctx, plusUSlab

    if PlusUSEnab.get() > 0:
        UserPS.enableChannel(0,True) # power up positive user supply
        SetPosUS()
        plusUSlab.config( style="Enab.TCheckbutton")
    else:
        UserPS.enableChannel(0,False) # power down positive user supply
        plusUSlab.config( style="Disab.TCheckbutton")
#
def BNegOnOff():
    global NegUSEnab, UserPS, ctx, negUSlab

    if NegUSEnab.get() > 0:
        UserPS.enableChannel(1,True) # power up negative user supply
        SetNegUS()
        negUSlab.config( style="Enab.TCheckbutton")
    else:
        UserPS.enableChannel(1,False) # power down negative user supply
        negUSlab.config( style="Disab.TCheckbutton")
#
def SetNegUS():
    global negUSEntry, UserPS, NegVolts, ctx, NegUS_RB

    if NegUSEnab.get() > 0:
        UserPS.enableChannel(1,True) # power up negative user supply
    else:
        UserPS.enableChannel(1,False) # power down negative user supply
    try:
        NegVolts = float(negUSEntry.get())
        if NegVolts > 0 :
            NegVolts = 0.0
            negUSEntry.delete(0,END)
            negUSEntry.insert(0, NegVolts)
        if NegVolts < -5.0:
            NegVolts = -5.0
            negUSEntry.delete(0,END)
            negUSEntry.insert(0, NegVolts)
    except:
        negUSEntry.delete(0,END)
        negUSEntry.insert(0, NegVolts)
    UserPS.pushChannel(1,NegVolts)# set value to volts
# Read back scaled values for user power supplies seem to be 500 too big?
    negrb_val = UserPS.readChannel(1)
    negrb_str = ' {0:.3f} '.format(negrb_val * -1)
    negUSrb.configure(text=negrb_str)
#
def SetPosUS():
    global plusUSEntry, PlusVolts, UserPS, ctx, PlusUS_RB, plusUSrb
    
    if PlusUSEnab.get() > 0:
        UserPS.enableChannel(0,True) # power up positive user supply
    else:
        UserPS.enableChannel(0,False)
    try:
        PlusVolts = float(plusUSEntry.get())
        if PlusVolts < 0 :
            PlusVolts = 0.0
            plusUSEntry.delete(0,END)
            plusUSEntry.insert(0, PlusVolts)
        if PlusVolts > 5.0:
            PlusVolts = 5.0
            plusUSEntry.delete(0,END)
            plusUSEntry.insert(0, PlusVolts)
    except:
        plusUSEntry.delete(0,END)
        plusUSEntry.insert(0, PlusVolts)
    UserPS.pushChannel(0,PlusVolts) # set positve user supply voltage
# Read back scaled values for user power supplies seem to be 500 too big?
    posrb_val = UserPS.readChannel(0)
    posrb_str = ' {0:.3f} '.format(posrb_val)
    plusUSrb.configure(text=posrb_str)
#
def scrollPlusUS(temp):

    onTextScroll(temp)
    SetPosUS()
#
def scrollNegUS(temp):

    onTextScroll(temp)
    SetNegUS()
#
#
## Text Editor stuff here
def TextNew_file():
    global BOMtext, TextCurrent_filepath
    
    BOMtext.delete(1.0, END)
#
def TextOpen_file():
    global BOMtext, TextCurrent_filepath
    
    filepath = askopenfilename(defaultextension=".txt",
                                filetypes=[("Circuit Files", "*.cir"),
                                               ("Text Files", "*.txt"),
                                                ("All Files", "*.*")])
    if filepath:
        TextCurrent_filepath = filepath
        try:
            with open(filepath, "r") as file:
                content = file.read()
                BOMtext.delete(1.0, END)
                BOMtext.insert(END, content)
            #.title(f"Simple Text Editor - {filepath}")
        except Exception as e:
            messagebox.showerror("Error", f"Could not open file: {e}")
#
def TextSave_file():
    global TextCurrent_filepath
    
    filepath = TextCurrent_filepath
    if filepath:
        TextWrite_to_file(filepath)
    else:
        TextSave_file_as()
#
def TextSave_file_as():
    global BOMtext, TextCurrent_filepath
    
    filepath = asksaveasfilename(defaultextension=".cir",
                                    filetypes=[("Circuit Files", "*.cir"),
                                               ("Text Files", "*.txt"),
                                                ("All Files", "*.*")])
    if filepath:
        TextWrite_to_file(filepath)
        TextCurrent_filepath = filepath
        # self.master.title(f"Simple Text Editor - {filepath}")
#
def TextWrite_to_file(filepath):
    global BOMtext

    try:
        with open(filepath, "w", encoding='utf-8') as file:
            file.write(BOMtext.get(1.0, END))
    except Exception as e:
        showwarning("Error", f"Could not save file: {e}")
#
def AutoPlacer(): # VERY Experimental
    global BOMtext
    global VPower, R_List, C_List, L_List, D_List, M_List, Q_List, U_List
    global U_Connections
    global ComponentList, VPowerConnections, VPower, UnRouted
    global FileString

    netlist = FileString.get()
    ResetMatrix()
    CmpList = ReadNetlist(netlist) # list of all subcircuit instances found
    #
    VPower = []
    UnRouted = []
    RL_OneList = []
    RR_OneList = []
    RL_TwoList = []
    RR_TwoList = []
    CL_OneList = []
    CR_OneList = []
    CL_TwoList = []
    CR_TwoList = []
    DL_OneList = []
    DR_OneList = []
    DL_TwoList = []
    DR_TwoList = []
    QL_List = []
    QR_List = []
    UL_List = []
    UR_List = []
    # 
    XCPList = []
    UIndex = 0
    TLIndex = BLIndex = 1
    TRIndex = BRIndex = 2
    TopQL = TopQR = 1 # Start first device in bottom region?
    JPIndex = 1
    XIndex = 1
    VIndex = 1
    for line in CmpList:
        if ".subckt" in line: # Stop when you get to sub circuits
            break
        if "cross_point" in line: # Select the lines that contain "cross_point"
            XCPList.append(line)
        SplitLine = []
        SplitLine = line.split()
        # if a source has V in name
        # and one or the other terminal nodes names have a V
        if len(SplitLine) > 0:
            FirstPart = SplitLine[0]
            if "V" == FirstPart[0]:
                if "V" in SplitLine[1]:
                    if SplitLine[1] in VPower:
                        donothing()
                    else:
                        VPower.append(SplitLine[1])
                if "V" in SplitLine[2]:
                    if SplitLine[2] in VPower:
                        donothing()
                    else:
                        VPower.append(SplitLine[2])
                if "COM" in SplitLine[1]:
                    if SplitLine[1] in VPower:
                        donothing()
                    else:
                        VPower.append(SplitLine[1])
                if "COM" in SplitLine[2]:
                    if SplitLine[2] in VPower:
                        donothing()
                    else:
                        VPower.append(SplitLine[2])
                if "0" == SplitLine[1]:
                    if SplitLine[1] in VPower:
                        donothing()
                    else:
                        VPower.append(SplitLine[1])
                if "0" == SplitLine[2]:
                    if SplitLine[2] in VPower:
                        donothing()
                    else:
                        VPower.append(SplitLine[2])
            if "R" == FirstPart[0]: # Find all resistors
                # JmpNum = 0
                if "JP" in SplitLine[1]:
                    Jumper = SplitLine[1] # First net is Jumper bus
                    JmpNum = int(Jumper.replace("JP","")) # extract number 1-16
                elif "JP" in SplitLine[2]:
                    Jumper = SplitLine[2] # First net is Jumper bus
                    JmpNum = int(Jumper.replace("JP","")) # extract number 1-16
                if JmpNum > 0 and JmpNum < 9: # Comp on left
                    if "V" in SplitLine[1] or "V" in SplitLine[2]:
                        RL_OneList.append(SplitLine)
                    elif SplitLine[1] == "0" or SplitLine[2] == "0":
                        RL_OneList.append(SplitLine)
                    else:
                        RL_TwoList.append(SplitLine)
                elif JmpNum > 8 and JmpNum < 17: # Comp on right
                    if "V" in SplitLine[1] or "V" in SplitLine[2]:
                        RR_OneList.append(SplitLine)
                    elif SplitLine[1] == "0" or SplitLine[2] == "0":
                        RR_OneList.append(SplitLine)
                    else:
                        RR_TwoList.append(SplitLine)
            if "C" == FirstPart[0] or "L" == FirstPart[0]: # Find all capacitors and inductors
                # JmpNum = 0
                if "JP" in SplitLine[1]:
                    Jumper = SplitLine[1] # First net is Jumper bus
                    JmpNum = int(Jumper.replace("JP","")) # extract number 1-16
                elif "JP" in SplitLine[2]:
                    Jumper = SplitLine[2] # First net is Jumper bus
                    JmpNum = int(Jumper.replace("JP","")) # extract number 1-16
                if JmpNum > 0 and JmpNum < 9:
                    if "V" in SplitLine[1] or "V" in SplitLine[2]:
                        CL_OneList.append(SplitLine)
                    elif SplitLine[1] == "0" or SplitLine[2] == "0":
                        CL_OneList.append(SplitLine)
                    else:
                        CL_TwoList.append(SplitLine)
                elif JmpNum > 8 and JmpNum < 17:
                    if "V" in SplitLine[1] or "V" in SplitLine[2]:
                        CR_OneList.append(SplitLine)
                    elif SplitLine[1] == "0" or SplitLine[2] == "0":
                        CR_OneList.append(SplitLine)
                    else:
                        CR_TwoList.append(SplitLine)
            if "D" == FirstPart[0]: # Find all diodes
                # JmpNum = 0
                if "JP" in SplitLine[1]:
                    Jumper = SplitLine[1] # 
                    JmpNum = int(Jumper.replace("JP","")) # extract number 1-16
                elif "JP" in SplitLine[2]:
                    Jumper = SplitLine[2] # 
                    JmpNum = int(Jumper.replace("JP","")) # extract number 1-16
                if JmpNum > 0 and JmpNum < 9:
                    if "V" in SplitLine[1] or "V" in SplitLine[2]:
                        DL_OneList.append(SplitLine)
                    elif SplitLine[1] == "0" or SplitLine[2] == "0":
                        DL_OneList.append(SplitLine)
                    else:
                        DL_TwoList.append(SplitLine)
                elif JmpNum > 8 and JmpNum < 17:
                    if "V" in SplitLine[1] or "V" in SplitLine[2]:
                        DR_OneList.append(SplitLine)
                    elif SplitLine[1] == "0" or SplitLine[2] == "0":
                        DR_OneList.append(SplitLine)
                    else:
                        DR_TwoList.append(SplitLine)
            if "Q" == FirstPart[0] or "M" == FirstPart[0]: # Find all 3 term transostors
                # JmpNum = 0
                if "JP" in SplitLine[1]:
                    Jumper = SplitLine[1] # 
                    JmpNum = int(Jumper.replace("JP","")) # extract number 1-16
                elif "JP" in SplitLine[2]:
                    Jumper = SplitLine[2] # 
                    JmpNum = int(Jumper.replace("JP","")) # extract number 1-16
                elif "JP" in SplitLine[3]:
                    Jumper = SplitLine[3] # 
                    JmpNum = int(Jumper.replace("JP","")) # extract number 1-16
                if JmpNum > 0 and JmpNum < 9:
                    QL_List.append(SplitLine)
                elif JmpNum > 8 and JmpNum < 17:
                    QR_List.append(SplitLine)
            if "U" in FirstPart: # Find all other IC
                    UL_List.append(SplitLine)
    #
## Clear all text in Editor
    BOMtext.delete("1.0", END)
## Left Side BB for jumpers 1-8
    # List two BB pin resistors on Left side
    for R in range (0, len(RL_TwoList), 1):
        Rterm = RL_TwoList[R]
        Rname  = Rterm[0]
        Rterm1 = Rterm[1]
        Rterm2 = Rterm[2]
        RValue = Rterm[3]
        if "JP" not in Rterm1:
            UnRhole = "TL" + str(TLIndex)
            UnRouted.append([Rterm1, UnRhole])
        if "JP" not in Rterm2:
            UnRhole = "BL" + str(TLIndex)
            UnRouted.append([Rterm2, UnRhole])
        #
        R_Line = Rname + " " 
        R_Line = R_Line + "TL" + str(TLIndex) + " " + "BL" + str(TLIndex) + " "
        X_Line = "X" + str(XIndex) + " " + Rterm1 + " " + "TL" + str(TLIndex) + " cross_point\n"
        XIndex = XIndex + 1
        BOMtext.insert(END, X_Line)
        X_Line = "X" + str(XIndex) + " " + Rterm2 + " " + "BL" + str(TLIndex) + " cross_point\n"
        XIndex = XIndex + 1
        BOMtext.insert(END, X_Line)
        TLIndex = TLIndex + 1
        BLIndex = BLIndex + 1
        #
        R_Line = R_Line + RValue + "\n" 
        BOMtext.insert(END, R_Line)
    # List two BB capacitors / inductors Left side
    for C in range (0, len(CL_TwoList), 1):
        Cterm = CL_TwoList[C]
        Cname  = Cterm[0]
        Cterm1 = Cterm[1]
        Cterm2 = Cterm[2]
        CValue = Cterm[3]
        if "JP" not in Cterm1:
            UnRhole = "TL" + str(TLIndex)
            UnRouted.append([Cterm1, UnRhole])
        if "JP" not in Cterm2:
            UnRhole = "BL" + str(TLIndex)
            UnRouted.append([Cterm2, UnRhole])
        #
        C_Line = Cname + " " # 
        C_Line = C_Line + "TL" + str(TLIndex) + " " + "BL" + str(TLIndex) + " "
        X_Line = "X" + str(XIndex) + " " + Cterm1 + " " + "TL" + str(TLIndex) + " cross_point\n"
        XIndex = XIndex + 1
        BOMtext.insert(END, X_Line)
        X_Line = "X" + str(XIndex) + " " + Cterm2 + " " + "BL" + str(TLIndex) + " cross_point\n"
        XIndex = XIndex + 1
        BOMtext.insert(END, X_Line)
        TLIndex = TLIndex + 1
        BLIndex = BLIndex + 1
        #
        C_Line = C_Line + CValue + "\n" 
        BOMtext.insert(END, C_Line)
    # Add two BB pin Diodes 
    for D in range (0, len(DL_TwoList), 1):
        Dterm = DL_TwoList[D]
        Dname  = Dterm[0]
        Dterm1 = Dterm[1]
        Dterm2 = Dterm[2]
        DValue = Dterm[3]
        if "JP" not in Dterm1:
            UnRhole = "TL" + str(TLIndex)
            UnRouted.append([Dterm1, UnRhole])
        if "JP" not in Dterm2:
            UnRhole = "BL" + str(TLIndex)
            UnRouted.append([Dterm2, UnRhole])
        #
        D_Line = Dname + " " #
        D_Line = D_Line + "TL" + str(TLIndex) + " " + "BL" + str(TLIndex) + " "
        X_Line = "X" + str(XIndex) + " " + Dterm1 + " " + "TL" + str(TLIndex) + " cross_point\n"
        XIndex = XIndex + 1
        BOMtext.insert(END, X_Line)
        X_Line = "X" + str(XIndex) + " " + Dterm2 + " " + "BL" + str(TLIndex) + " cross_point\n"
        XIndex = XIndex + 1
        BOMtext.insert(END, X_Line)
        TLIndex = TLIndex + 1
        BLIndex = BLIndex + 1
        #
        D_Line = D_Line + DValue + "\n" 
        BOMtext.insert(END, D_Line)
    # add resistors to Power / Gnd
    TLIndex = max(TLIndex, BLIndex)
    BLIndex = max(TLIndex, BLIndex)
    for R in range (0, len(RL_OneList), 1):
        Rterm = RL_OneList[R]
        Rname  = Rterm[0]
        Rterm1 = Rterm[1]
        Rterm2 = Rterm[2]
        RValue = Rterm[3]
        #
        R_Line = Rname + " "
        if Rterm1 == "0":
            if "BL" in Rterm2:
                R_Line = R_Line + "GND " + Rterm2 + " "
            else:
                R_Line = R_Line + "GND " + "BL" + str(BLIndex) + " " #
                if "JP" not in Rterm2:
                    UnRhole = "BL" + str(BLIndex)
                    UnRouted.append([Rterm2, UnRhole])
            X_Line = "XBL" + str(BLIndex) + " " + Rterm2 + " NC cross_point\n"
            XIndex = XIndex + 1
            BOMtext.insert(END, X_Line)
            BLIndex = BLIndex + 1
        elif "VDD" in Rterm1:
            if "TL" in Rterm2:
                R_Line = R_Line + "VDD " + Rterm2 + " "
            else:
                R_Line = R_Line + "VDD " + "TL" + str(TLIndex) + " "
                if "JP" not in Rterm2:
                    UnRhole = "TL" + str(TLIndex)
                    UnRouted.append([Rterm2, UnRhole])
            X_Line = "XTL" + str(TLIndex) + " " + Rterm2 + " NC cross_point\n"
            XIndex = XIndex + 1
            BOMtext.insert(END, X_Line)
            TLIndex = TLIndex + 1
        elif "VEE" in Rterm1:
            if "BL" in Rterm2:
                R_Line = R_Line + "VDD " + Rterm2 + " "
            else:
                R_Line = R_Line + "VEE " + "BL" + str(BLIndex) + " "
                if "JP" not in Rterm2:
                    UnRhole = "BL" + str(BLIndex)
                    UnRouted.append([Rterm2, UnRhole])
            X_Line = "XBL" + str(BLIndex) + " " + Rterm2 + " NC cross_point\n"
            XIndex = XIndex + 1
            BOMtext.insert(END, X_Line)
            BLIndex = BLIndex + 1
        #
        elif Rterm2 == "0":
            if "BL" in Rterm1:
                R_Line = R_Line + "GND " + Rterm1 + " "
            else:
                R_Line = R_Line + "GND " + "BL" + str(BLIndex) + " "
                if "JP" not in Rterm1:
                    UnRhole = "BL" + str(BLIndex)
                    UnRouted.append([Rterm1, UnRhole])
            X_Line = "XBL" + str(BLIndex) + " " + Rterm1 + " NC cross_point\n"
            XIndex = XIndex + 1
            BOMtext.insert(END, X_Line)
            BLIndex = BLIndex + 1
        elif "VDD" in Rterm2:
            if "TL" in Rterm1:
                R_Line = R_Line + "VDD " + Rterm1 + " "
            else:
                R_Line = R_Line + "VDD " + "TL" + str(TLIndex) + " "
                if "JP" not in Rterm1:
                    UnRhole = "TL" + str(TLIndex)
                    UnRouted.append([Rterm1, UnRhole])
            X_Line = "XTL" + str(TLIndex) + " " + Rterm1 + " NC cross_point\n"
            XIndex = XIndex + 1
            BOMtext.insert(END, X_Line)
            TLIndex = TLIndex + 1
        elif "VEE" in Rterm2:
            if "BL" in Rterm1:
                R_Line = R_Line + "VEE " + Rterm1 + " "
            else:
                R_Line = R_Line + "VEE " + "BL" + str(BLIndex) + " "
                if "JP" not in Rterm1:
                    UnRhole = "BL" + str(BLIndex)
                    UnRouted.append([Rterm1, UnRhole])
            X_Line = "XBL" + str(BLIndex) + " " + Rterm1 + " NC cross_point\n"
            XIndex = XIndex + 1
            BOMtext.insert(END, X_Line)
            BLIndex = BLIndex + 1
        #
        R_Line = R_Line + RValue + "\n" 
        BOMtext.insert(END, R_Line)
    # # add capacitors / inductors to Power / Gnd
    # TLIndex = max(TLIndex, BLIndex)
    # BLIndex = max(TLIndex, BLIndex)
    for C in range (0, len(CL_OneList), 1):
        Cterm = CL_OneList[C]
        Cname  = Cterm[0]
        Cterm1 = Cterm[1]
        Cterm2 = Cterm[2]
        CValue = Cterm[3]
        #
        C_Line = Cname + " " # 
        if Cterm1 == "0":
            if "BL" in Cterm2:
                C_Line = C_Line + "GND " + Cterm2 + " "
            else:
                C_Line = C_Line + "GND " + "BL" + str(BLIndex) + " "
                if "JP" not in Cterm2:
                    UnRhole = "BL" + str(BLIndex)
                    UnRouted.append([Cterm2, UnRhole])
            X_Line = "XBL" + str(BLIndex) + " " + Cterm2 + " NC cross_point\n"
            XIndex = XIndex + 1
            BLIndex = BLIndex + 1
            BOMtext.insert(END, X_Line)
        elif "VDD" in Cterm1:
            if "TL" in Cterm2:
                C_Line = C_Line + "VDD " + Cterm2 + " "
            else:
                C_Line = C_Line + "VDD " + "TL" + str(TLIndex) + " "
                if "JP" not in Cterm2:
                    UnRhole = "TL" + str(TLIndex)
                    UnRouted.append([Cterm2, UnRhole])
            X_Line = "XTL" + str(TLIndex) + " " + Cterm2 + " NC cross_point\n"
            XIndex = XIndex + 1
            TLIndex = TLIndex + 1
            BOMtext.insert(END, X_Line)
        elif "VEE" in Cterm1:
            if "BL" in Cterm2:
                C_Line = C_Line + "GND " + Cterm2 + " "
            else:
                C_Line = C_Line + "VEE " + "BL" + str(BLIndex) + " "
                if "JP" not in Cterm2:
                    UnRhole = "BL" + str(BLIndex)
                    UnRouted.append([Cterm2, UnRhole])
            X_Line = "XBL" + str(BLIndex) + " " + Cterm2 + " NC cross_point\n"
            XIndex = XIndex + 1
            BLIndex = BLIndex + 1
            BOMtext.insert(END, X_Line)
        elif Cterm2 == "0":
            if "BL" in Cterm1:
                C_Line = C_Line + "GND " + Cterm1 + " "
            else:
                C_Line = C_Line + "GND " + "BL" + str(BLIndex) + " "
                if "JP" not in Cterm1:
                    UnRhole = "BL" + str(BLIndex)
                    UnRouted.append([Cterm1, UnRhole])
            X_Line = "XBL" + str(BLIndex) + " " + Cterm1 + " NC cross_point\n"
            XIndex = XIndex + 1
            BLIndex = BLIndex + 1
            BOMtext.insert(END, X_Line)
        elif "VDD" in Cterm2:
            if "TL" in Cterm1:
                C_Line = C_Line + "VDD " + Cterm2 + " "
            else:
                C_Line = C_Line + "VDD " + "TL" + str(TLIndex) + " "
                if "JP" not in Cterm1:
                    UnRhole = "TL" + str(TLIndex)
                    UnRouted.append([Cterm1, UnRhole])
            X_Line = "XTL" + str(TLIndex) + " " + Cterm1 + " NC cross_point\n"
            XIndex = XIndex + 1
            TLIndex = TLIndex + 1
            BOMtext.insert(END, X_Line)
        elif "VEE" in Cterm2:
            if "BL" in Cterm1:
                C_Line = C_Line + "GND " + Cterm1 + " "
            else:
                C_Line = C_Line + "VEE " + "BL" + str(BLIndex) + " "
                if "JP" not in Cterm1:
                    UnRhole = "BL" + str(BLIndex)
                    UnRouted.append([Cterm1, UnRhole])
            X_Line = "XBL" + str(BLIndex) + " " + Cterm1 + " NC cross_point\n"
            XIndex = XIndex + 1
            BLIndex = BLIndex + 1
            BOMtext.insert(END, X_Line)
        #
        C_Line = C_Line + CValue + "\n" 
        BOMtext.insert(END, C_Line)
    # List Diodes on Left side
    for D in range (0, len(DL_OneList), 1):
        Dterm = DL_OneList[D]
        Dname  = Dterm[0]
        Dterm1 = Dterm[1]
        Dterm2 = Dterm[2]
        DValue = Dterm[3]
        #
        D_Line = Dname + " " # 
        if Dterm1 == "0":
            if "BL" in Dterm2:
                D_Line = D_Line + "GND " + Dterm1 + " "
            else:
                D_Line = D_Line + "GND " + "BL" + str(BLIndex) + " "
                if "JP" not in Dterm2:
                    UnRhole = "BL" + str(BLIndex)
                    UnRouted.append([Dterm2, UnRhole])
            X_Line = "XBL" + str(BLIndex) + " " + Dterm2 + " NC cross_point\n"
            XIndex = XIndex + 1
            BLIndex = BLIndex + 1
            BOMtext.insert(END, X_Line)
        elif "VDD" in Dterm1:
            if "TL" in Dterm2:
                D_Line = D_Line + "VDD " + Dterm1 + " "
            else:
                D_Line = D_Line + "VDD " + "TL" + str(TLIndex) + " "
                if "JP" not in Dterm2:
                    UnRhole = "TL" + str(TLIndex)
                    UnRouted.append([Dterm2, UnRhole])
            X_Line = "XTL" + str(TLIndex) + " " + Dterm2 + " NC cross_point\n"
            XIndex = XIndex + 1
            TLIndex = TLIndex + 1
            BOMtext.insert(END, X_Line)
        elif "VEE" in Dterm1:
            if "BL" in Dterm2:
                D_Line = D_Line + "GND " + Dterm1 + " "
            else:
                D_Line = D_Line + "VEE " + "BL" + str(BLIndex) + " "
                if "JP" not in Dterm2:
                    UnRhole = "BL" + str(BLIndex)
                    UnRouted.append([Dterm2, UnRhole])
            X_Line = "XBL" + str(BLIndex) + " " + Dterm2 + " NC cross_point\n"
            XIndex = XIndex + 1
            BLIndex = BLIndex + 1
            BOMtext.insert(END, X_Line)
        elif Dterm2 == "0":
            if "BL" in Dterm1:
                D_Line = D_Line + "GND " + Dterm1 + " "
            else:
                D_Line = D_Line + "BL" + str(BLIndex) + " GND "
                if "JP" not in Dterm1:
                    UnRhole = "BL" + str(BLIndex)
                    UnRouted.append([Dterm1, UnRhole])
            X_Line = "XBL" + str(BLIndex) + " " + Dterm1 + " NC cross_point\n"
            XIndex = XIndex + 1
            BLIndex = BLIndex + 1
            BOMtext.insert(END, X_Line)
        elif "VDD" in Dterm2:
            if "TL" in Dterm1:
                D_Line = D_Line + "VDD " + Dterm1 + " "
            else:
                D_Line = D_Line + "TL" + str(TLIndex) + " VDD "
                if "JP" not in Dterm1:
                    UnRhole = "TL" + str(TLIndex)
                    UnRouted.append([Dterm1, UnRhole])
            X_Line = "XTL" + str(TLIndex) + " " + Dterm1 + " NC cross_point\n"
            XIndex = XIndex + 1
            TLIndex = TLIndex + 1
            BOMtext.insert(END, X_Line)
        elif "VEE" in Dterm2:
            if "BL" in Dterm1:
                D_Line = D_Line + "GND " + Dterm1 + " "
            else:
                D_Line = D_Line + "BL" + str(BLIndex) + " VEE "
                if "JP" not in Dterm1:
                    UnRhole = "BL" + str(BLIndex)
                    UnRouted.append([Dterm1, UnRhole])
            X_Line = "XBL" + str(BLIndex) + " " + Dterm1 + " NC cross_point\n"
            XIndex = XIndex + 1
            BOMtext.insert(END, X_Line)
            BLIndex = BLIndex + 1
        #
        D_Line = D_Line + DValue + "\n" 
        BOMtext.insert(END, D_Line)
    # List Q transistors on Left side
    for Q in range (0, len(QL_List), 1):
        Qterm = QL_List[Q]
        Qname = Qterm[0]
        Qterm1 = Qterm[1]
        Qterm2 = Qterm[2]
        Qterm3 = Qterm[3]
        Qterm4 = Qterm[4]
        QValue = Qterm[5]
        #
        Q_Line = Qname + " "
        #
        if "VDD" in Qterm:
            TopQL = 0
        elif "VEE" in Qterm:
            TopQL = 1
        if "TL" in Qterm1 or "TL" in Qterm2 or "TL" in Qterm3:
            TopQL = 0
        elif "BL" in Qterm1 or "BL" in Qterm2 or "BL" in Qterm3:
            TopQL = 1
        # Do three terminals
        for T in range(1, 4, 1):
            if TopQL == 0:
                QIndex = TLIndex
                if "TL" in Qterm[T]:
                    Q_Line = Q_Line + " " + Qterm[T] + " "
                else:
                    Q_Line = Q_Line + "TL" + str(QIndex) + " "
                    TLIndex = TLIndex + 1
                if Qterm[T] == "0":
                    QN1 = "GND"
                    X_Line = "XTL" + str(QIndex) + " 0 " + QN1 + " cross_point\n"
                elif "VDD" in Qterm[T]:
                    QN1 = "VDD"
                    X_Line = "XTL" + str(QIndex) + " " + QN1 + " NC cross_point\n"
                elif "JP" not in Qterm[T]:
                    if "TL" in Qterm[T]:
                        donothing()
                    else:
                        UnRhole = "TL" + str(QIndex)
                        UnRouted.append([Qterm[T], UnRhole])
                else:
                    QN1 = Qterm[T]
                    X_Line = "X" + str(XIndex) + " " + QN1 + " " + "TL" + str(QIndex) + " cross_point\n"
                    XIndex = XIndex + 1
                #
            else:
                QIndex = BLIndex
                if "BL" in Qterm[T]:
                    Q_Line = Q_Line + " " + Qterm[T] + " "
                else:
                    Q_Line = Q_Line + "BL" + str(QIndex) + " "
                    BLIndex = BLIndex + 1
                if Qterm[T] == "0":
                    QN1 = "GND"
                    X_Line = "XBL" + str(QIndex) + " 0 " + QN1 + " cross_point\n"
                elif "VEE" in Qterm1:
                    QN1 = "VEE"
                    X_Line = "XBL" + str(QIndex) + " " + QN1 + " NC cross_point\n"
                elif "JP" not in Qterm[T]:
                    if "BL" in Qterm[T]:
                        donothing()
                    else:
                        UnRhole = "BL" + str(QIndex)
                        UnRouted.append([Qterm[T], UnRhole])
                else:
                    QN1 = Qterm[T]
                    X_Line = "X" + str(XIndex) + " " + QN1 + " " + "BL" + str(QIndex) + " cross_point\n"
                    XIndex = XIndex + 1
                #
            BOMtext.insert(END, X_Line)
        #
        Q_Line = Q_Line + Qterm4 + " " + QValue + "\n" 
        BOMtext.insert(END, Q_Line)
        if TopQL == 0: # Toggle between top and bottom
            TopQL = 1
        else:
            TopQL = 0
## Right Side BB for jumpers 9-16
    # List two BB pin resistors on Left side
    for R in range (0, len(RR_TwoList), 1):
        Rterm = RR_TwoList[R]
        Rname  = Rterm[0]
        Rterm1 = Rterm[1]
        Rterm2 = Rterm[2]
        RValue = Rterm[3]
        if "JP" not in Rterm1:
            UnRhole = "TR" + str(TRIndex)
            UnRouted.append([Rterm1, UnRhole])
        if "JP" not in Rterm2:
            UnRhole = "BR" + str(TRIndex)
            UnRouted.append([Rterm2, UnRhole])
        #
        R_Line = Rname + " " 
        R_Line = R_Line + "TR" + str(TRIndex) + " " + "BR" + str(TRIndex) + " "
        X_Line = "X" + str(XIndex) + " " + Rterm1 + " " + "TR" + str(TRIndex) + " cross_point\n"
        XIndex = XIndex + 1
        BOMtext.insert(END, X_Line)
        X_Line = "X" + str(XIndex) + " " + Rterm2 + " " + "BR" + str(TRIndex) + " cross_point\n"
        XIndex = XIndex + 1
        BOMtext.insert(END, X_Line)
        TRIndex = TRIndex + 1
        BRIndex = BRIndex + 1
        #
        R_Line = R_Line + RValue + "\n" 
        BOMtext.insert(END, R_Line)
    # List two BB capacitors Right side
    for C in range (0, len(CR_TwoList), 1):
        Cterm = CR_TwoList[C]
        Cname  = Cterm[0]
        Cterm1 = Cterm[1]
        Cterm2 = Cterm[2]
        CValue = Cterm[3]
        if "JP" not in Cterm1:
            UnRhole = "TR" + str(TRIndex)
            UnRouted.append([Cterm1, UnRhole])
        if "JP" not in Rterm2:
            UnRhole = "BR" + str(TRIndex)
            UnRouted.append([Cterm2, UnRhole])
        #
        C_Line = Cname + " " # 
        C_Line = C_Line + "TR" + str(TRIndex) + " " + "BR" + str(TRIndex) + " "
        X_Line = "X" + str(XIndex) + " " + Cterm1 + " " + "TR" + str(TRIndex) + " cross_point\n"
        XIndex = XIndex + 1
        BOMtext.insert(END, X_Line)
        X_Line = "X" + str(XIndex) + " " + Cterm2 + " " + "BR" + str(TRIndex) + " cross_point\n"
        XIndex = XIndex + 1
        BOMtext.insert(END, X_Line)
        TRIndex = TRIndex + 1
        BRIndex = BRIndex + 1
        #
        C_Line = C_Line + CValue + "\n" 
        BOMtext.insert(END, C_Line)
    # Add two BB pin Diodes 
    for D in range ( 0, len(DR_TwoList), 1):
        Dterm = DR_TwoList[D]
        Dname  = Dterm[0]
        Dterm1 = Dterm[1]
        Dterm2 = Dterm[2]
        DValue = Dterm[3]
        if "JP" not in Dterm1:
            UnRhole = "TR" + str(TRIndex)
            UnRouted.append([Dterm1, UnRhole])
        if "JP" not in Rterm2:
            UnRhole = "BR" + str(TRIndex)
            UnRouted.append([Dterm2, UnRhole])
        #
        D_Line = Dname + " "
        D_Line = D_Line + "TR" + str(TLIndex) + " " + "BR" + str(TRIndex) + " "
        X_Line = "X" + str(XIndex) + " " + Dterm1 + " " + "TR" + str(TRIndex) + " cross_point\n"
        XIndex = XIndex + 1
        BOMtext.insert(END, X_Line)
        X_Line = "X" + str(XIndex) + " " + Dterm2 + " " + "BR" + str(TRIndex) + " cross_point\n"
        XIndex = XIndex + 1
        BOMtext.insert(END, X_Line)
        TRIndex = TRIndex + 1
        BRIndex = BRIndex + 1
        #
        D_Line = D_Line + DValue + "\n" 
        BOMtext.insert(END, D_Line)
    # add resistors to Power / Gnd
    # TRIndex = max(TRIndex, BRIndex)
    # BRIndex = max(TRIndex, BRIndex)
    for R in range (0, len(RR_OneList), 1):
        Rterm = RR_OneList[R]
        Rname  = Rterm[0]
        Rterm1 = Rterm[1]
        Rterm2 = Rterm[2]
        RValue = Rterm[3]
        #
        R_Line = Rname + " " 
        if Rterm1 == "0":
            if "BR" in Rterm2:
                R_Line = R_Line + "GND " + Rterm2 + " "
            else:
                R_Line = R_Line + "GND " + "BR" + str(BRIndex) + " "
                if "JP" not in Rterm2:
                    UnRhole = "BR" + str(BRIndex)
                    UnRouted.append([Rterm2, UnRhole])
            X_Line = "XBR" + str(BRIndex) + " " + Rterm2 + " NC cross_point\n"
            XIndex = XIndex + 1
            BOMtext.insert(END, X_Line)
            BRIndex = BRIndex + 1
        elif "VDD" in Rterm1:
            if "TR" in Rterm2:
                R_Line = R_Line + "VDD " + Rterm2 + " "
            else:
                R_Line = R_Line + "VDD " + "TR" + str(TRIndex) + " "
                if "JP" not in Rterm2:
                    UnRhole = "TR" + str(TRIndex)
                    UnRouted.append([Rterm2, UnRhole])
            X_Line = "XTR" + str(TRIndex) + " " + Rterm2 + " NC cross_point\n"
            XIndex = XIndex + 1
            BOMtext.insert(END, X_Line)
            TRIndex = TRIndex + 1
        elif "VEE" in Rterm1:
            if "BR" in Rterm2:
                R_Line = R_Line + "GND " + Rterm2 + " "
            else:
                R_Line = R_Line + "VEE " + "BR" + str(BRIndex) + " "
                if "JP" not in Rterm2:
                    UnRhole = "BR" + str(BRIndex)
                    UnRouted.append([Rterm2, UnRhole])
            X_Line = "XBR" + str(BRIndex) + " " + Rterm2 + " NC cross_point\n"
            XIndex = XIndex + 1
            BOMtext.insert(END, X_Line)
            BRIndex = BRIndex + 1
        elif Rterm2 == "0":
            if "BR" in Rterm1:
                R_Line = R_Line + "GND " + Rterm1 + " "
            else:
                R_Line = R_Line + "GND " + "BR" + str(BRIndex) + " "
                if "JP" not in Rterm1:
                    UnRhole = "BR" + str(BRIndex)
                    UnRouted.append([Rterm1, UnRhole])
            X_Line = "XBR" + str(BRIndex) + " " + Rterm1 + " NC cross_point\n"
            XIndex = XIndex + 1
            BOMtext.insert(END, X_Line)
            BRIndex = BRIndex + 1
        elif "VDD" in Rterm2:
            if "TR" in Rterm1:
                R_Line = R_Line + "VDD " + Rterm1 + " "
            else:
                R_Line = R_Line + "VDD " + "TR" + str(TRIndex) + " "
                if "JP" not in Rterm1:
                    UnRhole = "TR" + str(TRIndex)
                    UnRouted.append([Rterm1, UnRhole])
            X_Line = "XTR" + str(TRIndex) + " " + Rterm1 + " NC cross_point\n"
            XIndex = XIndex + 1
            BOMtext.insert(END, X_Line)
            TRIndex = TRIndex + 1
        elif "VEE" in Rterm2:
            if "BR" in Rterm1:
                R_Line = R_Line + "GND " + Rterm1 + " "
            else:
                R_Line = R_Line + "VEE " + "BR" + str(BRIndex) + " "
                if "JP" not in Rterm1:
                    UnRhole = "BR" + str(BRIndex)
                    UnRouted.append([Rterm1, UnRhole])
            X_Line = "XBR" + str(BRIndex) + " " + Rterm1 + " NC cross_point\n"
            XIndex = XIndex + 1
            BOMtext.insert(END, X_Line)
            BRIndex = BRIndex + 1
        #
        R_Line = R_Line + RValue + "\n" 
        BOMtext.insert(END, R_Line)
    # # add capacitors to Power / Gnd
    # TRIndex = max(TRIndex, BRIndex)
    # BRIndex = max(TRIndex, BRIndex)
    for C in range (0, len(CR_OneList), 1):
        Cterm = CR_OneList[C]
        Cname  = Cterm[0]
        Cterm1 = Cterm[1]
        Cterm2 = Cterm[2]
        CValue = Cterm[3]
        #
        C_Line = Cname + " " # 
        if Cterm1 == "0":
            if "BR" in Cterm2:
                C_Line = C_Line + "GND " + Cterm2 + " "
            else:
                C_Line = C_Line + "GND " + "BR" + str(BRIndex) + " "
                if "JP" not in Cterm2:
                    UnRhole = "BR" + str(BRIndex)
                    UnRouted.append([Cterm2, UnRhole])
            X_Line = "XBR" + str(BRIndex) + " " + Cterm2 + " NC cross_point\n"
            XIndex = XIndex + 1
            BRIndex = BRIndex + 1
            BOMtext.insert(END, X_Line)
        elif "VDD" in Cterm1:
            if "TR" in Cterm2:
                C_Line = C_Line + "VDD " + Cterm2 + " "
            else:
                C_Line = C_Line + "VDD " + "TR" + str(TRIndex) + " "
                if "JP" not in Cterm2:
                    UnRhole = "TR" + str(TRIndex)
                    UnRouted.append([Cterm2, UnRhole])
            X_Line = "XTR" + str(TRIndex) + " " + Cterm2 + " NC cross_point\n"
            XIndex = XIndex + 1
            TRIndex = TRIndex + 1
            BOMtext.insert(END, X_Line)
        elif "VEE" in Cterm1:
            if "BR" in Cterm2:
                C_Line = C_Line + "GND " + Cterm2 + " "
            else:
                C_Line = C_Line + "VEE " + "BR" + str(BRIndex) + " "
                if "JP" not in Cterm2:
                    UnRhole = "BR" + str(BRIndex)
                    UnRouted.append([Cterm2, UnRhole])
            X_Line = "XBR" + str(BRIndex) + " " + Cterm2 + " NC cross_point\n"
            XIndex = XIndex + 1
            BRIndex = BRIndex + 1
            BOMtext.insert(END, X_Line)
        elif Cterm2 == "0":
            if "BR" in Cterm1:
                C_Line = C_Line + "GND " + Cterm1 + " "
            else:
                C_Line = C_Line + "GND " + "BR" + str(BRIndex) + " "
                if "JP" not in Cterm1:
                    UnRhole = "BR" + str(BRIndex)
                    UnRouted.append([Cterm1, UnRhole])
            X_Line = "XBR" + str(BRIndex) + " " + Cterm1 + " NC cross_point\n"
            XIndex = XIndex + 1
            BRIndex = BRIndex + 1
            BOMtext.insert(END, X_Line)
        elif "VDD" in Cterm2:
            if "TR" in Cterm1:
                C_Line = C_Line + "VDD " + Cterm1 + " "
            else:
                C_Line = C_Line + "VDD " + "TR" + str(TRIndex) + " "
                if "JP" not in Cterm1:
                    UnRhole = "TR" + str(TRIndex)
                    UnRouted.append([Cterm1, UnRhole])
            X_Line = "XTL" + str(TRIndex) + " " + Cterm1 + " NC cross_point\n"
            XIndex = XIndex + 1
            TRIndex = TRIndex + 1
            BOMtext.insert(END, X_Line)
        elif "VEE" in Cterm2:
            if "BR" in Cterm1:
                C_Line = C_Line + "GND " + Cterm1 + " "
            else:
                C_Line = C_Line + "VEE " + "BR" + str(BRIndex) + " "
                if "JP" not in Cterm1:
                    UnRhole = "BR" + str(BRIndex)
                    UnRouted.append([Cterm1, UnRhole])
            X_Line = "XBR" + str(BRIndex) + " " + Cterm1 + " NC cross_point\n"
            XIndex = XIndex + 1
            BOMtext.insert(END, X_Line)
            BRIndex = BRIndex + 1
        #
        C_Line = C_Line + CValue + "\n" 
        BOMtext.insert(END, C_Line)
    # List Diodes on Right side
    # TRIndex = max(TRIndex, BRIndex)
    # BRIndex = max(TRIndex, BRIndex)
    for D in range (0, len(DR_OneList), 1):
        Dterm = DR_OneList[D]
        Dname  = Dterm[0]
        Dterm1 = Dterm[1]
        Dterm2 = Dterm[2]
        DValue = Dterm[3]
        #
        D_Line = Dname + " " # 
        if Dterm1 == "0":
            if "BR" in Dterm2:
                D_Line = D_Line + "GND " + Dterm2 + " "
            else:
                D_Line = D_Line + "GND " + "BR" + str(BRIndex) + " "
                if "JP" not in Dterm2:
                    UnRhole = "BR" + str(BRIndex)
                    UnRouted.append([Dterm2, UnRhole])
            X_Line = "XBR" + str(BRIndex) + " " + Dterm2 + " NC cross_point\n"
            XIndex = XIndex + 1
            BRIndex = BRIndex + 1
            BOMtext.insert(END, X_Line)
        elif "VDD" in Dterm1:
            if "TR" in Dterm2:
                D_Line = D_Line + "VDD " + Dterm2 + " "
            else:
                D_Line = D_Line + "VDD " + "TR" + str(TRIndex) + " "
                if "JP" not in Dterm2:
                    UnRhole = "TR" + str(TRIndex)
                    UnRouted.append([Dterm2, UnRhole])
            X_Line = "XTR" + str(TRIndex) + " " + Dterm2 + " NC cross_point\n"
            XIndex = XIndex + 1
            TRIndex = TRIndex + 1
            BOMtext.insert(END, X_Line)
        elif "VEE" in Dterm1:
            if "BR" in Dterm2:
                D_Line = D_Line + "GND " + Dterm2 + " "
            else:
                D_Line = D_Line + "VEE " + "BR" + str(BRIndex) + " "
                if "JP" not in Dterm2:
                    UnRhole = "BR" + str(BRIndex)
                    UnRouted.append([Dterm2, UnRhole])
            X_Line = "XBR" + str(BRIndex) + " " + Dterm2 + " NC cross_point\n"
            XIndex = XIndex + 1
            BRIndex = BRIndex + 1
            BOMtext.insert(END, X_Line)
        elif Dterm2 == "0":
            if "BR" in Dterm1:
                D_Line = D_Line + "GND " + Dterm1 + " "
            else:
                D_Line = D_Line + "BR" + str(BRIndex) + " GND "
                if "JP" not in Dterm1:
                    UnRhole = "BR" + str(BRIndex)
                    UnRouted.append([Dterm1, UnRhole])
            X_Line = "XBR" + str(BRIndex) + " " + Dterm1 + " NC cross_point\n"
            XIndex = XIndex + 1
            BRIndex = BRIndex + 1
            BOMtext.insert(END, X_Line)
        elif "VDD" in Dterm2:
            if "TR" in Dterm1:
                D_Line = D_Line + "GND " + Dterm1 + " "
            else:
                D_Line = D_Line + "TR" + str(TRIndex) + " VDD "
                if "JP" not in Dterm1:
                    UnRhole = "TR" + str(TRIndex)
                    UnRouted.append([Dterm1, UnRhole])
            X_Line = "XTR" + str(TRIndex) + " " + Dterm1 + " NC cross_point\n"
            XIndex = XIndex + 1
            TRIndex = TRIndex + 1
            BOMtext.insert(END, X_Line)
        elif "VEE" in Dterm2:
            if "BR" in Dterm1:
                D_Line = D_Line + "GND " + Dterm1 + " "
            else:
                D_Line = D_Line + "BR" + str(Index) + " VEE "
                if "JP" not in Dterm1:
                    UnRhole = "BR" + str(BRIndex)
                    UnRouted.append([Dterm1, UnRhole])
            X_Line = "XBR" + str(BRIndex) + " " + Dterm1 + " NC cross_point\n"
            XIndex = XIndex + 1
            BRIndex = BRIndex + 1
            BOMtext.insert(END, X_Line)
        #
        D_Line = D_Line + DValue + "\n" 
        BOMtext.insert(END, D_Line)
    # List Q transistors on Right side
    for Q in range ( 0, len(QR_List), 1):
        Qterm = QR_List[Q]
        Qname = Qterm[0]
        Qterm1 = Qterm[1]
        Qterm2 = Qterm[2]
        Qterm3 = Qterm[3]
        Qterm4 = Qterm[4]
        QValue = Qterm[5]
        #
        Q_Line = Qname + " "
        #
        if "VDD" in Qterm:
            TopQR = 0
        elif "VEE" in Qterm:
            TopQR = 1
        if "TR" in Qterm1 or "TR" in Qterm2 or "TR" in Qterm3:
            TopQR = 0
        elif "BR" in Qterm1 or "BR" in Qterm2 or "BR" in Qterm3:
            TopQR = 1
        # Do three terminals
        for T in range(1, 4, 1):
            if TopQR == 0:
                QIndex = TRIndex
                if "TR" in Qterm[T]:
                    Q_Line = Q_Line + " " + Qterm[T] + " "
                else:
                    Q_Line = Q_Line + "TR" + str(QIndex) + " "
                    TRIndex = TRIndex + 1
                if Qterm[T] == "0":
                    QN1 = "GND"
                    X_Line = "XTR" + str(QIndex) + " 0 " + QN1 + " cross_point\n"
                elif "VDD" in Qterm[T]:
                    QN1 = "VDD"
                    X_Line = "XTR" + str(QIndex) + " " + QN1 + " NC cross_point\n"
                elif "JP" not in Qterm[T]:
                    if "TR" in Qterm[T]:
                        donothing()
                    else:
                        UnRhole = "TR" + str(QIndex)
                        UnRouted.append([Qterm[T], UnRhole])
                else:
                    QN1 = Qterm[T]
                    X_Line = "X" + str(XIndex) + " " + QN1 + " " + "TR" + str(QIndex) + " cross_point\n"
                    XIndex = XIndex + 1
                #
            else:
                QIndex = BRIndex
                if "BR" in Qterm[T]:
                    Q_Line = Q_Line + " " + Qterm[T] + " "
                else:
                    Q_Line = Q_Line + "BR" + str(QIndex) + " "
                    BRIndex = BRIndex + 1
                if Qterm[T] == "0":
                    QN1 = "GND"
                    X_Line = "XBR" + str(QIndex) + " 0 " + QN1 + " cross_point\n"
                elif "VEE" in Qterm1:
                    QN1 = "VEE"
                    X_Line = "XBR" + str(QIndex) + " " + QN1 + " NC cross_point\n"
                elif "JP" not in Qterm[T]:
                    if "BR" in Qterm[T]:
                        donothing()
                    else:
                        UnRhole = "BR" + str(QIndex)
                        UnRouted.append([Qterm[T], UnRhole])
                else:
                    QN1 = Qterm[T]
                    X_Line = "X" + str(XIndex) + " " + QN1 + " " + "BR" + str(QIndex) + " cross_point\n"
                    XIndex = XIndex + 1
                #
            BOMtext.insert(END, X_Line)
        #
        Q_Line = Q_Line + Qterm4 + " " + QValue + "\n" 
        BOMtext.insert(END, Q_Line)
        if TopQR == 0: # Toggle between top and bottom
            TopQR = 1
        else:
            TopQR = 0
    # List U ICs
    for U in range ( 0, len(UL_List), 1):
        CmpName = UL_List[U][0]
        CmpName = CmpName.replace("X","")
        CmpName = CmpName.replace(chr(167),"")# remove §
        U_Line = CmpName + " "
        for UPins in range(1, len(UL_List[U]), 1):
            CompPin = UL_List[U][UPins]
            U_Line = U_Line + CompPin + " "
        U_Line = U_Line + "\n"
        BOMtext.insert(END, U_Line)
    # Add back cross points to scope and Awg channels if any
    for X in range  ( 0, len(XCPList), 1):
        X_Line = XCPList[X]
        BOMtext.insert(END, X_Line)
    # Add Power / Ground
    # print(VPower)
    for PWR in range ( 0, len(VPower), 1):
        VPowerConnections[PWR].append(VPower[PWR])
        # print( "Found ", VPower[PWR], " connected to ", Vpin)
        V_Line = "V" + str(VIndex) + " " + VPower[PWR] + " GND 5\n"
        VIndex = VIndex + 1
        BOMtext.insert(END, V_Line)
    # print(UnRouted)
